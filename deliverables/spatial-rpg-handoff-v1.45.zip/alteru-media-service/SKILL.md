---
name: alteru-media-service
description: Integrate AlterU's shared image, audio, and video generation service into Agent workflows, games, applications, and internal services. Use for text-to-image, image editing, music, sound effects, player-avatar identity references, five-second portrait video, media task recovery, retries, rate limits, durable asset generation, or migration away from direct provider/model endpoints. Do not use this Skill to deploy the private media Worker or manage games.json.
---

# AlterU Media Service

Use the stable AlterU-owned API, bundled framework-neutral client, and Agent audio helper. Keep every caller independent from model hosts, provider fields, private deployment code, and credentials.

## Capability boundary

- Treat image `text` and single-reference `edit` as stable production capabilities.
- Use `edit`, not `avatar`, for player identity unless a product has separately validated `avatar`; current RPG production evidence is strongest for `edit`.
- Treat audio `music` and `sfx` as supported public capabilities. Prompts should be written in English by the calling Agent; end users do not need to author them.
- Audio generation success is not mastering approval. Durable assets require listening plus duration, loudness/peak, silence, and loop-boundary QA appropriate to their use.
- Treat five-second 9:16 start/end-frame video with an audio track as experimental. Require an explicit product need and test evidence before shipping it.
- Do not repurpose the video audio track as a production sound-effect generator. Workspace tests found that even single-object prompts with repeated `no music / no melody / dry Foley` constraints can add sustained tonal or musical layers, peak near 0 dBFS, and vary between generations. Five-second output also produces poor short-loop ambience even when edge RMS looks compatible.
- Use the audio-only endpoint for generated music and Foley. Prefer controllable Web Audio synthesis for deterministic UI bleeps or exact timing, and licensed recorded Foley when generation variability is unacceptable.
- Do not call provider endpoints directly from any Agent, game, application, or service.

Read [references/api-v1.md](references/api-v1.md) whenever implementing requests or errors. Read [references/audio.md](references/audio.md) whenever generating or integrating music/sound effects. Read [references/visual-identity.md](references/visual-identity.md) whenever a user/avatar can drive an image. Read [references/qa.md](references/qa.md) before declaring an integration ready.

## Integration workflow

1. Choose the stable workload namespace for `session_id`: permanent game UUID for a game; platform creation/session/project ID for an Agent; stable workload ID for an internal service. Reuse it throughout the workload and never mint a new value per request.
2. For TypeScript applications, prefer an existing workspace `shared/runtime/media.ts`; otherwise copy [assets/media.ts](assets/media.ts). For an Agent creating a durable MP3 asset, use [scripts/generate-audio.mjs](scripts/generate-audio.mjs) with an explicit output path.
3. Keep the default base URL from the client. Permit `baseUrl` overrides only for explicit local/staging QA; do not place provider hosts in environment variables.
4. Select the request mode:
   - `text`: environment, object, poster-like scene or any image with no reference.
   - `edit`: exactly one public HTTPS reference; use for player identity and controlled image-to-image work.
   - `avatar`: experimental alternate rendering path; never assume it preserves full-body identity better.
   - audio `music`: background music or longer musical structure.
   - audio `sfx`: one-shot Foley or ambient sound; it does not guarantee seamless loops.
5. Pass the desired scene dimensions to `fitMediaImageSize()` or `generateImageMedia()`. Do not crop/upload a square avatar merely to match the output aspect ratio; output size and identity reference are separate concerns.
6. Create one `requestId` per intentional generation. Reuse the same ID after an ambiguous timeout/network failure; create a new ID only after a structured terminal failure or an explicit user retry.
7. Surface immediate local feedback before the network finishes. Image generation must not block story/state progression unless the product explicitly requires media-gated play.
8. Handle `MediaServiceError` by code and `retryable`, respecting `retryAfterSeconds`. Do not blindly retry invalid references, rejected prompts or terminal failures.
9. Persist task IDs for video or any flow that must survive reload/restart. Poll no faster than eight seconds.
10. When an Agent creates a durable audio asset, download it into the project or controlled storage instead of treating the provider-backed CDN URL as the source file.
11. Run the bundled validator and the relevant QA matrix before release.

## Player visual identity

Only attach the player's reference when the player is the primary visible actor performing the scene's main action. Do not attach it to NPC-led, animal-led, environment or object shots merely because the player is mentioned.

Front-load a short `SUBJECT A` identity contract before the scene. Preserve the complete visible reference identity—not only the face—including silhouette, form/species, proportions, material, face visibility, covering, mask, costume, colors, patterns and accessories. If the reference does not show face, skin, hair, hands, arms or legs, keep them hidden and do not invent them. Stage props beside or against a faceless/covered subject instead of forcing new hands.

Keep named NPC identities separate. Never let the player's traits transfer to companions, background people, reflections, animals or props. Keep the final prompt concise enough that scene prose cannot bury the identity contract; the verified RPG contract caps it at 2400 characters.

## Video rules

- Supply public HTTPS start and end frames already composed at 9:16.
- Request exactly `ratio: '9:16'` and `durationSeconds: 5`.
- Describe one visible action. Put ambient sound in `soundPrompt`, not dialogue transcription.
- Use `submitVideoMedia()` + stored task ID when recovery matters; use `generateVideoMedia()` only when an in-memory wait is acceptable.
- Preserve the still image as fallback if video queues, times out or fails.
- Treat `soundPrompt` as audiovisual direction, not a mixing or mastering contract. It does not guarantee silence, event timing, absence of music, loudness, loopability, or isolated Foley.

## Audio rules

- Call `generateAudioMedia()` for application/runtime use, or `scripts/generate-audio.mjs` for an Agent-authored durable MP3.
- Accept only `kind: 'music' | 'sfx'` and `durationSeconds` from 0.5 through 120. Do not expose the upstream conditioner's larger numeric ceiling.
- Music prompts should name mood, instrumentation, tempo/BPM, structure, and vocal policy. SFX prompts should name source, action/count, microphone perspective/distance, environment, and exclusions.
- Do not promise deterministic output, exact event timing, fixed loudness, isolated stems, speech, or seamless looping. Generate alternate candidates when semantic precision matters and require human listening for a shipped asset.
- Raw output is 44.1 kHz stereo MP3. Keep playback gain conservative; master durable assets offline when true peak, loudness consistency, trimming, mono conversion, or loop seams matter.

## Validation

Run:

```bash
node /path/to/alteru-media-service/scripts/validate-media-integration.mjs /absolute/path/to/project
```

Add `--player-identity` when the project references a player avatar, `--video` when it uses video, and `--audio` when it uses generated music or sound effects.

Also run the project's build and real runtime tests. A successful HTTP response is not perceptual QA: inspect images, watch video, and listen to audio. For identity, use a normal human avatar and a faceless/nonhuman 1:1 fixture generated for testing rather than a real user or a library placeholder.

## Distribution boundary

This is a client-integration Skill, not the private service repository.

- Do not include Worker deployment, bindings, provider URLs, secrets, metrics tokens, `games.json`, migration tools or internal release scripts.
- Do not edit the recipient team's deployment workflow. Produce source changes, tests and a release-ready handoff only.
- Keep the RPG-building Skill separate. RPG projects may depend on this media contract, but this Skill must remain usable by non-RPG games.
