# Public API v1

Production base URL:

```text
https://game.aiwaves.tech/alteru-media/api
```

Every generation request requires:

- `request_id`: client-generated UUID used for idempotency;
- `session_id`: stable workload namespace. Games use a permanent game UUID; Agents use a platform creation/session/project ID; internal services use a stable workload ID. Never mint a fresh value per request.

Repeating the same `session_id + request_id` returns the same service task instead of generating twice.

## Images

`POST /v1/images/generations`

```json
{
  "request_id": "client-uuid",
  "session_id": "permanent-game-uuid",
  "mode": "text|edit|avatar",
  "prompt": "English visual prompt",
  "reference_urls": ["https://public.example/reference.png"],
  "size": { "width": 512, "height": 640 }
}
```

- `text`: zero references, PNG output.
- `edit`: exactly one public HTTPS reference, PNG output. This is the verified player-identity route.
- `avatar`: exactly one public HTTPS reference, WEBP output; treat as an alternate experimental mode.
- Width and height: 256–1536, divisible by 64, total pixels at most 1,572,864.

Images normally return HTTP 200 with `status: "succeeded"` and `media.type: "image"`.

## Video

`POST /v1/videos/generations`

```json
{
  "request_id": "client-uuid",
  "session_id": "permanent-game-uuid",
  "prompt": "One visible action",
  "sound_prompt": "rain and distant traffic",
  "start_url": "https://public.example/start.png",
  "end_url": "https://public.example/end.png",
  "ratio": "9:16",
  "duration_seconds": 5
}
```

The endpoint returns HTTP 202 and a service-owned task. It is experimental and accepts only the verified five-second portrait contract.

## Audio

`POST /v1/audio/generations`

```json
{
  "request_id": "client-uuid",
  "session_id": "stable-workload-id",
  "kind": "music|sfx",
  "prompt": "English audio prompt",
  "duration_seconds": 15
}
```

- Duration: 0.5–120 seconds.
- Success normally returns HTTP 200 and a completed task.
- Output media fields: `type: "audio"`, `kind`, HTTPS `url`, `duration_seconds`, `format: "mp3"`, `sample_rate_hz: 44100`, `channels: 2`.
- `generateAudioMedia()` is the TypeScript helper. `scripts/generate-audio.mjs` is the Agent helper for downloading a durable MP3 to an explicit path.
- The service guarantees transport metadata, not mastering, semantic precision, or seamless looping.

## Tasks

`GET /v1/tasks/{task_id}`

Statuses: `queued`, `running`, `succeeded`, `failed`. Provider task identifiers and provider-only fields are never public.

## Errors

```json
{
  "error": {
    "code": "RATE_LIMITED",
    "message": "Game generation rate limit reached",
    "retryable": true,
    "details": { "retry_after_seconds": 60 }
  }
}
```

Public codes:

| Code | Retry guidance |
| --- | --- |
| `INVALID_REQUEST` | Fix input; do not retry unchanged. |
| `REFERENCE_UNAVAILABLE` | Replace/fix public reference URL. |
| `PROVIDER_REJECTED` | Terminal for this prompt/reference combination. |
| `QUEUE_BUSY` | Retry with the supplied hint; default about 15 seconds. |
| `RATE_LIMITED` | Retry after the supplied hint; default about 60 seconds. |
| `PROVIDER_TASK_LOST` | Create a new task only after reporting loss. |
| `TIMEOUT` | Reuse the request ID while outcome is ambiguous. |
| `NOT_FOUND` | Do not poll the same unknown task forever. |
| `ORIGIN_NOT_ALLOWED` | Configuration/deployment issue; no client retry. |
| `INTERNAL_ERROR` | Retry only when marked retryable. |

Do not call or distribute private metrics, deployment, or provider interfaces. Agents, games, applications, and internal services only use the public base above.
