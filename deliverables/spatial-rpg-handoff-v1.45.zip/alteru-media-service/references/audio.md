# Audio generation and QA

Use this reference for Agent-authored music or sound effects through AlterU Media Service.

## Choose the path

- Application/runtime: copy `assets/media.ts` and call `generateAudioMedia()`.
- Agent creating a project asset: run `scripts/generate-audio.mjs`, which calls the same public service and downloads the MP3. It refuses to overwrite an existing file.
- Deterministic UI feedback or sample-accurate timing: prefer Web Audio synthesis or a reviewed recorded asset.

The Agent helper requires a stable workload namespace:

```bash
node scripts/generate-audio.mjs \
  --session-id <stable-workload-id> \
  --kind sfx \
  --prompt "A single dry wooden latch click, close microphone, no music, no voice." \
  --duration 2 \
  --output public/audio/latch.mp3
```

Use `--request-id <uuid>` to resume an ambiguous request. Do not change the request ID after a timeout unless the first task has a structured terminal failure or the user intentionally asks for another candidate.

## Prompt contracts

Write prompts in English. Do not ask users to translate or author model syntax.

Music prompt order:

```text
function/use, mood, genre, instrumentation, tempo/BPM, energy/structure, production perspective, no vocals when needed
```

Example:

```text
Background music for a nocturnal puzzle scene, warm and restrained, minimal ambient electronica, soft electric piano and analog synth, 88 BPM, gentle development, instrumental, no vocals, clean ending.
```

SFX prompt order:

```text
source/object, action and count, material, microphone perspective/distance, room/environment, desired transient/tail, exclusions
```

Example:

```text
A single wooden treasure-chest latch clicks open, dry close microphone, small room, crisp transient, short tail, no music, no voice.
```

Avoid artist imitation, copyrighted song titles, lyrics, dialogue, and vague one-word prompts. For gameplay-critical timing, describe only one event and trim offline after listening.

## Output contract

- 44.1 kHz, stereo, MP3.
- Duration from 0.5 to 120 seconds.
- Music and SFX use separate model routes behind the public service.
- Outputs are variable; a repeated prompt with a new request ID is a new candidate.

The API does not guarantee loudness, true peak, event timing, isolation, stems, speech, or seamless loop boundaries.

## QA before shipping

Always listen to the complete file. Also verify:

1. prompt adherence and absence of unwanted voice/music;
2. exact decoded duration, format, 44.1 kHz, and two channels;
3. no decoder clipping; keep durable music at or below about -1 dBTP after mastering;
4. appropriate integrated loudness relative to the actual game/application mix;
5. leading/trailing silence and whether a one-shot event is placed where playback expects it;
6. loop seam by listening across repeated playback, not only by comparing edge RMS;
7. mobile playback and pause/resume behavior when used at runtime.

Ordinary noncritical assets may ship from one reviewed candidate. Generate at least two candidates for title music, signature sounds, exact semantic events, or any output that fails the first listen. Do not keep regenerating indefinitely; stop once a suitable reviewed asset exists or report that the model is not meeting the requirement.

For durable Agent-authored assets, place the downloaded MP3 under the project's normal asset directory and include it in the build. For runtime-generated audio, persist the public task/media URL only when the product needs replay; keep a graceful fallback when generation or playback fails.
