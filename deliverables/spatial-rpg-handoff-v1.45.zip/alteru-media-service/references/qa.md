# Integration QA

## Mechanical checks

- Caller uses one stable workload namespace as `sessionId`; it is not regenerated per request.
- No provider/model hostname, provider route, secret, metrics token, or private deployment code appears in project source.
- Image size is fitted to the 64-pixel grid and remains under the pixel ceiling.
- Retry after ambiguous network failure reuses `requestId`.
- Explicit retry after structured terminal failure creates a new `requestId`.
- `QUEUE_BUSY` and `RATE_LIMITED` respect `retryAfterSeconds` and do not produce retry storms.
- Generation failure leaves gameplay usable and exposes a clear retry state.

## Image matrix

| Case | Expected |
| --- | --- |
| Text-only environment | no reference URL; scene matches current event rather than cover art |
| Object/item | no player reference; object enters the correct game state independently of image success |
| Normal player-led action | one original public HTTPS reference; `mode=edit`; identity belongs only to `SUBJECT A` |
| NPC-led action with player mentioned | no player reference |
| Player and named NPC together | player identity stays on `SUBJECT A`; NPC remains distinct |
| Faceless/nonhuman fixture | full silhouette/material preserved; no invented human face or limbs |
| Slow profile | first player image waits for the real profile rather than permanently using fallback identity |
| Saved wrong opening | bounded first-scene repair; no bulk regeneration of all history |

Inspect actual generated pixels. Prompt inspection and HTTP 200 are not substitutes.

## Video matrix

- Start and end frames are both public 9:16 images.
- One visible action fits five seconds.
- Audio track exists and matches `soundPrompt`.
- Task resumes from stored task ID after reload.
- Poll interval is at least eight seconds.
- Timeout/failure keeps the still-image fallback and does not block the game.
- No 4:5 frame is silently stretched or letterboxed into 9:16.

## Audio matrix

| Case | Expected |
| --- | --- |
| Music | English prompt names use, mood, instrumentation, BPM/tempo, structure, and vocal policy |
| One-shot SFX | one event; source/material/perspective/exclusions are explicit; leading silence does not break timing |
| Ambience | no unwanted music/voice; level is usable; fades are understood rather than mislabeled as seamless |
| Duration bounds | client and service reject values below 0.5 or above 120 seconds |
| Idempotent retry | same workload + request ID returns the same task/media rather than another generation |
| Durable Agent asset | MP3 is downloaded into a project-controlled path and the helper refuses overwrite |
| Runtime audio | failure leaves a silent/recorded/synthesized fallback and does not block core state |
| File QA | decodes as 44.1 kHz stereo MP3; duration matches; no clipped samples |
| Perceptual QA | complete file listened to; prompt adherence, unwanted elements, loudness, timing, and loop seam reviewed |

## Release evidence

Record:

- project commit or Agent work artifact;
- media client version/source;
- request mode and dimensions;
- task ID, never provider task ID;
- success/failure code and timing;
- inspected normal-avatar and edge-fixture results;
- production bundle proof that the public client—not a provider endpoint—is shipped.
