# Complete visual identity contract

## Ownership decision

Use a player reference only when the player is both:

1. a primary visible subject; and
2. the actor performing the shot's main action.

NPC-led shots, player-as-background shots, animal-led shots, object close-ups and environment shots do not receive the player reference.

## Prompt order

Put identity before scene prose:

```text
HARD FULL-VISUAL-IDENTITY CAST MAP. REFERENCE IMAGE OVERRIDES ALL GENERIC CHARACTER WORDS. SUBJECT A MUST keep the exact complete visible identity of the main foreground subject in the reference—not merely its face. Preserve its silhouette, form or species, body proportions, material, head shape, face visibility, covering, mask, costume, colors, patterns and accessories. Never reinterpret a covering as clothing over a generic human body. Any face, skin, hair, hands, arms or legs not visible in the reference MUST remain hidden and MUST NOT be invented. If hands are absent, stage props beside or against SUBJECT A instead of exposing new hands. Do not transfer reference traits to other people, animals or objects. CURRENT SCENE: ...
```

Keep the combined prompt concise. The verified cinematic RPG implementation uses a 2400-character ceiling.

## Scene writing

- Call the player `SUBJECT A`; describe actions and props, not an invented body.
- Do not visually define gender, age, ethnicity, species, face, hair, anatomy, body type or role-shaped clothing.
- Treat courier, traveler, knight, detective and similar words as story responsibilities, not appearance.
- Give every named NPC a separate explicit identity.
- When a covered/faceless subject needs to interact with an object, place it beside, against or near the original silhouette unless the reference visibly supports hands.
- Ban readable text, pseudo-text, logos and UI in generated scenes unless the product intentionally needs them.

## Required edge fixture

Do not use a real user or a game's bundled placeholder for destructive/iterative QA. Generate a dedicated 1:1 fixture whose identity depends on more than a face, for example:

- an off-white sheet ghost;
- no visible face, skin, hair, hands, arms or legs;
- two oval eye holes;
- a distinctive colored patch and one small accessory.

Pass criteria: the result preserves the entire covered silhouette and distinguishing details, does not turn it into a generic human, does not invent absent body parts, and does not transfer the reference identity to an NPC.

Also test a normal human avatar. The edge fixture must complement, not replace, ordinary identity QA.
