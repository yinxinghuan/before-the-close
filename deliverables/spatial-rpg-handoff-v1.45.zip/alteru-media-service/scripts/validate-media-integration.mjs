#!/usr/bin/env node

import fs from 'node:fs'
import path from 'node:path'

const args = process.argv.slice(2)
const targetArg = args.find((arg) => !arg.startsWith('--'))
const requireIdentity = args.includes('--player-identity')
const requireVideo = args.includes('--video')
const requireAudio = args.includes('--audio')

if (!targetArg) {
  console.error('Usage: node validate-media-integration.mjs /absolute/path/to/project [--player-identity] [--video] [--audio]')
  process.exit(2)
}

const root = path.resolve(targetArg)
if (!fs.existsSync(root) || !fs.statSync(root).isDirectory()) {
  console.error(`Project directory not found: ${root}`)
  process.exit(2)
}

const allowedExtensions = new Set(['.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs'])
const ignored = new Set(['node_modules', 'dist', '.git', 'coverage'])
const files = []

function walk(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    if (ignored.has(entry.name)) continue
    const absolute = path.join(directory, entry.name)
    if (entry.isDirectory()) walk(absolute)
    else if (allowedExtensions.has(path.extname(entry.name))) files.push(absolute)
  }
}

walk(root)
const source = files.map((file) => fs.readFileSync(file, 'utf8')).join('\n')
const failures = []
const warnings = []

function requirePattern(pattern, message) {
  if (!pattern.test(source)) failures.push(message)
}

requirePattern(/game\.aiwaves\.tech\/alteru-media\/api|generateImageMedia|generateAudioMedia|submitVideoMedia|generateVideoMedia/, 'public AlterU Media Service client/base not found')
requirePattern(/sessionId|session_id/, 'media requests do not visibly use a stable workload session ID')
requirePattern(/requestId|request_id|createMediaRequestId/, 'idempotent request ID handling not found')

const forbidden = [
  [/\/generate_image(?:_avatar|_text)?\b/, 'direct image provider route'],
  [/MEDIA_METRICS_TOKEN/, 'private metrics token'],
  [/\/internal\/metrics/, 'private metrics endpoint'],
  [/deploy-backend\.mjs/, 'private deployment script'],
  [/AI_SERVICE3_AUDIO_(?:BASE_URL|TOKEN)|X-AlterU-Media-Key|\/audio_file\//, 'private audio provider configuration or route'],
]

if (requireVideo) forbidden.push([/\/video_task\b/, 'direct video provider task route'])

for (const [pattern, label] of forbidden) {
  if (pattern.test(source)) failures.push(`forbidden ${label} found in game source`)
}

if (requireIdentity) {
  requirePattern(/HARD FULL-VISUAL-IDENTITY CAST MAP/, 'full visual identity contract not found')
  requirePattern(/SUBJECT A/, 'SUBJECT A ownership label not found')
  requirePattern(/MUST NOT be invented|must not be invented/i, 'absent-body protection not found')
  requirePattern(/mode:\s*['"]edit['"]|mode\s*===?\s*['"]edit['"]|referenceMode\s*=\s*['"]edit['"]|mode:\s*ref_url\s*\?\s*referenceMode/, 'verified edit mode not found')
  requirePattern(/referenceUrls|reference_urls|ref_url/, 'reference URL transport not found')
}

if (requireVideo) {
  requirePattern(/ratio:\s*['"]9:16['"]|ratio\s*===?\s*['"]9:16['"]/, 'verified 9:16 video ratio not found')
  requirePattern(/durationSeconds:\s*5|duration_seconds:\s*5/, 'verified five-second video duration not found')
  requirePattern(/waitForMediaTask|generateVideoMedia|getMediaTask/, 'video polling/recovery client not found')
}

if (requireAudio) {
  requirePattern(/generateAudioMedia|\/v1\/audio\/generations/, 'public audio generation client/route not found')
  requirePattern(/kind:\s*['"](?:music|sfx)['"]|kind\s*===?\s*['"](?:music|sfx)['"]|MediaAudioKind/, 'audio kind selection not found')
  requirePattern(/durationSeconds|duration_seconds/, 'audio duration handling not found')
  requirePattern(/media\?*\.type\s*!==?\s*['"]audio['"]|media\.type\s*===?\s*['"]audio['"]|MediaAudio/, 'audio response type handling not found')
}

if (!/fitMediaImageSize/.test(source)) warnings.push('fitMediaImageSize is not referenced; confirm dimensions are already valid multiples of 64')
if (!/MediaServiceError/.test(source)) warnings.push('MediaServiceError is not referenced; confirm structured errors are handled')

const result = {
  ok: failures.length === 0,
  root,
  scannedFiles: files.length,
  playerIdentity: requireIdentity,
  video: requireVideo,
  audio: requireAudio,
  failures,
  warnings,
}

console.log(JSON.stringify(result, null, 2))
process.exit(result.ok ? 0 : 1)
