---
name: build-spatial-story-game
description: Build or extend an orthogonal 2D map-exploration RPG with generated scene art, directly controlled characters, collision-aligned objects, connected areas, and asset-grounded AI narrative. Use for RPG-JS-style spatial story games or converting an existing narrative RPG to map interaction; retain the existing story authority.
---

# 空间叙事 RPG 制作流程

将可行走世界与持久叙事组合起来。先通过一个真正可玩的场景，再用相邻场景验证复用。适用于正交 2D 地图壳；不是纯文字/电影分页壳，也不是任意生成世界或多人生产后台的保证。

## 选择与范围

- 明确这次做新游戏、给现有叙事换空间壳，还是扩展已验证地图。保留用户选择的题材、玩法、引擎与发布范围。
- 编码前复制 `assets/experience-capability-profile.json` 到项目 `doc/experience-capabilities.json`，按 [体验能力档案](references/experience-capability-profile.md) 记录单次形态、时长、连续性、NPC、对话、背包、声音、旅程数、持久化和收束模式。发布前再次更新并运行 `validate-experience-profile.mjs`。单旅程、作者对白和本地恢复都可以是合格的明确选择；画像触发的对话历史、人物生活、图像背包、脚步、云恢复或多旅程不能因 agent 忘记实现而静默消失。
- 使用项目已有 `game-interface-workflow` 推进需求、视觉、UI 与运行 QA；新玩法使用 `game-design-review`。用户已认可方向时直接延续，不重新索要风格批准。
- 正式人物、墙地、门、家具、物件、特写、海报、音乐及事件音效必须使用当前平台媒体服务；调用与任务恢复遵循 `alteru-media-service`。记录稳定 session、request/task、结果 URL、源文件 SHA 和准入状态；本地脚本只做有记录的透明化、裁切、装配和审计，不能自行重画正式素材或直连模型供应商。
- 原有 StorySave/reducer/Story Session 是唯一叙事权威；空间引擎不再保存另一套道具与剧情事实。新建叙事内核时使用当前 `build-stateful-story-game` 冻结内核，不要从某个成品整包复制旧引擎。
- `create-rpg-game` 的 stateful/cinematic 两种产品壳不能被误当成此空间壳。正式后台和发布仍按项目当前 Story Session/发布合同另行验证。

## 从工具包开始

首次在另一个项目使用时，读 [独立使用与复验](references/quickstart.md)。先完成参数化素材整理和清单检查，再进入目标游戏真实 renderer；工具包不是可直接发布的完整游戏模板。

若制作 B 式正交俯视探索场景，直接使用包内 [独立墙地拼装合同与参考图](references/modular-orthographic-scene.md) 和 [墙、门、物件装配规格及失败准入例](references/wall-door-assembly.md)；包内可离线查看旧街真实运行的墙地、门洞、人物与物件关系。接收方不应被要求打开样本游戏仓库才能判断投影、墙地分层或视觉准入。剧情特写的镜头例外也在该合同中。

## 制作顺序

1. **空间白盒与尺度合同**：先确定世界坐标、人物脚底与占地、场景真实用途、通行净宽、门/家具尺寸。空间比例来自场景身份，不来自图片画布宽度。记录不变量及允许变化项；读 [空间和美术合同](references/art-and-space.md)。场景跨越多个手机视口、需要横纵镜头移动或多个功能区时，再读 [大面积可探索场景](references/large-scene-layout.md)。
2. **场景清单**：为每个场景定义稳定 ID、独立地板/墙段/门槛/家具素材、可行走边界、静态障碍、人物、实体/状态、接近点、出入口及到达点。由同一数据投射渲染、寻路、碰撞和模型上下文；不要维护彼此无关联的四套坐标。模块化场景按 [墙地拼装合同](references/modular-orthographic-scene.md) 落地，整房概念图不能直接顶替运行地图。
3. **素材生产与准入**：先把“平台能否直接生成新的完整素材”作为独立能力验收，记录并行数、墙钟时间、每件任务耗时、首轮准入率和纠正轮数；场景拼装、裁切复用和代码缩放都不能充当生成成功证据。地板与墙面是不同源素材，门洞按布局真实留空；背景只烘焙不会改变且不承担墙地拼装职责的环境。可变物件独立状态图，人物用统一动作图集；生成工具不保证输出透明 PNG、指定尺寸或一致位置。先按 [投影、比例、步态准入门禁](references/art-admission-gate.md) 建立人物、门、地砖、家具和小物件的同屏比例表；主角另执行 [主角素材阻断门禁](references/protagonist-asset-gate.md)，禁止局部肢体反射，未 accepted 时整房不能称高保真。实测主角/NPC 身高、墙面与物件裁切、桌面前后边是否平行等长及四向动作，再进入真实手机合成画面；禁止凭提示词或图集 hash 宣称素材合规。任一类尺寸调整后，重新检查整组比例与碰撞。房间空、缺少使用痕迹或需要非关键陈设时，使用 [场景密度与生活痕迹合同](references/environment-density.md)，先用独立家具建立功能分区和可解释的工作关系，再用主要设备的材质 / 接口建立题材身份，最后补独立小物件与使用痕迹；不要把“多画东西”直接等同于合格氛围。大场景需要批量补景时，素材生产通过后才按 [大面积可探索场景](references/large-scene-layout.md) 的生成式细节包合同使用语义槽位、逐格准入、确定性装配与强制回退；图片模型不拥有路线、碰撞和区域布局的决定权。
4. **渐进房间交付**：用户生成新房间时按 [动态房间渐进交付合同](references/progressive-room-delivery.md)，在媒体任务开始前冻结场景 ID、边界、出生点、出口、语义槽位、接近点、路线和碰撞。该骨架一旦通过可达检查就允许玩家进入；未完成的家具以与最终 footprint 相同的可识别体积显示，媒体在后台并行生成。虚空状态持续显示不挡移动的 `role=status` 提示，只说明“世界正在加载 / 可以先四处看看”。碰撞、路线、footprint、媒体任务、后台处理、坐标、画布尺寸和测速等实现信息不得进入玩家文案；没有真实任务进度时也不显示百分比或伪造完成数。准入后只替换对应槽位的视觉和状态图，不移动既有碰撞、出口或玩家。单件失败继续保留体积与功能状态，不能把整房锁在加载页。分别记录 `brief → shell interactive` 与 `brief → high-fidelity accepted`，不能把后者当作玩家等待时间。
5. **最小行动闭环**：按 [探索、接近与内容面板合同](references/exploration-interaction.md) 分开 `热点寻路 → 已接近行动按钮 → 内容/转场`。点击地图实体只能接近，不得自动展开或提交；局部面板绑定原目标，移动即退出。随后才是权威提交 → 图形状态和库存变化 → 下一决策。不让每个物件都变成遮住地图的调查卡。用户要求接近旧街参考体验或交付可复用完整壳时，同时执行 [参考体验完整性合同](references/reference-experience-parity.md)；新旅程开场、NPC 环境巡游/注意面向、按时间展开的对话、地图、背包、菜单和可持续 NPC 交谈都是交付范围，不能用静态人物、地点列表、人物摘要和一次性动作代替。动态 NPC 的画面、碰撞、接近点、热点与权威行动距离必须共用位置。
6. **受限叙事**：模型只获得当前场景允许看到的实体、状态、已知名字、库存、线索和可做动作。结构提议经验证/必要的语义审查后交给规则执行；自由叙述不能直接改图、传送或发道具。新空间、新角色或新动作缺少完整资产/能力时，不临时生一张图就放行。读 [权威和转场合同](references/runtime.md)。
7. **跨场景实证**：同一主角连续走完相邻场景，往返两条连接，回来时状态保持，刷新仍在当前场景。先完成入口/出口/到达点/版本迁移和请求恢复，再增加地图数。数量由本次目标决定，不固定三张。
8. **验收与沉淀**：运行 [验收矩阵](references/acceptance.md) 和 [最终合成画面签收门禁](references/final-visual-gate.md)。机械测试、素材孤图和第一轮截图都不能把视觉状态改成“已通过”；负责 agent 必须逐件检查最终 renderer，修复 P0/P1 后以同状态复拍并再次签收。用户要求完整可玩或高保真版本时，再执行 [章节收口与声画发布门禁](references/release-completeness.md)，把章节完成、运行素材、背景音乐、事件音、海报、双部署和目录状态逐层收口。记录实际失败及适用边界；只有已运行且完成第二轮视觉签收的能力写成“已验证”，下一阶段能力留为候选。

## 接入原有 StoryCartridge

使用 [故事与地图绑定](references/story-binding.md) 中的可移植编译器和旧档接入预检。支持一个叙事地点对应多个房间、按场景区分同名动作和明确落点；复制模块后对目标副本运行独立验证，再接唯一 Story Session 的提交前准入。

## 增加选择与后果

已验证的线性路线要扩展成分支时，读 [分支与可见后果](references/branch-consequences.md)。把前置信息、真实代价、允许改选时机、确认与完成、跨场景后果和旧档兼容一起设计；不能只换两段台词或让美术独立决定完成。

## 收束章节与回顾结果

已有自然完成点、完成后仍可探索时，读 [章节收束](references/chapter-closure.md)。从权威完成事实生成只读结果，保留实际路线后果与旧档语义，检查小屏固定操作区和关闭原地继续；不把回执、自动化通关或观察脚本误报为完成/理解证据。

## 增加实体角色

角色图集准入后，按 [实体角色扩展](references/physical-characters.md) 共享站位/碰撞/渲染配置，并接权威介绍、旧档与回执恢复。角色在画面里存在不等于玩家已知道姓名；站立验收也不能代替四方向图集动作验收。

## 通过媒介增加角色

故事需要电台、电话或书信角色时，读 [媒介角色合同](references/mediated-characters.md)。区分身份已知、当前可联络和物理在场，复用现有权威命令准入，验证首次介绍与丢回执恢复。远程角色不替代尚未完成的实体素材验收。

## 手机视口与局部特写

制作手机直接移动场景、提高地图占比、全屏铺底或加入局部观察时，读 [镜头与特写合同](references/viewport-and-closeups.md)。生产探索镜头不能默认把完整地图 `contain` 成总览；先按认可参考或总览/轻推对照确定可见世界范围与人物可读尺度，再用共享世界父层跟随脚点。等比镜头不能改变世界比例、碰撞或存档；近景复用已准入实体状态，操作仍走同一个权威入口。只有少数需要看清细节/操作设备的节点进入特写，普通拾取无需全部弹卡。

## 移动、步态与手机差异

直接移动/点击寻路出现滑步、节点停顿或手机与桌面不同步时，读 [距离驱动步态与手机验收](references/mobile-motion.md)。可复用 `assets/distance-motion.ts`，由目标游戏配置步幅与姿态名；位移、碰撞后的路程与切帧共用一次更新。用户反馈、帧率模拟和真实设备证据分别记录。

## 视角定版与候选替换

用户确认可玩版本的视角后，按 [素材生产合同](references/art-production.md) 固定参考、运行元数据和准入流程。确认视角不代表当前边缘已完美，也不意味着下一张生成图可直接覆盖。一次候选失败后应回到已有可玩基线推进独立工作，避免把章节研发变成无限重生成。

## 可执行工具

- `scripts/verify-motion.mjs [module.ts]`：Node >=22.18，无npm依赖，在合成空间验证距离步态与路径预算；默认检查包内模块，或传目标游戏副本。

- `scripts/verify-package.py PACKAGE.zip --report RESULT.json`：在临时目录解包，用合成诊断图/小房间验证浅色保护、失败不覆盖、碰撞路径和状态完整性；不读游戏代码、不联网。需要 Pillow/numpy 和 PATH 中的 Node。

- `scripts/prepare-actor-cutout.py SOURCE OUTPUT --neutral-min N --chroma-max N --foot-x X --foot-y Y`：仅在当前用户授权与图像工具规则允许本地编辑时使用。3×4 图集的浅中性背景连通去底、两像素边沿去污染和无缩放脚底对齐；参数必须由当前素材确定，不自动接入游戏。需要 Pillow/numpy。详见 [素材生产合同](references/art-production.md)。

- `scripts/inspect-assets.py <png...>`：只读报告 PNG 实际尺寸、模式、alpha 范围和不透明主体边界；需要 Pillow。不会编辑图像。
- `scripts/audit-projected-art.py SPEC.json --root GAME_ROOT`：只读检查人物可见身高、墙面与物件的源图到世界尺寸横纵缩放，以及可选的主家具与人物比例；准入格式和视觉边界见 [投影、比例、步态准入门禁](references/art-admission-gate.md)。需要 Pillow。
- `scripts/validate-world.mjs <manifest.json> [asset-root]`：验证空间清单、可达性、转场落点、图集边界与资产文件；门目标额外检查 approach/threshold 脚点进入 activation，portal target 到达后仍在目标门激活区。输入格式见 [manifest](references/manifest.md)。必须从游戏真正消费的清单导出，禁止另写一套只为通过检查的数据。
- `scripts/validate-progressive-room.mjs <room-contract.json>`：检查虚空与完成态共用 scene、出生点、出口、槽位及 footprint，并拒绝向玩家暴露碰撞、坐标、后台任务、画布尺寸和测速等实现信息。复制 `assets/progressive-room-contract.json` 后填写项目真实数据；它不替代可达性、媒体恢复和真实画面验收。
- `scripts/validate-experience-profile.mjs <experience-capabilities.json>`：按游戏画像检查高保真版本是否遗漏开场、NPC 生活、分阶段对话、长篇/跨次对话历史、背包图像、距离脚步、持久化和章节收束，并校验单/多旅程、作者/生成对白与本地/云恢复的明确选择。复制 `assets/experience-capability-profile.json` 后填写真实证据。
- `assets/conversation-history.ts`、`assets/journey-directory.ts`、`assets/distance-footsteps.ts`：存储无关的对话历史、旅程目录和实际位移脚步最小内核。接收项目负责把它们接入自己的权威存档、音频和 UI；不能把纯内存调用冒充持久化或真实音频验收。
- `assets/nearby-interaction.mjs`：零依赖的稳定目标选择与底部行动意图参考；接收项目需把自己的真实 activation 作为 `isNear` 传入，并按 [互动合同](references/exploration-interaction.md) 做浏览器截图复验。
- `scripts/check-art-candidates.py <art-manifest.json> --root <game-root> [--candidate ID=PATH] [--report out.json]`：根据实际运行元数据检查尺寸、alpha、hash、裁切与脚底；需要 Pillow。只有传入的候选参与替换检查，文件保持只读。格式与退出码见 [素材生产合同](references/art-production.md)。
- `scripts/build-art-review.py SPEC.json --root GAME_ROOT --out REVIEW.html`：从原始 PNG 生成只读 3×4 图集检查文档，切换底色/方向/帧与播放。输入、脚点参考和边界见 [素材生产合同](references/art-production.md)。不是游戏 renderer，不修改透明通道或准入状态。
- 这些检查都不能判断图片画得是否正确。真实运行证据仍是最终关口。

## 物件遮挡

人物与家具需要正确前后叠放时读 [深度排序](references/depth-rendering.md)，包含固定图形节点、支撑物深度、坐标取整补偿与真实失败边界；不要把原始图像高度当成落地深度。

## 服务与恢复实证

将已完成章节接入服务、受限模型或生产发布时读 [服务与恢复证据](references/production-evidence.md)。区分当前设备观察选择、权威命令、历史回执、备份恢复、云端 PITR 和平台目录上架；本包不自带生产后台。

## 独立工程装配

新建真实 RPG-JS 壳时读 [独立装配实证](references/independent-assembly.md)。v1.9 提供参数化 world / renderer / storage scope，保留版本、启动握手、单实例和生产边界；它们已用于第二个独立章节，不是成品后端模板。

## 连续调查与题材 UI（第二题材试用）

需要把空间探索扩成连续调查时，读 [连续调查与可换主题 UI](references/continuous-investigation.md)。为新故事选择或应用六套既有界面时，必须再读 [空间叙事 UI 主题目录](references/ui-theme-catalog.md)，按稳定编号/slug 记录选择，并复制或映射 `assets/ui-theme-tokens.css` 的语义 token。主题必须覆盖探索 HUD、行动区、对话、背包、档案、资料放大、加载、错误和结果；不能只给档案组件换色。先用一条权威、可恢复的任务证明来源、比较、后果与下一步，再扩展生成内容。连续调查与跨题材主题应用仍须经同事 agent 小切片复验后才能标为正式可交接。

## 复用边界

已验证参考：项目内 `rpgjs-story-lab`。具体坐标、车厢题材、黄雨衣和章节规则只属样本，不能作为其他游戏默认内容。参考定位与已知坑见 [实证记录](references/evidence.md)。技能可移植的是合同、制作顺序和检查器；样本没有被认证为生产多人模板。

交付时指出：技能位置、实际扩展了哪些玩法/场景、通过哪些检查、哪些仍未经验证。不把自动化通关称为玩家理解通过。未经请求不发布或创建新后台。
