/** Zero-dependency grid pathfinder. Actor positions use top-left coordinates. */
export function actorTopLeftFromFoot(foot,actor){return {x:foot.x-actor.w/2,y:foot.y-actor.h}}

export function createWalkability({region,obstacles,actor}){
 const overlaps=(p,o)=>p.x<o.x+o.w&&p.x+actor.w>o.x&&p.y<o.y+o.h&&p.y+actor.h>o.y
 return p=>Number.isFinite(p.x)&&Number.isFinite(p.y)&&p.x>=region.x&&p.y>=region.y&&p.x+actor.w<=region.x+region.w&&p.y+actor.h<=region.y+region.h&&!obstacles.some(o=>overlaps(p,o))
}

export function findGridPath({from,to,step,isWalkable}){
 const key=p=>`${p.x},${p.y}`,round=p=>({x:Math.round(p.x/step)*step,y:Math.round(p.y/step)*step})
 const clear=(a,b)=>{const n=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)));for(let i=1;i<=n;i++)if(!isWalkable({x:a.x+(b.x-a.x)*i/n,y:a.y+(b.y-a.y)*i/n}))return false;return true}
 if(!isWalkable(from)||!isWalkable(to))return []
 const nearby=p=>{const center=round(p),points=[];for(let y=-1;y<=1;y++)for(let x=-1;x<=1;x++){const q={x:center.x+x*step,y:center.y+y*step};if(isWalkable(q)&&clear(p,q))points.push(q)}return points.sort((a,b)=>Math.hypot(a.x-p.x,a.y-p.y)-Math.hypot(b.x-p.x,b.y-p.y))}
 const starts=nearby(from),ends=new Set(nearby(to).map(key));if(!starts.length||!ends.size)return []
 const queue=[...starts],parents=new Map(starts.map(p=>[key(p),null]));let end
 for(let i=0;i<queue.length;i++){
  const p=queue[i];if(ends.has(key(p))){end=p;break}
  for(const [dx,dy] of [[step,0],[-step,0],[0,step],[0,-step]]){const q={x:p.x+dx,y:p.y+dy};if(!parents.has(key(q))&&isWalkable(q)&&clear(p,q)){parents.set(key(q),p);queue.push(q)}}
 }
 if(!end)return []
 const route=[to];for(let p=end;p;p=parents.get(key(p))??null)route.push(p)
 return route.reverse()
}
