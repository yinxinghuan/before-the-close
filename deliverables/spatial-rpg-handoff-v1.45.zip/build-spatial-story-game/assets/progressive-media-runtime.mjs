/**
 * Recover accepted media tasks for a progressive room without resubmitting them.
 * Consumers provide the platform task reader so this module stays transport agnostic.
 */

const phases=new Set(['pending','checking','ready','failed'])

export function freshProgressiveMediaState(definitions){
 return {version:1,assets:Object.fromEntries(Object.entries(definitions).map(([id,item])=>[id,{taskId:item.taskId,requestId:item.requestId,phase:'pending'}]))}
}

export function loadProgressiveMediaState(storage,key,definitions){
 const fresh=freshProgressiveMediaState(definitions)
 try{
  const saved=JSON.parse(storage.getItem(key)??'null')
  if(saved?.version!==1)return fresh
  for(const [id,expected] of Object.entries(definitions)){
   const entry=saved.assets?.[id]
   if(entry?.taskId===expected.taskId&&entry.requestId===expected.requestId&&phases.has(entry.phase))fresh.assets[id]={...entry}
  }
 }catch{}
 return fresh
}

export function saveProgressiveMediaState(storage,key,state){storage.setItem(key,JSON.stringify(state))}

const wait=(milliseconds,signal)=>new Promise((resolve,reject)=>{
 const timer=setTimeout(resolve,milliseconds)
 signal?.addEventListener('abort',()=>{clearTimeout(timer);reject(new DOMException('Aborted','AbortError'))},{once:true})
})

export async function recoverProgressiveMedia({definitions,initial,readTask,onUpdate,signal,pollIntervalMs=8000}){
 let state={version:1,assets:Object.fromEntries(Object.entries(initial.assets).map(([id,entry])=>[id,{...entry}]))}
 const emit=(id,entry)=>{state={version:1,assets:{...state.assets,[id]:entry}};onUpdate?.(state,id)}
 await Promise.all(Object.entries(definitions).map(async([id,expected])=>{
  const current=state.assets[id]
  if(current?.phase==='ready'&&current.taskId===expected.taskId&&current.requestId===expected.requestId)return
  emit(id,{taskId:expected.taskId,requestId:expected.requestId,phase:'checking'})
  while(!signal?.aborted){
   try{
    const task=await readTask(expected.taskId,{signal})
    if(task.task_id!==expected.taskId||task.request_id!==expected.requestId){emit(id,{taskId:expected.taskId,requestId:expected.requestId,phase:'failed',errorCode:'TASK_IDENTITY_MISMATCH'});return}
    if(task.status==='succeeded'&&task.media?.type==='image'){emit(id,{taskId:expected.taskId,requestId:expected.requestId,phase:'ready',remoteUrl:task.media.url});return}
    if(task.status==='failed'){emit(id,{taskId:expected.taskId,requestId:expected.requestId,phase:'failed',errorCode:task.error?.code??'GENERATION_FAILED'});return}
    emit(id,{taskId:expected.taskId,requestId:expected.requestId,phase:'pending'})
    await wait(Math.max(8000,pollIntervalMs),signal)
   }catch(error){
    if(signal?.aborted||(error instanceof DOMException&&error.name==='AbortError'))return
    if(error?.retryable===false){emit(id,{taskId:expected.taskId,requestId:expected.requestId,phase:'failed',errorCode:error.code??'TASK_READ_FAILED'});return}
    emit(id,{taskId:expected.taskId,requestId:expected.requestId,phase:'pending',errorCode:error?.code??'NETWORK_ERROR'});return
   }
  }
 }))
 return state
}
