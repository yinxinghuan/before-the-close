/**
 * Geometry-only B-view room segment builder. The caller owns images, palette,
 * collision, state and renderer. World units are supplied, never hardcoded.
 * Render layers are N=0, W/E=1, actor=2, S=3. The physical rect remains
 * authoritative; renderRect extends side walls to the north/south caps and
 * adds the foreground south-wall horizontal overhang.
 *
 * @typedef {{x:number,y:number,w:number,h:number}} Rect
 * @typedef {{id:string,side:'N'|'E'|'S'|'W',at:number,width:number}} Door
 * @typedef {{floor:Rect,walls:{back:number,thickness:number,foreground:number},doors:Door[]}} Room
 */

/** Subtract a set of openings from a complete one-dimensional wall edge. */
export function subtractIntervals(start,end,openings){
 if(!(end>start))throw new Error('INVALID_WALL_EDGE')
 const gaps=[...openings].map(([a,b])=>[Math.max(start,a),Math.min(end,b)]).filter(([a,b])=>b>a).sort((a,b)=>a[0]-b[0])
 const out=[];let cursor=start
 for(const [a,b] of gaps){if(a>cursor)out.push([cursor,a]);cursor=Math.max(cursor,b)}
 if(cursor<end)out.push([cursor,end])
 return out
}

/** Create draw rectangles and matching physical opening ranges from one room. */
export function assembleRoom(room){
 const {floor:f,walls:w,doors}=room
 if(!(f.w>0&&f.h>0&&w.back>0&&w.thickness>0&&w.foreground>0))throw new Error('INVALID_ROOM_GEOMETRY')
 const sides=['N','E','S','W']
 const bySide=Object.fromEntries(sides.map(side=>[side,[]]))
 const seen=new Set()
 for(const door of doors){
  if(!sides.includes(door.side)||!Number.isFinite(door.at)||!(door.width>0)||seen.has(door.id))throw new Error('INVALID_DOOR')
  seen.add(door.id)
  const a=door.at-door.width/2,b=door.at+door.width/2
  const lo=door.side==='N'||door.side==='S'?f.x:f.y
  const hi=door.side==='N'||door.side==='S'?f.x+f.w:f.y+f.h
  if(a<lo||b>hi)throw new Error('DOOR_OUTSIDE_EDGE')
  bySide[door.side].push([a,b,door.id])
 }
 const horizontal=(side,y,h)=>subtractIntervals(f.x,f.x+f.w,bySide[side]).map(([a,b])=>({side,rect:{x:a,y,w:b-a,h},start:a,end:b}))
 const vertical=(side,x)=>subtractIntervals(f.y,f.y+f.h,bySide[side]).map(([a,b])=>({side,rect:{x,y:a,w:w.thickness,h:b-a},start:a,end:b}))
 const physicalSegments=[
  ...horizontal('N',f.y-w.back,w.back),
  ...vertical('W',f.x-w.thickness),
  ...vertical('E',f.x+f.w),
  ...horizontal('S',f.y+f.h-w.foreground,w.foreground+w.thickness),
 ]
 const segments=physicalSegments.map(segment=>{
  const {side,start,end,rect}=segment
  const left=side==='S'&&start===f.x?w.thickness:0
  const right=side==='S'&&end===f.x+f.w?w.thickness:0
  const top=(side==='W'||side==='E')&&start===f.y?w.back:0
  const bottom=(side==='W'||side==='E')&&end===f.y+f.h?w.thickness:0
  return {...segment,renderLayer:side==='N'?0:side==='S'?3:1,renderRect:{...rect,x:rect.x-left,y:rect.y-top,w:rect.w+left+right,h:rect.h+top+bottom}}
 })
 const openings=doors.map(door=>{
  const start=door.at-door.width/2,end=door.at+door.width/2
  const rect=door.side==='N'?{x:start,y:f.y-w.back,w:door.width,h:w.back}
   :door.side==='S'?{x:start,y:f.y+f.h-w.foreground,w:door.width,h:w.foreground+w.thickness}
   :door.side==='W'?{x:f.x-w.thickness,y:start,w:w.thickness,h:door.width}
   :{x:f.x+f.w,y:start,w:w.thickness,h:door.width}
  return {id:door.id,side:door.side,start,end,rect}
 })
 return {floor:{...f},segments,openings}
}
