# 体验能力档案

空间、素材和剧情跑通后，仍可能遗漏开场、人物生活、声音、历史、存档或收束。每个项目在编码前创建 `doc/experience-capabilities.json`，发布前再次更新并运行校验器。档案的作用是让能力成为明确的产品选择，而不是让未实现功能静默消失。

复制 `assets/experience-capability-profile.json` 作为起点。模板所有能力默认 `planned`、证据为空；目标模式只是可编辑示例，不是已实现声明。每项通过目标项目运行验证后才提升为 `implemented`，禁止沿用示例证据路径。`gameProfile` 描述实际产品，不要为了通过校验而降低时长、关闭连续性或把已有 NPC 写成不存在。

## 三层能力

### 默认核心

这类能力由空间叙事壳默认提供；不适用时必须有真实产品理由：

- 新旅程开场和恢复不重播；
- 直接探索、接近、主操作和真实转场；
- 与玩家动作对应的加载、恢复与错误反馈；
- 与移动、剧情事件和全局静音一致的声音层；
- 本次体验的完成、停止和回访合同；
- 至少一种经过声明的持久化模式。

### 按画像触发

- `physicalNpc=true`：必须有 `npcWorldLife`。岗位角色可原地值守，但接近时仍面向玩家；有巡游职责的角色必须真实移动并共享碰撞/交互位置。
- `conversation=true`：必须有分阶段对话。若 `expectedMinutes >= 30` 或 `crossSessionContinuity=true`，还必须有持久对话历史，至少保存最近数轮或稳定摘要。
- `inventory=true`：必须有图像识别层；可复用已准入头像、物件和资料缩略图，纯文字列表不足以达到参考体验层级。
- `directMovement=true`：必须有由实际位移驱动的脚步或明确的创意静默理由。计时循环音不合格。
- `sessionShape="chapter"`：必须有章节收束；不强制电影过场，但必须形成清楚的情绪与结果终点。`ongoing` 则必须定义自然停止和回访入口。
- `crossDevice=true`：持久化必须为账号或平台云端模式，本地浏览器存储不能冒充跨设备恢复。
- `compareBranches=true` 或 `sharedDevice=true`：必须采用多旅程目录；否则单旅程可以是明确且合格的模式。

### 可替换策略

自由交谈可以是 `authored`、`hybrid` 或 `generated`。模型生成不是高保真的默认条件：作者模式可以完全合格。选择 `hybrid/generated` 时才要求上下文范围、权威写入边界、超时和作者保底；不得为了展示 AI 而牺牲人物稳定性。

## 发布状态

每项能力使用以下状态：

- `implemented`：实现并有真实证据；
- `not-applicable`：产品画像确实不需要，并写明理由；
- `planned`：尚未完成，只允许在开发阶段存在。

`releaseTarget="high-fidelity"` 时，画像触发的能力不能是 `planned` 或 `not-applicable`。证据至少包含测试、真实 renderer 截图或运行轨迹之一；只写“代码已完成”不算证据。

## 使用

```bash
node /path/to/build-spatial-story-game/scripts/validate-experience-profile.mjs \
  /absolute/path/to/game/doc/experience-capabilities.json
```

校验器只证明项目没有静默省略能力，不能替代视觉签收、新玩家理解或平台服务验证。
