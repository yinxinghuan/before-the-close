# 校验清单格式 v1

JSON 从游戏当前布局与实体清单导出，数值单位为世界像素。无网络依赖。

```
{
  "version": 1,
  "coordinateAnchor": "top-left",
  "world": {"width": 384, "height": 576, "step": 4},
  "actor": {"width": 9, "height": 15},
  "assets": [{"id":"floor", "path":"public/art/floor.png"}],
  "scenes": [{
    "id":"room", "background":"floor",
    "walkRegion":{"x":16,"y":32,"w":200,"h":300},
    "spawn":{"x":100,"y":200},
    "obstacles":[{"x":16,"y":32,"w":40,"h":40}],
    "targets":[
      {"id":"cabinet","approach":{"x":60,"y":80},"states":["closed","open"],"renderedStates":["closed","open"]},
      {"id":"door-n","kind":"door","side":"N","approach":{"x":100,"y":36},"threshold":{"x":100,"y":32},"activation":{"x":80,"y":28,"w":48,"h":40},"states":["open"],"renderedStates":["open"]}
    ]
  }],
  "portals":[]
}
```

`coordinateAnchor` 必须显式写为 `"top-left"` 或 `"foot"`。推荐运行清单直接使用 `top-left`，与 `assets/world.ts`、`assets/grid-pathfinder.mjs` 和 RPG-JS actor position 一致；此时 `spawn / approach / threshold / arrival` 都是人物碰撞矩形左上角。若项目权威状态保存脚点中心，写 `"foot"`，校验器会按 `x - actor.width/2, y - actor.height` 统一换算后再检查。旧清单省略时只为兼容而按 `top-left` 处理，新项目不得省略。

assets 可附 `imageWidth/imageHeight` 以及 `crops:[{x,y,w,h}]`；检查 crop 不越界。工具只检查文件存在，实际 PNG 模式/alpha 由 inspect-assets.py 检查。门禁/剧情解锁条件仍需游戏规则测试。

定义第二个场景后，再向 portals 添加 `{ "id":"door-a", "from":"room", "to":"other", "arrival":{"x":100,"y":36}, "target":"door-n" }`；from/to 均必须是已登记场景，arrival 必须落在目标场景可达地面。`target` 指向目标场景的门。门目标必须同时导出方向、可行走的门槛站位和激活区；检查器使用角色脚点验证 approach、threshold 和 portal arrival 都在同一激活区，防止“远处能触发、走到门口反而失效”。

静态可达性按演员矩形扫过每个网格边，而不只判断下一个网格点。出生点加入网格、接近点/落点连接网格也需无碰撞。实际反例：演员宽2、步长8、厚1的隔墙，两个节点都合法但中间穿墙；v1.7.1 拒绝这种虚假可达。仍采用离散网格与直角连接，可能保守拒绝某些复杂狭窄空间；应调整目标工程采样步长并以真实引擎验证。
