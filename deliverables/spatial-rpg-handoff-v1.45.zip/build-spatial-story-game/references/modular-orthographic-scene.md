# 可独立使用的 B 式正交场景拼装合同

此文档和包内 `assets/orthographic-b/` 参考图足以启动另一个项目；不要要求接收方打开样本游戏仓库。`scene/actor/props` 是 B 视角样本，`assembled-street/assembled-doorway` 是实际运行的独立墙、地、门、人物与家具装配证据。它们不是可直接改名复用的题材素材。详细装配与失败准入见 [wall-door-assembly.md](wall-door-assembly.md)。

## 素材最小集合

每种可探索室内空间至少准备并登记独立的 `floor`、`north-wall`、`side-wall`、`door/threshold`、`furniture`；需要南侧遮挡时再加 `foreground-wall`。地板与墙面必须来自不同源文件；整张房间概念图只能作为构图参考，不能充当运行背景。可重复小地砖可平铺，独特的大地面也可是一块独立 ground plate，不能强迫所有主场景使用小图平铺。门洞是墙段之间真实留出的空间，门叶/门槛独立实例；开门状态必须对应碰撞与转场。

所有正式素材走当前平台媒体服务；记录每件素材的请求 ID、公开参考 URL、完整提示词、结果 URL、源尺寸、SHA256、alpha/裁切和准入状态。服务生成成功仅代表候选。背景图含整间房、墙图混入地砖、图集烘焙棋盘格、角色方向/身份串格时必须拒绝。长方形墙板或地面允许不透明满幅图；不规则人物、椅背和可变物件需真实透明通道或经授权、可复验的准备流程。

## 一个布局同时驱动四件事

```ts
type Side = 'N' | 'E' | 'S' | 'W'
type RoomLayout = {
  floor: {x:number;y:number;w:number;h:number}
  walls: {back:number;thickness:number;foreground:number}
  doors: Array<{id:string;side:Side;at:number;width:number;to:string;arrival:{x:number;y:number}}>
  furniture: Array<{id:string;art:string;footprint:{x:number;y:number;w:number;h:number};foot:{x:number;y:number}}>
  traces?: Array<{id:string;art:string;visual:{x:number;y:number;w:number;h:number};footprint?:{x:number;y:number;w:number;h:number};support?:string}>
}
```

1. 地板只绘制在 `floor` 矩形中。世界像素/Tile 比例固定；同类地砖不因位于画面上方而缩小。
2. 对每条边，从 `doors` 的开口区间减去墙的完整区间，得到一组墙段；画墙面、墙脚与短端面。不能在墙图上画一个门，再单独维护不相干的碰撞开口。
3. 每个门洞的位置、宽度、门槛、寻路出口和目标场景到达点来自同一条 door 记录。门关闭时按状态加入阻挡，打开后仍保留真实墙边。
4. 家具图按 `foot` 排序；碰撞使用 `footprint`，不是图片透明边界。人物只以脚底和 hitbox 移动。北墙与远侧家具在人物后，南侧前景墙在人物前；可穿行家具按脚底深度排序。
5. `traces` 表达非关键使用痕迹。落地鞋和清洁底座锚定地面，杯子、工具和折叠布料可用 `support` 锚定家具上表面；只有真实占地阻挡时才写 `footprint`。家具移动或缩放时，同步重算其支撑物件，不能留下悬空摆放。
6. 图源 ID、实际文件 hash、世界尺寸、缩放、脚底、碰撞、门净宽和场景入口写入运行清单；检查器从运行数据导出，不能另造一套“通过检查用”的清单。

## B 视角判定

- `assets/orthographic-b/scene.png`：地面网格两组线保持平行，没有消失点或越远越小的同类物件；顶部/短立面可见，但不是 45° 等轴测。
- `assets/orthographic-b/actor.png`：每个朝向有同一脚底基线；朝下也能看到头顶，面部不是正面立绘。新项目可以改变身材和服装，不改变观看关系。
- `assets/orthographic-b/props.png`：柜顶和短正面共存，门开启状态共享轮廓与脚点。新项目物件也要和场景地板同像素密度、同光向。

这些图在本包中，不依赖网络或样本目录。三张原始视角样本的 SHA256 分别为 `scene 37a4a0a6d1b6e33eae5a794f214973c291e47f9ce8e8e2e78a66707f03174359`、`actor 7e70f17d07eb2384e253635fd32be641c5986b260828ac0167659b61b9db3842`、`props 9c8878fc26ace493e8b8a9b289056df28c692290a61d8fb1cf5013992fef4cd3`。

## 特写例外

肖像、资料放大、关键物件近景和过场可用正面/侧面/局部镜头，但在清单里标为 `closeup`，只进入阅读/特写界面。不能把特写图放进可行走世界充当人物、墙或道具；同一物件的身份、材质和可见状态仍要对应。

## 必须留下的真实验收证据

在 390×844、320×568 运行真实 renderer，分别拍下：空房墙地接缝、穿门时的墙段开口、人物靠北墙/南墙和家具前后、四向走停、两个场景往返、特写关闭回到原位置。另检查图像源文件实际分离、alpha 与物件边界、世界碰撞和可见墙/门一致。只看概念图或通过脚本不算验收。
