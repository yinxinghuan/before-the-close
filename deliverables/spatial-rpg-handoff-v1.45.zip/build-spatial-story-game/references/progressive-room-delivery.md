# 动态房间的渐进交付合同

适用于用户提出一个新房间后，正式地面、家具和小物仍在平台媒体服务生成的阶段。目标是尽快交付可探索空间，同时保证高保真素材完成时不会改变玩家已经理解的空间。

## 两条完成时间

- `brief → shell interactive`：房间 ID、边界、出生点、出口、功能槽位、接近点和占地已冻结；可达检查通过，玩家可以进入。
- `brief → high-fidelity accepted`：正式素材经生成、处理、合成画面两轮签收后进入相同槽位。

两条时间都要记录。高保真完成时间不能冒充玩家首次可进入时间；已有清单的页面启动耗时也不能冒充从需求到骨架完成的制作时间。

## 同一空间真源

虚空状态与完成状态必须共享稳定 scene ID、出生点、出口 ID/锚点、槽位 ID 和 footprint。虚空中的体积占位不是随意装饰，而是最终物件的真实空间承诺。素材完成后只替换视觉、状态图和必要的脚点深度数据，不移动出口、扩大/缩小占地或把玩家送回出生点。

复制 `assets/progressive-room-contract.json` 并替换为项目真实数据，运行：

```bash
node scripts/validate-progressive-room.mjs progressive-room-contract.json
```

检查器拒绝：缺少稳定 ID、虚空不可进入、出生点变化、出口变化、槽位增删、footprint 漂移，以及把实现信息写进玩家文案。它不证明真实路线可达、媒体任务可恢复或最终画面合格；仍需运行 world validator、浏览器交互和最终合成画面签收。

## 玩家看到什么

持续状态提示不挡移动，使用 `role=status`，只回答：世界仍在形成、玩家现在可以做什么。推荐表达是“世界正在加载”“你可以先四处看看”。不要显示碰撞、路线、footprint、媒体任务、后台处理、请求 ID、坐标、画布尺寸或制作测速。没有真实任务统计时不显示百分比、完成件数或倒计时。

界面可用程序网格、轮廓体积和题材中性的微弱动效表达未完成，但不能让占位物比正式物件更像可拾取奖励。`prefers-reduced-motion` 下取消循环位移和闪烁，保留状态文字与静态轮廓。

## 任务与失败

正式图像使用 `alteru-media-service` 的稳定 session/request 合同。持久化每个槽位的任务状态和结果身份；模糊网络失败复用同一 request ID，结构化终止失败才创建新请求。单件失败保留该槽位占位及可恢复入口，不锁住整房。页面重载后从持久任务恢复，不能把“正在生成”直接改成失败或重新创建全部任务。

交付包已包含 `assets/alteru-media-service.ts`：需要持久恢复时先用 `submitImageMedia` 保存 task ID，再用 `waitForMediaTask` 等待；简单内存等待可用 `generateImageMedia`；`getMediaTask` 恢复既有任务，`MediaServiceError.retryable` 区分模糊失败与终止失败，`fitMediaImageSize` 约束平台尺寸。调用方生成一次 request ID 并连同 session ID、最终 task、媒体 URL、尺寸、时间和下载文件 SHA 写入项目报告。`edit` 只接受一张平台可访问的公网绝对参考 URL；客户端不包含长期凭据，也不得自行把秘密打进 Vite bundle。

素材必须逐槽位经历 `generated → processed → integrated → visual-reviewed → accepted`。只有 `accepted` 可以替换占位。替换前后在同一角色位置截图，检查投影、比例、支撑、遮挡和路线；完成态仍不得向玩家显示内部任务信息。

复制 `assets/progressive-media-runtime.mjs` 作为任务恢复内核。每个槽位持久化 `taskId + requestId + phase`；页面启动时先恢复本地 `ready`，只查询未完成任务。任务返回的两项身份必须同时匹配后才能替换素材。终止失败只让该槽位保持占位，网络不确定只保留 `pending`，两者都不阻塞移动和其余槽位。

本地浏览器若被平台的 Origin 白名单拒绝，应由开发服务器提供窄范围同源代理；正式平台域名仍直连平台媒体服务。不要在产品 UI 中显示 `ORIGIN_NOT_ALLOWED`、任务 ID、接口地址或代理状态。

真实浏览器验收至少覆盖：

1. 清空房间媒体存档后，骨架先于全部素材可探索。
2. 多个已接受任务可以逐槽位替换，不要求固定返回顺序。
3. 刷新后已经接受的槽位立即恢复，不重新提交，也不重复查询。
4. 单件结构化失败保留它自己的占位，其余槽位继续完成。
5. `320×568` 与 `390×844` 的最终合成画面没有实现信息、错位或路线变化。
