#!/usr/bin/env python3
"""Audit source-to-world scale for orthographic actors, walls and props.

This does not judge pose, perspective or visual quality. It catches source art
being stretched, adult height drift and table-to-character scale drift.
"""
import argparse
import json
import sys
from pathlib import Path

from PIL import Image


def measure(spec: dict, root: Path) -> list[str]:
    errors: list[str] = []
    actors: dict[str, float] = {}
    for actor in spec.get('actors', []):
        name = actor['id']
        image = Image.open(root / actor['path']).convert('RGBA')
        cell = actor.get('cell', [0, 0, image.width, image.height])
        x, y, w, h = cell
        if x < 0 or y < 0 or w <= 0 or h <= 0 or x + w > image.width or y + h > image.height:
            errors.append(f'{name}: cell outside source image')
            continue
        visible = image.crop((x, y, x + w, y + h)).getchannel('A').point(lambda a: 255 if a > 200 else 0).getbbox()
        if not visible:
            errors.append(f'{name}: no visible opaque silhouette')
            continue
        world_w, world_h = actor['displayWorld']
        if abs(world_w / w - world_h / h) / max(world_w / w, world_h / h) > 0.02:
            errors.append(f'{name}: actor cell stretched in world')
        actors[name] = (visible[3] - visible[1]) * world_h / h
        print(f'actor {name}: visible height {actors[name]:.2f} world units, source bbox {visible}')
    reference = spec.get('adultReference')
    if reference and reference in actors:
        tolerance = spec.get('adultHeightTolerance', 0.12)
        for name in spec.get('adults', []):
            if name in actors and abs(actors[name] / actors[reference] - 1) > tolerance:
                errors.append(f'{name}: adult visible height differs from {reference} by more than {tolerance:.0%}')
    group_scales: dict[str, tuple[str, float]] = {}
    for wall in spec.get('walls', []):
        name = wall['id']
        image = Image.open(root / wall['path'])
        crop = wall.get('sourceCrop', [0, 0, image.width, image.height])
        x, y, w, h = crop
        if x < 0 or y < 0 or w <= 0 or h <= 0 or x + w > image.width + .01 or y + h > image.height + .01:
            errors.append(f'{name}: crop outside source image')
            continue
        world_w, world_h = wall['displayWorld']
        sx, sy = world_w / w, world_h / h
        print(f'wall {name}: source {w:.2f}x{h:.2f} -> world {world_w:.2f}x{world_h:.2f}, scale {sx:.4f}/{sy:.4f}')
        if abs(sx - sy) / max(sx, sy) > 0.02:
            errors.append(f'{name}: wall source stretched; crop or redesign instead')
        group = wall.get('scaleGroup')
        if group:
            if group in group_scales:
                earlier, base = group_scales[group]
                if abs(sx - base) / max(sx, base) > 0.02:
                    errors.append(f'{name}: wall texture scale differs from {earlier} in group {group}')
            else:
                group_scales[group] = (name, sx)
    for prop in spec.get('props', []):
        name = prop['id']
        image = Image.open(root / prop['path']).convert('RGBA')
        x, y, w, h = prop.get('sourceCrop', [0, 0, image.width, image.height])
        if x < 0 or y < 0 or w <= 0 or h <= 0 or x + w > image.width or y + h > image.height:
            errors.append(f'{name}: prop crop outside source image')
            continue
        world_w, world_h = prop['displayWorld']
        sx, sy = world_w / w, world_h / h
        print(f'prop {name}: source {w:.2f}x{h:.2f} -> world {world_w:.2f}x{world_h:.2f}, scale {sx:.4f}/{sy:.4f}')
        if abs(sx - sy) / max(sx, sy) > 0.02:
            errors.append(f'{name}: prop source stretched; preserve its projection')
        width_range = prop.get('visibleWidthToAdultRange')
        if width_range and reference in actors:
            visible = image.crop((x, y, x + w, y + h)).getchannel('A').point(lambda a: 255 if a > 200 else 0).getbbox()
            if not visible:
                errors.append(f'{name}: no visible opaque prop')
            else:
                ratio = (visible[2] - visible[0]) * sx / actors[reference]
                if not width_range[0] <= ratio <= width_range[1]:
                    errors.append(f'{name}: visible width / {reference} height {ratio:.2f} outside {width_range}')
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('spec', type=Path)
    parser.add_argument('--root', type=Path, default=Path('.'))
    args = parser.parse_args()
    errors = measure(json.loads(args.spec.read_text()), args.root)
    for error in errors:
        print('FAIL:', error, file=sys.stderr)
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
