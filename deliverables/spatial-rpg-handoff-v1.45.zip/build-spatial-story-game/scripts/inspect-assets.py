#!/usr/bin/env python3
"""Read-only PNG admission report; never modifies the input."""
import argparse, json
from PIL import Image
p=argparse.ArgumentParser();p.add_argument('paths',nargs='+');p.add_argument('--require-alpha',action='store_true');a=p.parse_args();rows=[];failed=False
for path in a.paths:
    with Image.open(path) as im:
        alpha=im.getchannel('A') if 'A' in im.getbands() else None
        bounds=alpha.point(lambda x:255 if x>200 else 0).getbbox() if alpha else None
        transparent=bool(alpha and alpha.getextrema()[0]==0 and alpha.getextrema()[1]>0)
        rows.append(dict(path=path,size=im.size,mode=im.mode,alpha=alpha.getextrema() if alpha else None,opaqueBounds=bounds,hasTransparentPixels=transparent))
        failed|=a.require_alpha and not transparent
print(json.dumps(rows,ensure_ascii=False,indent=2))
raise SystemExit(1 if failed else 0)
