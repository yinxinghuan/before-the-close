#!/usr/bin/env node
import fs from 'node:fs'
import path from 'node:path'

const input=process.argv[2]
if(!input){console.error('Usage: node validate-experience-profile.mjs /path/to/experience-capabilities.json');process.exit(2)}
const file=path.resolve(input)
let profile
try{profile=JSON.parse(fs.readFileSync(file,'utf8'))}catch(error){console.error(`FAIL: cannot read profile: ${error.message}`);process.exit(2)}

const errors=[]
const requireValue=(condition,message)=>{if(!condition)errors.push(message)}
requireValue(profile.schemaVersion===1,'schemaVersion must be 1')
requireValue(['prototype','playable','high-fidelity'].includes(profile.releaseTarget),'releaseTarget must be prototype, playable, or high-fidelity')
const game=profile.gameProfile??{},modes=profile.modes??{},capabilities=profile.capabilities??{},decisions=profile.decisions??{}
requireValue(['chapter','ongoing'].includes(game.sessionShape),'gameProfile.sessionShape must be chapter or ongoing')
requireValue(Number.isFinite(game.expectedMinutes)&&game.expectedMinutes>0,'gameProfile.expectedMinutes must be a positive number')
for(const key of ['crossSessionContinuity','crossDevice','directMovement','physicalNpc','conversation','inventory','compareBranches','sharedDevice','creativeSilence'])requireValue(typeof game[key]==='boolean',`gameProfile.${key} must be boolean`)
requireValue(['single','multiple'].includes(modes.journeys),'modes.journeys must be single or multiple')
requireValue(['none','local-session','account-cloud'].includes(modes.persistence),'modes.persistence must be none, local-session, or account-cloud')
requireValue(['authored','hybrid','generated'].includes(modes.conversation),'modes.conversation must be authored, hybrid, or generated')

const release=profile.releaseTarget==='high-fidelity'
function requireCapability(id,reason,allowNotApplicable=false){
 const item=capabilities[id]
 if(!item){errors.push(`${id}: missing (${reason})`);return}
 if(!['implemented','not-applicable','planned'].includes(item.state)){errors.push(`${id}: invalid state`);return}
 if(release&&(item.state==='planned'||(item.state==='not-applicable'&&!allowNotApplicable)))errors.push(`${id}: high-fidelity release requires implemented (${reason})`)
 if(item.state==='implemented'&&(!Array.isArray(item.evidence)||item.evidence.length===0))errors.push(`${id}: implemented capability needs evidence`)
 if(item.state==='not-applicable'&&!(typeof item.reason==='string'&&item.reason.trim()))errors.push(`${id}: not-applicable needs a reason`)
}
for(const [id,reason] of Object.entries({opening:'new journey and resume entry',exploration:'spatial story core loop',loadingRecovery:'player-facing wait and recovery',closure:'completion or return contract'}))requireCapability(id,reason)
requireCapability('audioLayers','music/event/mute contract',game.creativeSilence)
requireCapability('persistence','declared save boundary',!game.crossSessionContinuity&&modes.persistence==='none')
if(game.physicalNpc)requireCapability('npcWorldLife','physical NPCs exist')
if(game.conversation){
 requireCapability('stagedConversation','conversation exists')
 if(game.expectedMinutes>=30||game.crossSessionContinuity)requireCapability('conversationHistory','long or cross-session conversation')
}
if(game.inventory)requireCapability('inventoryVisuals','inventory exists')
if(game.directMovement&&!game.creativeSilence)requireCapability('distanceFootsteps','direct movement needs movement-grounded sound')
if(game.crossDevice)requireValue(modes.persistence==='account-cloud','crossDevice requires account-cloud persistence')
if(game.compareBranches||game.sharedDevice)requireValue(modes.journeys==='multiple','branch comparison or shared-device use requires multiple journeys')
if(modes.journeys==='single')requireValue(typeof decisions.journeys==='string'&&decisions.journeys.trim(),'single journey mode needs an explicit product decision')
if(modes.persistence!=='none')requireValue(typeof decisions.persistence==='string'&&decisions.persistence.trim(),'persistence mode needs an explicit boundary decision')
if(modes.conversation==='authored')requireValue(typeof decisions.conversation==='string'&&decisions.conversation.trim(),'authored conversation needs an explicit product decision')
if(modes.conversation!=='authored'){
 for(const id of ['generatedConversationBoundary','generatedConversationFallback'])requireCapability(id,'hybrid/generated conversation safety')
}

if(errors.length){for(const error of errors)console.error(`FAIL: ${error}`);process.exit(1)}
console.log(JSON.stringify({passed:true,releaseTarget:profile.releaseTarget,sessionShape:game.sessionShape,journeys:modes.journeys,persistence:modes.persistence,conversation:modes.conversation,capabilities:Object.keys(capabilities).length}))
