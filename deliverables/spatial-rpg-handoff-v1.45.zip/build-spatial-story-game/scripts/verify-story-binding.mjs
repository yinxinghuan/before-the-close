// Node >=22.18, --experimental-transform-types. No npm or game imports.
import {test} from 'node:test'
import assert from 'node:assert/strict'
import {resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
const moduleUrl=(argument,fallback)=>argument?pathToFileURL(resolve(argument)):new URL(fallback,import.meta.url)
const {compileSpatialBinding}=await import(moduleUrl(process.argv[2],'../assets/spatial-binding.ts').href)
const {dryRunSpatialAttachment}=await import(moduleUrl(process.argv[3],'../assets/spatial-attachment.ts').href)
// Authoring data only. Multiple rooms share a story location; action IDs can
// repeat across scenes. This deliberately differs from a one-room-per-node game.
function fixture(){
 const story={id:'binding-specimen',initialMap:[{id:'archive',current:true},{id:'courtyard'}],characters:[{id:'keeper'}],domainRules:{rules:[{id:'inspect',effects:[]},{id:'stairs-up',effects:[]},{id:'stairs-down',effects:[]},{id:'leave',effects:[{type:'map',nodeId:'courtyard'}]},{id:'return',effects:[{type:'map',nodeId:'archive'}]}]}}
 const scenes=[{id:'lower',storyLocationId:'archive',spawn:{x:10,y:10}},{id:'upper',storyLocationId:'archive',spawn:{x:10,y:10}},{id:'outside',storyLocationId:'courtyard',spawn:{x:10,y:10}}]
 const entity=(id,scene,actions)=>({id,scene,position:{x:20,y:20},approach:{x:20,y:25},states:['ready'],actions})
 const world={version:1,cartridgeId:story.id,mapVersion:'rooms-1',actionScope:'scene',interactionDistance:16,scenes,entities:[entity('desk','lower',['inspect','stairs-up','leave']),entity('shelf','upper',['inspect','stairs-down']),entity('gate','outside',['return'])],characters:[{id:'keeper',kind:'physical',entities:['desk']}],portals:[{actionId:'stairs-up',scene:'upper',position:{x:10,y:10}},{actionId:'stairs-down',scene:'lower',position:{x:10,y:10}},{actionId:'leave',scene:'outside',position:{x:10,y:10}},{actionId:'return',scene:'lower',position:{x:10,y:10}}]}
 const walk=(_scene,p)=>p.x>=0&&p.y>=0&&p.x<80&&p.y<80
 const save=(location='archive')=>({version:17,cartridgeId:story.id,map:story.initialMap.map(n=>({...n,current:n.id===location})),characters:[{id:'keeper'}],inventory:[{id:'seal',count:2}],finale:{phase:'open'},history:[{text:'Authored history'}]})
 return {story,world,walk,save,compile:()=>compileSpatialBinding(story,world,walk)}
}
test('same story node can have distinct physical rooms and local repeated actions',()=>{
 const f=fixture(),b=f.compile();assert.throws(()=>b.locate(f.save()),/AMBIGUOUS_SPATIAL_SCENE/)
 assert.equal(b.locate(f.save(),'upper'),'upper');assert.equal(b.targetFor('inspect','lower'),'desk');assert.equal(b.targetFor('inspect','upper'),'shelf')
 assert.throws(()=>b.targetFor('inspect'),/AMBIGUOUS_ACTION_TARGET/)
 assert.deepEqual(b.assertTransition(f.save(),f.save(),'stairs-up','lower'),{scene:'upper',position:{x:10,y:10}})
})
test('location transitions require the matching authored portal and source',()=>{
 const f=fixture(),b=f.compile();assert.equal(b.assertTransition(f.save(),f.save('courtyard'),'leave','lower').scene,'outside')
 assert.throws(()=>b.assertTransition(f.save(),f.save('courtyard'),'inspect','lower'),/UNADMITTED_STORY_TRANSITION/)
 assert.throws(()=>b.assertTransition(f.save(),f.save('courtyard'),'leave','upper'),/PORTAL_SOURCE_MISMATCH/)
 f.world.portals.find(p=>p.actionId==='leave').scene='upper';assert.throws(f.compile,/PORTAL_RULE_MISMATCH/)
})
test('interaction admission rejects wrong scene, target and blocked or distant feet',()=>{
 const b=fixture().compile();assert.equal(b.admits('inspect','desk','lower',{x:20,y:25}),true)
 for(const [target,scene,p] of [['shelf','lower',{x:20,y:25}],['desk','upper',{x:20,y:25}],['desk','lower',{x:70,y:70}],['desk','lower',{x:-1,y:25}]])assert.equal(b.admits('inspect',target,scene,p),false)
})
test('unmapped rules, characters, ambiguous bindings and invalid arrivals fail',()=>{
 for(const [edit,pattern] of [
  [f=>f.story.domainRules.rules.push({id:'invented',effects:[]}),/UNBOUND_STORY_ACTION/],
  [f=>f.world.characters[0].id='other',/UNKNOWN_STORY_CHARACTER/],
  [f=>f.world.entities[0].actions.push('inspect'),/DUPLICATE_ACTION_BINDING/],
  [f=>f.world.portals[0].position.x=100,/INVALID_PORTAL_BINDING/],
 ]){const f=fixture();edit(f);assert.throws(f.compile,pattern)}
})
test('compiled configuration and returned arrival cannot mutate the authoring source',()=>{
 const f=fixture(),b=f.compile();f.world.portals[0].position.x=75
 const arrival=b.assertTransition(f.save(),f.save(),'stairs-up','lower');arrival.position.x=77
 assert.equal(b.assertTransition(f.save(),f.save(),'stairs-up','lower').position.x,10)
})
test('dry-run retains the whole save but never mutates or enrolls it',()=>{
 const f=fixture(),save=f.save(),original=structuredClone(save),b=f.compile()
 const result=dryRunSpatialAttachment(save,b,{supportedSaveVersion:17,resume:{sceneId:'upper',position:{x:11,y:12}},readySceneIds:['upper'],readyCharacterIds:['keeper']})
 assert.equal(result.status,'dry-run-ready');assert.deepEqual(result.candidate.story,original)
 result.candidate.story.inventory[0].count=0;result.candidate.story.history[0].text='changed';assert.deepEqual(save,original)
 assert.deepEqual(result.candidate.spatial.resume,{sceneId:'upper',position:{x:11,y:12}})
})
test('dry-run fails closed for schema, assets and missing explicit room',()=>{
 const f=fixture(),b=f.compile(),base={supportedSaveVersion:17,resume:{sceneId:'upper',position:{x:11,y:12}},readySceneIds:['upper'],readyCharacterIds:['keeper']}
 for(const [patch,code] of [[{supportedSaveVersion:16},'STORY_SCHEMA_REQUIRES_ADAPTER'],[{readySceneIds:[]},'SCENE_ASSETS_NOT_ADMITTED'],[{readyCharacterIds:[]},'CHARACTER_PRESENTATION_NOT_ADMITTED'],[{resume:undefined},'AMBIGUOUS_SPATIAL_SCENE']]){
  const r=dryRunSpatialAttachment(f.save(),b,{...base,...patch});assert.equal(r.status,'not-ready');assert.equal(r.candidate,null);assert.ok(r.issues.some(i=>i.code===code))
 }
})
