---
name: build-stateful-story-game
description: "Guide a user from a world idea to a standalone, persistent AI role-playing game source project using one of two bundled personal-world engines, and evaluate asynchronous multiplayer/shared-world extensions against a proven authority contract. Use for AI RPGs, dialogue adventures, open-world exploration, emotional guided journeys, relationship simulations, continuous worlds, numeric narrative systems, companions, treasures, danger encounters, generated scene art, fixed 4:5 visual stages, dynamic endings, or shared-world RPG planning. Produces verified source and handoff-ready artifacts while remaining independent of the receiving team's deployment system."
---

# Build AI Role-Playing Game

Create one independent RPG project from a product conversation. Reuse a bundled deterministic engine and author the world through a paired Chinese/English StoryCartridge. Deliver verified source, not a `?cartridge=` link and not a deployment.

## Hard deployment boundary

Read [references/deployment-boundary.md](references/deployment-boundary.md) before artifact handoff.

- Stop at verified source, `dist/`, poster, notices, documentation, UUID, and a handoff manifest.
- Never edit `games.json`, run a catalog migration, call internal deployment scripts, configure GitHub Pages, upload to an internal CDN, or assert that a game is online.
- If the receiving workspace has its own publisher Skill, hand the verified project to it as a separate task. Do not infer its hosting contract.

## Select one bundled engine

Read [references/template-selection.md](references/template-selection.md) before implementation.

### Stateful Conversation (`stateful`)

Choose this for long-form reading, persistent exploration, rich world/inventory panels, and images placed inline with events. The frozen engine is `assets/stateful-story-template/`.

### Cinematic Civic (`cinematic`)

Choose this for one new 4:5 image per successful step, less reading, staged action/result/decision flow, milestone markers, and a fixed visual canvas. The frozen engine is `assets/cinematic-story-template/`; video transport is intentionally disabled pending separate authorization. Read [references/cinematic-contract.md](references/cinematic-contract.md).

Use one shell per exported product unless the user explicitly requests an A/B test. Both engines preserve the same core state contracts. Do not pick the cinematic engine merely because a game uses generated images; pick it when image-per-step pacing is the product promise.

### Asynchronous shared world

Read [references/multiplayer-boundary.md](references/multiplayer-boundary.md) before promising multiplayer. This version records the authority, API, conflict, grant, identity, Remix-isolation, personal-save-envelope, and media-attachment contracts learned from City of Tides plus the deployed Neighbor Help validation experiment. `assets/action-authority-experiment/` is now a runnable, optional experiment layer for single-player governed actions and asynchronous shared-world transactions; it is not installed into either personal engine by default. It mechanically covers normal concurrency plus response loss after commit, duplicate submission, cursor reconnect, private-save/ack failure, ruleset upgrade and post-verification identity claims. Neighbor Help also passed a fresh real Telegram `claim → reentry → complete` transaction after its committed-outcome bridge. The remaining production gates are backend-verifiable platform signatures, two real authenticated accounts/devices, receiving-runtime multi-instance transactions and real personal-cloud-save fault injection. Do not call the experiment a frozen generic multiplayer engine until those external gates pass.

Create an empty working copy. Never edit installed Skill assets:

```bash
node <skill>/scripts/prepare-engine.mjs \
  --mode <stateful|cinematic> \
  --target <workspace>/.story-engine
```

Later commands may use this path. For smoke tests, `scripts/scaffold.mjs` can read the bundled engine directly. Use a different `--template` only when the receiving team explicitly verifies a newer engine checkout.

## Workflow

### 1. Interview in product language

Read [references/interview.md](references/interview.md). Ask no more than three short questions at a time. Confirm:

1. who the player is and what freedom feels enjoyable;
2. guided or open-world structure;
3. exactly three visible stats, one meaningful resource/treasure, and playable failure consequences;
4. companion and relationship expectations;
5. danger cadence and whether physical combat is absent, rare, or allowed;
6. whether the player wants accumulated reading or image-per-step pacing;
7. visual and audio character, including what the world, its major regions and its important consequences should sound like.

Do not ask the user about reducers, schemas, prompts, APIs, UUIDs, hosting, or deployment.

Write `doc/world-brief.json` from `assets/world-brief.example.json`, then run:

```bash
node <skill>/scripts/validate-brief.mjs <game>/doc/world-brief.json
```

### 2. Lock the template and design contract

For finite campaigns or reports of premature endings, read [references/campaign-pacing.md](references/campaign-pacing.md). Define substantive milestone dependencies and distinguish checkpoints from true endings; verify the shortest legal completion route. Fixed turn counts and prompt-only requests to “make it longer” are not substitutes. Dynamic episodes are an optional, separately verified capability, not an automatic property of either template.

State the chosen mode and why in one sentence. Create:

```text
doc/requirements.md
doc/visual.md
```

Define the opening, player freedom, three stats, companions, inventory ownership, danger, failure/recovery, chapter boundaries versus true endings, restart, image cadence, audio, bilingual behavior, and mobile/desktop layouts. The opening is progressive disclosure, not a synopsis: begin with one ordinary activity, one disruption and one human response, then reveal routes and lore through player actions. For generated or recorded sound, read [references/audio-direction.md](references/audio-direction.md): ordinary reading uses sparse regional A beds, while the somewhat fuller B score is reserved for durable reveals/relationship turns/chapter boundaries, pauses A, and observes a three-minute cooldown. All ambience and event sounds are one-shot: ambience plays once per location visit, and a short cue plays once per committed event; mute, page resume, rerender, restore and reconnect never restart a completed sound. Keep ambience, signature events and deterministic feedback separate. Routine prose, energy/standing cards and image completion stay silent; one ordinary choice gets one quiet acknowledgement, and only a separately meaningful durable consequence may add another cue. Never impose a fixed five-turn ending.

For `cinematic`, also define:

- a 4–7 beat player-lived opening sequence: ordinary arrival → visible disruption → concrete evidence/voice → named debut only after visible form/action → immediate conflict → choices;
- single-direction opening pagination, with choices, free input and numeric shortcuts hidden until the final authored beat;
- the `decision -> resolving -> result -> decision` information order;
- 4:5 stage composition and safe region;
- one-image-per-step budget;
- caption length/pagination and speaker identity;
- campaign arc, dynamic-ending boundaries, and milestone-video policy;
- whether Civic or Living is the release default.
- whether the entry CTA is a real first action. When it is, author `opening.entryAction`, leave pre-action `opening.choices` empty, resolve it locally through the reducer, and reveal initially unexplained stats only after facts make them meaningful.

For `stateful`, preserve accumulated reading and free action. It may use local domain transactions for the first meaningful choices, but must not inherit cinematic pagination, a fixed action/result tray, or a global three-scene gate.

### 3. Author one paired Cartridge

Read [references/cartridge-contract.md](references/cartridge-contract.md) and inspect the selected engine's `src/story/types.ts` before writing code.

Add one Cartridge file with one `zh` export and one `en` export to the working engine. Keep all stable ids identical across languages. Register both in the working engine's `src/story/cartridges/index.ts` during authoring.

The Cartridge owns world rules, opening, characters, places, items, exactly three stats, director rules, danger, image direction, audio assets/direction, and demo/campaign content. The engine owns parsing, reduction, save migration, identity, media queues, hybrid audio playback/fallback, choice recovery, UI flow, and deterministic danger resolution.

If the game has scarce resources, one-time rewards, crafting/exchanges, route locks, charged items, party gates, recovery rules, ending prerequisites, or an authored first action whose result must be stable, read [references/domain-rules.md](references/domain-rules.md). Declare exact `domainRules` in the Cartridge; keep matching, zero-model adjudication, atomic reduction and derived metrics in the engine.

If the requested mechanic does not fit the schema, explain the missing engine capability before changing shared code.

### 4. Preserve continuity and real state

Read [references/continuity-and-danger.md](references/continuity-and-danger.md).

- Treat `StorySave` as authoritative; AI prose is never the database.
- Preserve companions and known characters by stable id. A new group cannot silently replace the current party.
- Separate authored future cast from player-known cast. Mark a fixed character that appears later with `hiddenUntilIntroduced`; it must not enter the roster, objectives, dialogue, relationships, or choices before a visible debut.
- Stage every named debut in this order: visible form/action, everyday source of the name, present relationship or intent, then interaction choices. Hidden protocol commands and prompt text do not count as a player-visible introduction.
- Give every model-created recurring character a new stable `character_id` plus a complete visual identity on that same visible debut. Once an id is bound to a name, later protocol may enrich facts but may not rename the id or bind the name to a second id. Relationship and party commands may reference known characters only, and joining must also be visible in the same response.
- Persist acquisitions/removals through structured commands; inventory UI reads persisted inventory only.
- Paid work is a local transaction: persist an exact-wage `[job]` contract at offer time, settle that contract once through the reducer, and reject or repair any response whose visible payment, contract and coin delta disagree. Localized coin nouns such as 钱币、铜板、铜币、硬币、coins and coppers share this contract. Compensation synonyms such as 报酬、工钱、薪水、工资、pay, wages, salary and compensation are also money claims: “赚得 / 收到 / 领到 / earned / received” them or handing them to the player counts as a completed transfer even when no coin noun appears, so vague amounts must be rejected before commit. Explicit denials and NPC-only wages are not player income. A promise never credits coin, and job settlement never stacks with a coin widget. Spending has a separate consent gate: only the current player action may authorize one exact purchase. Asking, looking, considering, hearing a price, or saying only “把钱全部花完 / spend all my money” is not consent; the latter lacks a purchase object and must be clarified without changing coin.
- Make visible prose and returned choices describe the same immediate situation. Every person, place, object, institution, and immediate goal named by a choice must already be visible in that response or established in authoritative state. Filter known-invalid choices individually before render and preserve every remaining valid choice; do not reject a whole usable set because one option is bad. A turn may expose one to five choices, and the count is never a quota: do not pad to three or truncate a fourth/fifth grounded choice merely for layout. Generated labels such as “观察新变化 / 等待 / 和同伴商量怎么办 / 继续当前任务 / 换一种方式” are placeholders rather than executable commitments: filter them, along with the just-completed action and retry-prefixed paraphrases. Only install grounded recovery actions when no trustworthy choice remains; prompt wording alone is not a gate. When a visible attack, rescue, pursuit, intrusion or confrontation begins, emit an `encounter` in that same turn. Until visible prose explains the same participants/threat being resolved and the same turn commits `encounter: resolution`, every discussion, observation, question, wait or plan must keep that active thread present; it may not disappear between turns.
- Send every generated or authored result through one turn pipeline before the reducer. Keep the map node in `location` and the exact inn/workshop/household scene in `sceneLocation`; one `scene_location` must belong to the effective map node, and `image_location` must equal that exact scene. Give every fixed map node bilingual `routeHints` for the concrete words players will see there (for example field, trellis and vines), and require a movement/commitment cue plus one unique destination fingerprint before semantic routing. A model-created or player-named place must also become a first-class map node: assign/reuse one stable `location_id`, retain only aliases and sublocations proven in visible prose or the player's explicit naming action, merge later aliases without duplicating the node, and bind every resolvable displayed route to `targetLocationId` before it is clickable. An alias collision or reused id with a different canonical label must never be guessed. A displayed cross-location choice is an executable UI contract: if generation and one repair both omit or contradict its unique destination, commit only the locally certain route transition and derive grounded choices at the destination; never turn it into a false “still at the old place” dead end. A new task requires `state`, and choices cannot silently act in a previous place. For unknown, ambiguous or free-input conflicts, reject the draft and preserve authority. If a displayed system recommendation itself cannot produce a reliable result after one repair, commit no state change, remove that recommendation, preserve only trustworthy sibling buttons, and keep free input available; if no sibling remains, render no quick reply instead of inventing a recovery menu or turning the long-term objective into a button. If the only failure is that every newly generated reply was filtered out after an otherwise valid consequence, commit the consequence and derive choices from the already-authoritative state. During active danger never reuse older siblings: derive all buttons from the current threat and write that exact threat into every confirm/respond/withdraw label. Do not inject generic companion discussion as a recovery option. Exclude the action that just completed and semantic same-object rewrites such as inspect → touch/recheck when no authoritative progress occurred. Treat every deterministic authored label as a scoped contract: when its location/character/job preconditions fail, it may neither execute nor re-enter the tray. Never fabricate new people, places or objects merely to fill a quota.
- Store every rendered choice set as an immutable scene-level choice record in the article as well as the live tray. On save migration, rewrite legacy generic consistency recoveries and their stored choice records to the action-preserving form; migrations must be idempotent.
- Scope filtering applies when a deterministic label executes or re-enters a generated tray. Do not semantic-repeat filter the trusted follow-ups emitted by the authored turn itself, and do not test them only against the pre-turn cast/job snapshot: that visible turn may be introducing the character or contract required by its own next action.
- Give every Cartridge a world-native `transitionAnchor`. Before a reducer commits a new location, insert a visible bridge through that anchor and only then show destination prose and choices. Reuse a train carriage, route map, camp, stair landing, ship log, or another believable anchor; do not force every story to imitate a latent-space hub.
- Never synthesize a generic “continue” button when concrete choices were presented.
- Send the current state snapshot and recent relevant events every turn.

### 5. Configure danger without forcing one genre

Every Cartridge defines `dangerDirector`:

- a concrete safe-turn range and cooldown;
- a world-specific threat palette;
- three materially different response methods, each written as one short,
  concrete action the player can take now. These strings are rendered directly
  when generated replies fail, so never write an abstract strategy category or
  bundle alternatives with commas, slashes, `or`, or `或` merely to fill a slot;
- five severity DCs and deterministic fallback costs;
- `physicalCombat: none | rare | allowed`.

Use warning → confrontation → resolution. The local engine owns the d20 and outcome; AI narrates the fixed result. Refresh must not reroll. If AI omits a valid cost after failure or costly success, the reducer applies the configured fallback.

### 6. Direct images without identity drift

Runtime images are event-specific. Never seed every later scene with the poster or opening composition.

For `stateful`, configure perspective through `imageDirector.perspective`; do not hard-code one camera language into the shared engine. Omit the field or use `ordinary: observer` when migrating an existing game so its visual behavior remains stable. Use `ordinary: balanced` when the product needs a genuine mix: the local director deterministically alternates suitable ordinary scene decisions to keep the measured first-person share at 40–60%, while explicit player-visible actions remain observer/third-person. Use `first-person-preferred` only when the product explicitly wants roughly three quarters of suitable ordinary scenes from the player's eyes. Configure `importantDialogue` and `newLocation` independently. A first-person prompt must call the camera the protagonist's eyes, keep the protagonist's face, head, back, shoulders, silhouette, reflection and body out of frame, avoid over-the-shoulder staging, and never invent hands unless visible prose established them. It must never receive the player avatar reference. A new-location establishing image or a scene that needs the protagonist's full action, costume or spatial relation should remain observer/third-person.

If the Cartridge declares `presetEventDirector`, author concrete location-bound events rather than a generic “observe new changes” button. Do not offer one while an objective, reply context, accepted/offered job or danger thread is active. Give each event exact visible prose, one concrete objective, one to five grounded follow-ups and an event-specific image. Audit the authored event pool's perspective distribution separately: a `balanced` game must include both first-person and observer images instead of embedding first-person wording in most event prompts.

When a product promises expression images for important dialogue, add `character-expression` to `imageDirector.guaranteedTriggers`. Importance belongs to the line, not the speaker's roster rank: plot revelations, relationship changes, boundaries, promises, requests, warnings, new tasks and strong emotional turns qualify from any visible speaker. Emit `dialogue_focus` when the model recognizes one; retain local consequence/tone/text inference as a fallback. The trigger overrides a generic environment proposal, bypasses ordinary image cooldown, and requests a contextual medium close-up. Short administrative acknowledgements do not qualify.

Treat `image_subject` as reference-identity ownership, not a census:

- use `player` only when the protagonist is the dominant visible actor performing the main action;
- use `others` when a companion/NPC owns the action, even if the player is incidental;
- use `environment` for empty/object-only shots.

Only `player` shots may receive the player avatar reference. Treat the avatar as the protagonist's complete visible identity, not as a face token: preserve silhouette, form/species, body proportions, material, face visibility, covering, mask, costume, colors, patterns, and accessories. A faceless sheet ghost, helmeted figure, creature, animal, or object-like avatar must remain that form. Never invent a face, skin, hair, hands, arms, or legs absent from the reference. Other actors, reflections, masks, and animals cannot inherit any reference-derived trait.

For `cinematic`, define `mediaDirector.imageTarget` as 4:5 (normally `512x640`), `imageProfile: fast-small`, and `imageDirector.maxQuietTurns: 1`. Use the player's original public HTTPS avatar directly as the edit reference; output width/height control the generated scene and do not require pre-cropping or re-uploading the avatar. The renderer contract must be short (at most 2400 characters), front-loaded, and name the protagonist only as `SUBJECT A`; strip role-shaped appearance words such as courier, traveler, knight, generic anatomy, or period clothing before generation. External pages use the 10.5-second shell window; once platform capability is known, keep retrying profile lookup to the 30.5-second hard fallback so the first image cannot race ahead without the avatar. Prefer fewer people and clearer blocking when the protagonist must be recognisable.

The frozen cinematic engine routes runtime images through the shared AlterU Media Service contract. If `$alteru-media-service` is installed, use that separate Skill as the current source of truth for public API, complete visual identity, retries and media QA; do not copy its private-service responsibilities into this RPG Skill. The frozen client remains present so this RPG package is buildable on its own. Media requests may contain only the session/request id, mode, size, the current visible scene's minimized prompt, and a public HTTPS player-avatar or generated-anchor reference when identity ownership requires it. Never send the complete `StorySave`, relationship log, inventory, chat history, or raw free input to the media service. Treat reference URLs and generated prompts as ephemeral request data: never persist them in analytics, logs, game saves, or handoff artifacts. Retry only structured retryable failures and honor the public retry hint.

For a generated recurring NPC, create one text-mode 4:5 identity anchor before the first character-led scene, persist only its media `task_id` in `CharacterVisualIdentity.anchorTaskId`, and resolve that task to an ephemeral URL when a later scene needs an edit reference. The first scene and every later character-led scene must reuse the same anchor. Never persist the returned CDN URL or raw reference URL. If the anchor fails, keep the character/state turn playable and mark identity generation failed; do not replace the stable character with a lookalike.

Optional external transports have no bundled vendor defaults. The `remote` story adapter stays disabled unless the consuming project explicitly configures `VITE_STORY_API_ORIGIN`. Cinematic video generation is disabled in this handoff package; frame URLs and video prompts require a separate data-boundary review and authorization before any client is installed or `videoEnabled` is turned on. Do not restore vendor endpoints in shared source, and do not treat a consuming project's separate endpoint approval as part of this Skill.

### 7. Verify the working engine before export

Read [references/acceptance.md](references/acceptance.md). For a final handoff, prefer the unified acceptance command over manually replaying the list below:

```bash
node <skill>/scripts/acceptance.mjs \
  --scope full \
  --report <absolute-report.json>
```

Only a `pass` report from `full` scope may support “unified acceptance passed.” A `core` run is deliberately `partial` and exists only for fast diagnosis. The unified runner discovers every non-browser `test:*` script from both mother-template package files, runs the action-authority experiment's required personal/multiplayer/HTTP/fault/identity matrix, runs the explicit browser matrix, exports fresh isolated products, installs their locked dependencies, validates/tests/builds them, and records `deploymentIncluded: false`. Keep the individual commands below for narrowing a failure.

Install locked dependencies when absent. For `stateful`, run at least:

```bash
npm install
npm run test:protocol
npm run test:payment
npm run test:turn
npm run test:dynamic-locations
npm run test:dynamic-locations-browser
npm run test:recovery-policy
npm run test:pipeline
npm run test:state-integrity
npm run test:danger
npm run test:danger-loop
npm run test:danger-grounding
npm run test:choice-recovery
npm run test:image-director
npm run test:perspective-director
npm run test:preset-events
npm run test:v9-migration
npm run test:item-images
npm run test:persistence
npm run test:audio
npm run test:hybrid-audio
npm run test:restart
npm run test:status-drawer
npm run test:i18n
npm run test:avatar
npm run test:character-debut
npm run test:generated-characters
npm run test:domain-continuity
npm run test:recovery-choice-priority
npm run test:active-thread
npm run test:choice-quality
npm run test:loop-escape
npm run build
```

For `cinematic`, run at least:

```bash
npm install
npm run test:protocol
npm run test:danger
npm run test:danger-grounding
npm run test:image-director
npm run test:avatar-reference
npm run test:cinematic
npm run test:loop-escape
npm run test:ending
npm run test:opening
npm run test:character-debut
npm run test:hybrid-audio
npm run build
```

Also exercise a free-form action that rejects all suggestions and one failed danger resolution with a persisted consequence. In cinematic mode, a calm turn with zero grounded recommendations must leave quick replies empty and retain free input; it must not manufacture a generic recovery menu. Active danger is the exception and keeps only threat-bound deterministic actions. Verify result and decision never display simultaneously and every successful step produces one image decision.

For accumulated-reading `stateful` games, add a browser turn at 390×844 and 320×568 that changes at least one beneficial and one harmful stat. Assert that narrated status reports are absent, ordinary prose does not create a duplicate decision-context row, authoritative delta strips remain readable, only changed HUD values animate once and settle, grounded choices remain available, and reduced-motion removes displacement/scale.

Also reload a progressed save, choose Continue, and assert that the first visible content is a readable context anchor (prefer the latest player action plus its consequence), while the current quick replies remain visible. Never resume at `scrollHeight`: the stateful shell intentionally keeps a large bottom reading spacer, so physical-bottom scrolling produces an empty viewport. Keep this rule as a mechanical `test:resume` plus browser evidence at 390×844 and 320×568.

When `domainRules` exists, also run `npm run test:domain` and a browser trace covering illegal action → feasible recovery → legal action → repeat rejection. Inject hostile model commands that attempt a second action, unrelated resource grants, route changes and repeated rewards.

### 8. Export one standalone project

Create an empty target, optionally with an empty `doc/`, then run:

```bash
node <skill>/scripts/scaffold.mjs \
  --mode <stateful|cinematic> \
  --game-id <kebab-id> \
  --title "<English catalog title>" \
  --cartridge-file <file>.ts \
  --zh-export <zhExport> \
  --en-export <enExport> \
  --template <workspace>/.story-engine \
  --target <absolute-target>
```

The script generates a UUID v4, creates an isolated save namespace, recursively retains local Cartridge dependencies, retains referenced world assets, and exports a single-Cartridge Vite project. Never reuse another game's UUID, save key, repository, or poster.

Install dependencies in the exported project and finish `doc/technical.md` from the final code.

### 9. Produce distinct visual assets

For `stateful` create a native landscape `entryImage` (approximately 16:9). For `cinematic` create a native 4:5 `entryImage` matching the exact opening beat and composition-safe UI region. Both modes also need:

- `coverImage`: world/style reference, not UI;
- `public/poster.png`: 1024×1024 raster poster, English text only, absolutely no Chinese or pseudo-Chinese characters.

Do not reuse the formal poster as a runtime scene reference. Inspect the poster at 1024×1024 and 160×160.

### 10. Validate the independent product

Run:

```bash
node <skill>/scripts/validate-game.mjs <game> --test --build --<stateful|cinematic>
node <skill>/scripts/validate-game.mjs <game> --test --build --handoff-ready --<stateful|cinematic>
```

Read [references/qa.md](references/qa.md). Capture 390×844, 320×568, 1024×768, and 1440×900. Verify both platform layout and external visitor mode. Repair every P0/P1 and recapture the same state.

For cinematic games, additionally prove: opening image matches opening text; all captions are readable through pagination; result hides the next premise/choices; next premise and choices appear together; enabled options are unmistakable; the stage composes correctly behind the upper dashboard; a normal face avatar and a generated faceless full-body avatar both retain their complete identity on the player actor only.

### 11. Hand off, do not deploy

Create `doc/artifact-handoff.json` through the validator. Give the source, `dist/`, poster, notices, test evidence, mode, UUID, and build command to the receiving team. State: “handoff-ready artifacts verified; deployment is outside this Skill.”

Before sending a packaged Skill, run the package-only gate and send its JSON report plus SHA-256 alongside the archive:

```bash
node <skill>/scripts/acceptance.mjs \
  --scope package \
  --package <absolute-package.zip> \
  --report <absolute-package-report.json>
```

## Non-negotiable core contract

- Exactly three visible stats; clamp every delta to registered limits.
- Give every visible stat a concise player-facing explanation of meaning, change/recovery, and threshold effects. If a minimum restricts play, use the engine `floorRule` plus deterministic recovery domain rules so the same-turn result, free input, quick replies and restored saves cannot bypass it.
- A recovery action is available according to world state, not unlocked only at the stat floor. When ordinary rest is allowed, explicit contextual actions such as resting in a newly described hut must resolve through a local rule at any current value; questions about availability or price are not consent. Use `dangerPolicy` so an accepted recovery cannot also take a surprise same-turn danger loss. During active danger, reject ordinary rest with a concrete reason and retain one deterministic withdrawal/recovery that cannot soft-lock at the floor. Use `domainMaxDelta` only when a trusted local recovery legitimately exceeds the model-command cap.
- Stable character, place, item, relationship, and party ids across languages and saves.
- Danger fallback methods are player-facing buttons: one method equals one
  concrete immediate action. Keep old copies in `legacyMethods` when changing a
  live game so current saved choices migrate without rewriting past actions.
- A visible active conflict is a persisted thread, not scenery. Establish it with `encounter` in the same turn, preserve the same threat through non-resolving actions, bypass ordinary opening grace once active, and close it only with visible same-thread resolution plus authoritative settlement.
- A matched domain rule owns the entire turn transaction. The model may narrate, but every model protocol command—including choices—is discarded; the local resolution installs exact effects and feasible next choices. A failed requirement applies zero partial effects.
- Store charged-item usage once and derive remaining charges; never maintain two writable counters.
- Future fixed characters remain hidden until a visible debut; no dialogue, objective, roster entry, relationship or choice may name them first.
- Items expose count/rarity, effect, limitation, provenance, metrics, and persistent ownership.
- Chinese and English UI follow player language; production poster remains English-only.
- A chapter ending is resumable. Restart is explicit, confirmed, and isolated to this game.
- Returning players receive Continue/Restart and can jump to the latest anchor.
- In `stateful`, “latest anchor” means the latest readable action/context block, never the scroll container's physical bottom or its layout spacer; after Continue, context and current choices must be visible together.
- Audio is gesture-unlocked, background-safe, and non-blocking. Generated music/ambience use durable local assets with natural endings; the reading-first A bed never overlaps the cooldown-limited B feature score. Ambience plays once per location visit, short cues play once per committed event, and completed sounds never restart on mute/page resume/rerender/restore/reconnect. Deterministic feedback stays synthesized unless a reviewed cue explicitly replaces it, every recorded layer has a synth/silence fallback, bundled Cartridge SFX stays at or below `0.045`, and recorded ordinary/effect gain stays at or below `0.12`.
- The project owns its UUID, save namespace, source, artwork, docs, and build artifact.
- `stateful` images stay inline and never steal scroll position.
- `cinematic` guarantees one image decision per successful step, short paginated text, phased result/decision UI, direct original-avatar edit references for player-owned shots, and bounded automatic repair of legacy first/second scene images that lack the current identity-reference version.
- `cinematic` opens with 4–7 chronological beats the player directly experiences; it never replaces them with a lore résumé or reveals choices/input before the final beat.

## Status language

Say **source verified** only after authoring validation, runtime QA, and build pass. Say **handoff-ready artifacts verified** only after `--handoff-ready` passes. Never say **published**, **deployed**, or **online** from this Skill.
