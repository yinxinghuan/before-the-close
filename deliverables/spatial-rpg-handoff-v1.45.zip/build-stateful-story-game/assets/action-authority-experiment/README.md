# Action Authority Experiment

这是随 `build-stateful-story-game` 交付的独立实验层，不是默认引擎，也不是部署包。

它验证两类可选接入：单人受管数值/行动，以及异步多人共享世界事务。多人部分包含纯 reducer、绑定会话的 gateway、HTTP + SQLite 测试权威、提交结果丢失后的 action-id 对账、重复提交、cursor 重连、私人回执、规则升级和身份 claims 合同。

```bash
npm install
npm test
```

生产接入必须由接收方实现真实平台签名验证、数据库事务、权限/封禁与部署。浏览器传来的 `user_id`、query 参数或 profile JSON 不能充当可验证身份；本实验不包含任何 AlterU 部署流程、凭据、域名或数据库配置。
