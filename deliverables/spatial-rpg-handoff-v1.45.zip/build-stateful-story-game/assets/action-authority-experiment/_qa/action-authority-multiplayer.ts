import assert from 'node:assert/strict'
import { enumerateExecutableActions } from '../src/story/experimental/actionAuthority'
import { createSharedAidLab } from '../src/story/experimental/labWorld'
import {
  acknowledgeReceipt,
  applySharedAction,
  initialEnvelope,
  listPendingReceipts,
  mergeReceiptsIntoEnvelope,
} from '../src/story/experimental/sharedWorldAuthority'

const lab = createSharedAidLab('zh')
const requestA = {
  worldKey: 'main', actionId: 'claim-a', actorUserId: 'user-a', expectedVersion: 0,
  rulesetVersion: 1, actionDefinitionId: 'claim-last-umbrella',
}
const requestB = {
  worldKey: 'main', actionId: 'claim-b', actorUserId: 'user-b', expectedVersion: 0,
  rulesetVersion: 1, actionDefinitionId: 'claim-last-umbrella',
}

const committedA = applySharedAction(lab.head, lab.ruleset, requestA)
assert.equal(committedA.response.ok, true)
assert.equal(committedA.head.version, 1)
assert.equal(committedA.head.cursor, 1)
assert.equal(committedA.head.snapshot.stats['umbrella-units'], 0)
assert.equal(committedA.head.receipts.length, 1)
assert.equal(committedA.head.receipts[0]?.actorUserId, 'user-a')

const replayA1 = applySharedAction(committedA.head, lab.ruleset, requestA)
const replayA2 = applySharedAction(replayA1.head, lab.ruleset, requestA)
assert.equal(replayA1.response.replayed, true)
assert.equal(replayA2.response.replayed, true)
assert.equal(replayA2.head.version, 1, 'three sends of one action id must commit one version')
assert.equal(replayA2.head.receipts.length, 1, 'idempotent replay must not duplicate a grant receipt')

const staleB = applySharedAction(replayA2.head, lab.ruleset, requestB)
assert.equal(staleB.response.ok, false)
assert.equal(staleB.response.code, 'VERSION_CONFLICT')
assert.equal(staleB.head.version, 1)

const refreshedB = applySharedAction(staleB.head, lab.ruleset, { ...requestB, expectedVersion: 1 })
assert.equal(refreshedB.response.ok, false)
assert.equal(refreshedB.response.code, 'INVALID_ACTION')
assert.ok(refreshedB.response.reasons?.some((reason) => reason.includes('已经被别人领走')))
assert.equal(refreshedB.head.version, 1)
assert.equal(refreshedB.head.receipts.length, 1)
assert.equal(enumerateExecutableActions(refreshedB.head.snapshot, lab.ruleset, 'user-b').length, 0, 'stale shared choice must disappear after refresh')

const pendingA = listPendingReceipts(refreshedB.head, 'user-a')
const pendingB = listPendingReceipts(refreshedB.head, 'user-b')
assert.equal(pendingA.length, 1)
assert.equal(pendingB.length, 0)

const envelope0 = initialEnvelope({ privateRelationship: 'keep-me', chapter: 4 })
const envelope1 = mergeReceiptsIntoEnvelope(envelope0, pendingA)
const envelope2 = mergeReceiptsIntoEnvelope(envelope1, pendingA)
assert.deepEqual(envelope2.namespaces.story, envelope0.namespaces.story, 'receipt merge cannot erase private story state')
assert.equal(envelope2.namespaces.sharedInventory.items['community-umbrella'], 1)
assert.equal(envelope2.namespaces.sharedInventory.receiptIds.length, 1, 'receipt merge must be idempotent')

const prematureAck = acknowledgeReceipt(refreshedB.head, 'user-a', pendingA[0]!.id, [])
assert.equal(prematureAck.ok, false)
assert.equal(prematureAck.reason, 'PRIVATE_SAVE_NOT_VERIFIED')
const ack = acknowledgeReceipt(
  refreshedB.head,
  'user-a',
  pendingA[0]!.id,
  envelope2.namespaces.sharedInventory.receiptIds,
)
assert.equal(ack.ok, true)
assert.equal(listPendingReceipts(ack.head, 'user-a').length, 0)

const publicJson = JSON.stringify(ack.head.events[0])
for (const forbidden of ['privateRelationship', 'freeInput', 'privateInventory', 'receiptIds']) {
  assert.equal(publicJson.includes(forbidden), false, `public event leaked ${forbidden}`)
}

const mismatchedRuleset = applySharedAction(lab.head, lab.ruleset, { ...requestA, rulesetVersion: 2 })
assert.equal(mismatchedRuleset.response.code, 'RULESET_MISMATCH')
assert.equal(mismatchedRuleset.head.version, 0)

// Different clients can generate the same local request id. Idempotency must be
// scoped to the authenticated actor, not to an untrusted id alone.
const collisionLab = createSharedAidLab('zh', 2)
const sameLocalIdA = applySharedAction(collisionLab.head, collisionLab.ruleset, {
  worldKey: 'main', actionId: 'local-1', actorUserId: 'user-a', expectedVersion: 0,
  rulesetVersion: 1, actionDefinitionId: 'claim-last-umbrella',
})
const sameLocalIdB = applySharedAction(sameLocalIdA.head, collisionLab.ruleset, {
  worldKey: 'main', actionId: 'local-1', actorUserId: 'user-b', expectedVersion: 1,
  rulesetVersion: 1, actionDefinitionId: 'claim-last-umbrella',
})
assert.equal(sameLocalIdA.response.ok, true)
assert.equal(sameLocalIdB.response.ok, true)
assert.equal(sameLocalIdB.response.replayed, false)
assert.equal(sameLocalIdB.head.version, 2)
assert.equal(new Set(sameLocalIdB.head.receipts.map((receipt) => receipt.id)).size, 2)
const collisionReplayA = applySharedAction(sameLocalIdB.head, collisionLab.ruleset, {
  worldKey: 'main', actionId: 'local-1', actorUserId: 'user-a', expectedVersion: 0,
  rulesetVersion: 1, actionDefinitionId: 'claim-last-umbrella',
})
assert.equal(collisionReplayA.response.replayed, true)
assert.equal(collisionReplayA.response.event?.actorUserId, 'user-a')
assert.equal(collisionReplayA.head.version, 2)

console.log(JSON.stringify({
  ok: true,
  race: { contenders: 2, available: 1, committed: 1, receipts: 1 },
  assertions: [
    'stable-action-id', 'version-conflict', 'refresh-revalidation', 'single-grant',
    'private-save-before-ack', 'namespace-preservation', 'public-private-separation', 'ruleset-version-gate',
    'actor-scoped-idempotency',
  ],
  boundary: 'local authority simulation only; no authenticated production backend',
}, null, 2))
