import assert from 'node:assert/strict'
import {
  enumerateExecutableActions,
  rejectionReasons,
  resolveActionInput,
  restoreAuthorityState,
  serializeAuthorityState,
} from '../src/story/experimental/actionAuthority'
import { createPersonalLab, createRoomSevenAmbiguityLab } from '../src/story/experimental/labWorld'

const opening = createPersonalLab('zh')
const openingActions = enumerateExecutableActions(opening.state, opening.ruleset)
assert.equal(openingActions.length, 6, 'authority layer must preserve more than three executable actions')
assert.deepEqual(openingActions.map((action) => action.id), [
  'inspect-directory',
  'ask-mara-red-lights',
  'go-second-floor',
  'rest-lobby-chair',
  'inspect-key-rack',
  'check-rain-ledger',
])

const invalidBefore = serializeAuthorityState(opening.state)
const invalid = resolveActionInput(opening.state, opening.ruleset, '进入七号房', {
  source: 'free-input', actionId: 'personal-invalid-1',
})
assert.equal(invalid.status, 'rejected')
assert.ok(invalid.reasons.some((reason) => reason.includes('七号房门不在这里')))
assert.equal(serializeAuthorityState(invalid.state), invalidBefore, 'rejected action must be a zero-effect transaction')

const button = resolveActionInput(opening.state, opening.ruleset, 'inspect-directory', {
  source: 'button', actionId: 'personal-directory-button',
})
const free = resolveActionInput(createPersonalLab('zh').state, opening.ruleset, '现在查看一下黄铜目录', {
  source: 'free-input', actionId: 'personal-directory-free',
})
assert.equal(button.status, 'committed')
assert.equal(free.status, 'committed')
assert.equal(button.state.stats.clues, 1)
assert.equal(free.state.stats.clues, 1)
assert.equal(button.state.facts['directory-read'], true)
assert.equal(free.state.facts['directory-read'], true)

const repeated = resolveActionInput(button.state, opening.ruleset, '查看黄铜目录', {
  source: 'free-input', actionId: 'personal-directory-repeat',
})
assert.equal(repeated.status, 'rejected')
assert.equal(repeated.state.stats.clues, 1, 'one-time clue cannot be farmed')
assert.equal(repeated.state.actionLedger.length, 1, 'rejection cannot append a committed action')

const replayed = resolveActionInput(button.state, opening.ruleset, 'inspect-directory', {
  source: 'button', actionId: 'personal-directory-button',
})
assert.equal(replayed.status, 'replayed')
assert.equal(replayed.state.actionLedger.length, 1, 'same action id must be idempotent')

const routeA = resolveActionInput(createPersonalLab('zh').state, opening.ruleset, '去二层', {
  source: 'free-input', actionId: 'personal-route-stable',
})
const routeB = resolveActionInput(createPersonalLab('zh').state, opening.ruleset, 'go-second-floor', {
  source: 'button', actionId: 'personal-route-stable',
})
assert.equal(routeA.status, 'committed')
assert.equal(routeA.state.currentLocationId, 'second-floor-corridor')
assert.equal(routeA.state.activeThread?.id, 'red-lights-closing')
assert.deepEqual(routeA.state, routeB.state, 'same seed, state and action id must produce the same scheduled event')
assert.deepEqual(routeA.state.eventLedger.map((event) => event.id), ['corridor-whisper'])
assert.ok(routeA.choices.length > 0)
assert.ok(routeA.choices.every((choice) => !['ask-mara-red-lights', 'inspect-directory', 'rest-lobby-chair'].includes(choice.id)))
for (const choice of routeA.choices) {
  const definition = opening.ruleset.actions.find((action) => action.id === choice.id)!
  assert.deepEqual(rejectionReasons(definition, routeA.state, opening.ruleset), [], `rendered choice ${choice.id} must execute now`)
}

const named = resolveActionInput(routeA.state, opening.ruleset, '说明红灯顺序', {
  source: 'free-input', actionId: 'personal-name-pattern',
})
assert.equal(named.status, 'committed')
assert.equal(named.state.activeThread?.phase, 'active', 'non-resolving action must preserve the threat')
assert.ok(named.choices.some((choice) => choice.id === 'enter-room-seven'))

const lit = resolveActionInput(routeA.state, opening.ruleset, '点燃红色火柴', {
  source: 'free-input', actionId: 'personal-light-match',
})
assert.equal(lit.status, 'committed')
assert.equal(lit.state.inventory['red-match'], 2)
assert.equal(lit.state.activeThread?.phase, 'resolved')
assert.ok(lit.choices.some((choice) => choice.id === 'enter-room-seven'), 'a concrete follow-up must replace the resolved threat')

const noMatchState = { ...routeA.state, inventory: { ...routeA.state.inventory, 'red-match': 0 } }
const noMatchBefore = serializeAuthorityState(noMatchState)
const noMatch = resolveActionInput(noMatchState, opening.ruleset, '点燃红色火柴', {
  source: 'free-input', actionId: 'personal-no-match-left',
})
assert.equal(noMatch.status, 'rejected')
assert.ok(noMatch.reasons.some((reason) => reason.includes('没有红色火柴')))
assert.equal(serializeAuthorityState(noMatch.state), noMatchBefore)

const unknown = resolveActionInput(opening.state, opening.ruleset, '唱一首从未出现过的歌', {
  source: 'free-input', actionId: 'personal-open-flow',
})
assert.equal(unknown.status, 'unmatched')
assert.equal(serializeAuthorityState(unknown.state), serializeAuthorityState(opening.state))

const ambiguousLab = createRoomSevenAmbiguityLab('zh')
const ambiguous = resolveActionInput(ambiguousLab.state, ambiguousLab.ruleset, '检查门', {
  source: 'free-input', actionId: 'personal-ambiguous-door',
})
assert.equal(ambiguous.status, 'clarify')
assert.deepEqual(ambiguous.candidates?.map((action) => action.id), ['inspect-left-door', 'inspect-right-door'])
assert.equal(serializeAuthorityState(ambiguous.state), serializeAuthorityState(ambiguousLab.state))

const restored = restoreAuthorityState(serializeAuthorityState(named.state), opening.ruleset)
assert.deepEqual(restored, named.state, 'serialized snapshot must restore every authoritative field')
assert.throws(() => restoreAuthorityState(serializeAuthorityState(named.state), { ...opening.ruleset, version: 2 }), /Ruleset mismatch/)

console.log(JSON.stringify({
  ok: true,
  openingExecutableActions: openingActions.length,
  assertions: [
    'no-dead-options', 'more-than-three-preserved', 'button-free-input-equivalence',
    'atomic-rejection', 'repeat-reward-blocked', 'action-id-idempotency',
    'active-thread-continuity', 'deterministic-events', 'ambiguity-no-guess', 'full-snapshot-restore',
  ],
}, null, 2))
