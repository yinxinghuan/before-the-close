import assert from 'node:assert/strict'
import { createHttpBoundAuthorityGateway } from '../src/story/experimental/httpSharedWorldGateway'
import { createSharedRelayLab } from '../src/story/experimental/labWorld'
import {
  initialEnvelope,
  mergeReceiptsIntoEnvelope,
} from '../src/story/experimental/sharedWorldAuthority'
import { submitWithConflictRefresh } from '../src/story/experimental/sharedWorldGateway'
import { createSqliteSharedWorldService } from './support/sqlite-shared-world-service'

const lab = createSharedRelayLab('zh')
const service = createSqliteSharedWorldService({
  ruleset: lab.ruleset,
  initialHead: lab.head,
  actorTokens: {
    'qa-session-a': 'user-a',
    'qa-session-b': 'user-b',
  },
})

const { baseUrl } = await service.listen()
try {
  const health = await fetch(`${baseUrl}/api/health`).then((response) => response.json()) as Record<string, unknown>
  assert.equal(health.storage, 'sqlite-transactional')
  assert.equal(health.identity_mode, 'qa-server-bound-session')
  assert.equal(health.deployment, false)
  const unauthenticated = await fetch(`${baseUrl}/api/world/state?world_key=main`)
  assert.equal(unauthenticated.status, 401)

  const userA = createHttpBoundAuthorityGateway({
    apiBase: baseUrl, worldKey: 'main', rulesetVersion: 1, actorSessionToken: 'qa-session-a',
  })
  const userB = createHttpBoundAuthorityGateway({
    apiBase: baseUrl, worldKey: 'main', rulesetVersion: 1, actorSessionToken: 'qa-session-b',
  })
  const initialA = await userA.read()
  const initialB = await userB.read()
  assert.equal(initialA.version, 0)
  assert.equal(initialB.version, 0)

  const [raceA, raceB] = await Promise.all([
    userA.submit({ actionId: 'http-race-a', expectedVersion: 0, actionDefinitionId: 'claim-signal-battery' }),
    userB.submit({ actionId: 'http-race-b', expectedVersion: 0, actionDefinitionId: 'claim-signal-battery' }),
  ])
  const race = [raceA, raceB]
  assert.equal(race.filter((result) => result.ok).length, 1)
  assert.equal(race.filter((result) => result.code === 'VERSION_CONFLICT').length, 1)
  const winnerGateway = raceA.ok ? userA : userB
  const loserGateway = raceA.ok ? userB : userA
  const winnerResponse = raceA.ok ? raceA : raceB
  const winnerActionId = raceA.ok ? 'http-race-a' : 'http-race-b'
  const loserActionId = raceA.ok ? 'http-race-b' : 'http-race-a'

  const replay = await winnerGateway.submit({
    actionId: winnerActionId, expectedVersion: 0, actionDefinitionId: 'claim-signal-battery',
  })
  assert.equal(replay.ok, true)
  assert.equal(replay.replayed, true)
  assert.equal(replay.version, winnerResponse.version)

  const stale = await submitWithConflictRefresh({
    gateway: loserGateway,
    initialView: raceA.ok ? initialB : initialA,
    actionId: loserActionId,
    actionDefinitionId: 'claim-signal-battery',
  })
  assert.equal(stale.status, 'stale')
  assert.equal(stale.attempts, 1)

  const viewAfterRace = await userB.read()
  const spoofedResponse = await fetch(`${baseUrl}/api/world/action`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer qa-session-b' },
    body: JSON.stringify({
      world_key: 'main',
      action_id: 'http-spoofed-handoff',
      actor_user_id: 'user-a',
      expected_version: viewAfterRace.version,
      ruleset_version: 1,
      action_definition_id: 'handoff-weather-radio-to-user-b',
    }),
  })
  const spoofedActor = await spoofedResponse.json() as { ok: boolean; code?: string }
  assert.equal(spoofedResponse.status, 422)
  assert.equal(spoofedActor.ok, false)
  assert.equal(spoofedActor.code, 'INVALID_ACTION')

  const handoff = await submitWithConflictRefresh({
    gateway: userA,
    initialView: await userA.read(),
    actionId: 'http-handoff',
    actionDefinitionId: 'handoff-weather-radio-to-user-b',
  })
  assert.equal(handoff.status, 'committed')
  assert.equal(handoff.response.event?.actorUserId, 'user-a')

  const report = await submitWithConflictRefresh({
    gateway: userB,
    initialView: viewAfterRace,
    actionId: 'http-report',
    actionDefinitionId: 'report-west-bridge-flooding',
  })
  assert.equal(report.status, 'committed')
  assert.equal(report.attempts, 2)
  assert.equal(report.response.event?.actorUserId, 'user-b')
  assert.equal(service.actionTransactionCount(), 3)

  const cursorOne = await userA.read(1)
  assert.deepEqual(cursorOne.events.map((event) => event.seq), [2, 3])
  assert.deepEqual((await userA.read(3)).events, [])

  const pendingA = await userA.pendingReceipts()
  const pendingB = await userB.pendingReceipts()
  assert.ok(pendingA.length >= 1)
  assert.ok(pendingB.length >= 2)
  const crossActorAck = await userA.acknowledge(pendingB[0]!.id, [pendingB[0]!.id])
  assert.equal(crossActorAck.ok, false)
  assert.equal(crossActorAck.reason, 'RECEIPT_NOT_FOUND')
  const earlyAck = await userA.acknowledge(pendingA[0]!.id, [])
  assert.equal(earlyAck.ok, false)
  assert.equal(earlyAck.reason, 'PRIVATE_SAVE_NOT_VERIFIED')

  const envelopeA = mergeReceiptsIntoEnvelope(initialEnvelope({}, { 'weather-radio': 1 }), pendingA)
  const envelopeB = mergeReceiptsIntoEnvelope(initialEnvelope(), pendingB)
  for (const receipt of pendingA) {
    const result = await userA.acknowledge(receipt.id, envelopeA.namespaces.sharedInventory.receiptIds)
    assert.equal(result.ok, true)
  }
  for (const receipt of pendingB) {
    const result = await userB.acknowledge(receipt.id, envelopeB.namespaces.sharedInventory.receiptIds)
    assert.equal(result.ok, true)
  }
  assert.deepEqual(await userA.pendingReceipts(), [])
  assert.deepEqual(await userB.pendingReceipts(), [])

  const freshUserB = createHttpBoundAuthorityGateway({
    apiBase: baseUrl, worldKey: 'main', rulesetVersion: 1, actorSessionToken: 'qa-session-b',
  })
  const reconnected = await freshUserB.read(0)
  assert.equal(reconnected.version, 3)
  assert.deepEqual(reconnected.events.map((event) => event.seq), [1, 2, 3])
  const publicJson = JSON.stringify(reconnected)
  for (const privateField of ['relationship', 'affection', 'privateDialogue', 'freeInput', 'sharedInventory']) {
    assert.equal(publicJson.includes(privateField), false)
  }

  console.log(JSON.stringify({
    ok: true,
    service: { storage: health.storage, identityMode: health.identity_mode, version: reconnected.version, cursor: reconnected.cursor },
    checks: [
      'real-http-boundary',
      'sqlite-immediate-transaction',
      'two-isolated-session-race',
      'server-bound-actor-cannot-be-spoofed',
      'stable-action-id-replay',
      'stale-choice-revalidation',
      'unique-item-two-sided-receipts',
      'private-save-before-ack',
      'cursor-reconnect',
      'public-private-separation',
    ],
    boundary: 'local HTTP + SQLite authority with QA session tokens; platform-verifiable identity and deployed multi-instance behavior remain unverified',
  }, null, 2))
} finally {
  await service.close()
}
