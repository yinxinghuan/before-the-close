import assert from 'node:assert/strict'
import { createHttpBoundAuthorityGateway } from '../src/story/experimental/httpSharedWorldGateway'
import { createSharedAidLab } from '../src/story/experimental/labWorld'
import { initialEnvelope, mergeReceiptsIntoEnvelope } from '../src/story/experimental/sharedWorldAuthority'
import { submitWithAuthorityRecovery } from '../src/story/experimental/sharedWorldGateway'
import { createSqliteSharedWorldService } from './support/sqlite-shared-world-service'

const lab = createSharedAidLab('zh', 2)
const droppedActionId = 'fault-commit-response-lost'
const expectedReceiptId = `user-a:${droppedActionId}:grant:0`
const service = createSqliteSharedWorldService({
  ruleset: lab.ruleset,
  initialHead: lab.head,
  actorTokens: { 'qa-session-a': 'user-a', 'qa-session-b': 'user-b' },
  faults: {
    dropActionResponseAfterCommit: [droppedActionId],
    failGrantAckOnce: [expectedReceiptId],
  },
})

const { baseUrl } = await service.listen()
try {
  const userA = createHttpBoundAuthorityGateway({
    apiBase: baseUrl, worldKey: 'main', rulesetVersion: 1, actorSessionToken: 'qa-session-a',
  })
  const initial = await userA.read()
  const recovered = await submitWithAuthorityRecovery({
    gateway: userA,
    initialView: initial,
    actionId: droppedActionId,
    actionDefinitionId: 'claim-last-umbrella',
  })
  assert.equal(recovered.status, 'committed-reconciled')
  assert.equal(service.actionTransactionCount(), 1)
  assert.equal(recovered.view.events.filter((event) => event.actionId === droppedActionId).length, 1)

  for (let index = 0; index < 3; index += 1) {
    const replay = await userA.submit({
      actionId: droppedActionId,
      expectedVersion: 0,
      actionDefinitionId: 'claim-last-umbrella',
    })
    assert.equal(replay.ok, true)
    assert.equal(replay.replayed, true)
  }
  assert.equal(service.actionTransactionCount(), 1)

  const pendingBeforeSave = await userA.pendingReceipts()
  assert.deepEqual(pendingBeforeSave.map((receipt) => receipt.id), [expectedReceiptId])
  const saveFailedEnvelope = initialEnvelope({ checkpoint: 'unchanged' })
  const earlyAck = await userA.acknowledge(expectedReceiptId, saveFailedEnvelope.namespaces.sharedInventory.receiptIds)
  assert.equal(earlyAck.ok, false)
  assert.equal((await userA.pendingReceipts()).length, 1)

  const persisted = mergeReceiptsIntoEnvelope(saveFailedEnvelope, pendingBeforeSave)
  const injectedAckFailure = await userA.acknowledge(expectedReceiptId, persisted.namespaces.sharedInventory.receiptIds)
  assert.equal(injectedAckFailure.ok, false)
  assert.equal(injectedAckFailure.reason, 'INJECTED_ACK_TRANSPORT_FAILURE')
  assert.equal((await userA.pendingReceipts()).length, 1)
  const ackRetry = await userA.acknowledge(expectedReceiptId, persisted.namespaces.sharedInventory.receiptIds)
  assert.equal(ackRetry.ok, true)
  assert.deepEqual(await userA.pendingReceipts(), [])

  const disconnectedCursor = 0
  const reconnectedA = createHttpBoundAuthorityGateway({
    apiBase: baseUrl, worldKey: 'main', rulesetVersion: 1, actorSessionToken: 'qa-session-a',
  })
  assert.deepEqual((await reconnectedA.read(disconnectedCursor)).events.map((event) => event.seq), [1])

  const userBBeforeUpgrade = createHttpBoundAuthorityGateway({
    apiBase: baseUrl, worldKey: 'main', rulesetVersion: 1, actorSessionToken: 'qa-session-b',
  })
  const staleRulesView = await userBBeforeUpgrade.read()
  assert.ok(staleRulesView.availableActions.some((action) => action.id === 'claim-last-umbrella'))
  service.upgradeRuleset({ ...lab.ruleset, version: 2 })
  const oldRulesResponse = await userBBeforeUpgrade.submit({
    actionId: 'fault-old-ruleset',
    expectedVersion: staleRulesView.version,
    actionDefinitionId: 'claim-last-umbrella',
  })
  assert.equal(oldRulesResponse.ok, false)
  assert.equal(oldRulesResponse.code, 'RULESET_MISMATCH')
  assert.equal(service.actionTransactionCount(), 1)
  const upgradedView = await userBBeforeUpgrade.read(staleRulesView.cursor)
  assert.equal(upgradedView.rulesetVersion, 2)
  assert.ok(upgradedView.availableActions.some((action) => action.id === 'claim-last-umbrella'))

  const invalidSession = createHttpBoundAuthorityGateway({
    apiBase: baseUrl, worldKey: 'main', rulesetVersion: 2, actorSessionToken: 'expired-session',
  })
  await assert.rejects(() => invalidSession.read(), (error: Error & { code?: string }) => error.code === 'AUTH_REQUIRED')

  console.log(JSON.stringify({
    ok: true,
    checks: [
      'response-loss-after-commit-reconciled-by-action-id',
      'three-duplicate-submissions-one-transaction',
      'private-save-failure-keeps-receipt-pending',
      'ack-failure-is-retryable',
      'cursor-reconnect-exactly-once-view',
      'ruleset-upgrade-rejects-old-client-without-commit',
      'invalid-session-has-no-actor-fallback',
    ],
  }, null, 2))
} finally {
  await service.close()
}
