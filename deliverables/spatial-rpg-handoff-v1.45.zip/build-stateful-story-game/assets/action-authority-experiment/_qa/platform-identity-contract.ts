import assert from 'node:assert/strict'
import {
  validateVerifiedPlatformIdentity,
  type CryptographicallyVerifiedIdentity,
  type PlatformIdentityClaims,
} from '../src/story/experimental/platformIdentity'

const now = 2_000_000_000
const claims: PlatformIdentityClaims = {
  issuer: 'https://platform.example',
  audience: 'alteru-shared-world',
  gameId: 'game-uuid-a',
  subject: 'stable-user-a',
  sessionId: 'opaque-session-a',
  issuedAt: now - 10,
  expiresAt: now + 290,
  tokenId: 'single-use-bootstrap-jti',
  scopes: ['world:read', 'world:act'],
}
const proof: CryptographicallyVerifiedIdentity = {
  signatureVerified: true,
  keyId: 'qa-key-1',
  algorithm: 'EdDSA',
  claims,
}
const expected = {
  issuer: claims.issuer,
  audience: claims.audience,
  gameId: claims.gameId,
  requiredScope: 'world:act',
  nowSeconds: now,
}

const accepted = validateVerifiedPlatformIdentity(proof, expected)
assert.equal(accepted.ok, true)
if (accepted.ok) assert.equal(accepted.actorUserId, 'stable-user-a')

assert.equal(validateVerifiedPlatformIdentity({ ...proof, signatureVerified: false } as unknown as CryptographicallyVerifiedIdentity, expected).ok, false)
assert.deepEqual(validateVerifiedPlatformIdentity({ ...proof, claims: { ...claims, audience: 'other' } }, expected), { ok: false, code: 'AUDIENCE_MISMATCH' })
assert.deepEqual(validateVerifiedPlatformIdentity({ ...proof, claims: { ...claims, gameId: 'game-uuid-b' } }, expected), { ok: false, code: 'GAME_MISMATCH' })
assert.deepEqual(validateVerifiedPlatformIdentity({ ...proof, claims: { ...claims, expiresAt: now - 60 } }, expected), { ok: false, code: 'EXPIRED' })
assert.deepEqual(validateVerifiedPlatformIdentity({ ...proof, claims: { ...claims, issuedAt: now + 60, expiresAt: now + 120 } }, expected), { ok: false, code: 'NOT_YET_VALID' })
assert.deepEqual(validateVerifiedPlatformIdentity({ ...proof, claims: { ...claims, expiresAt: now + 700 } }, expected), { ok: false, code: 'TTL_TOO_LONG' })
assert.deepEqual(validateVerifiedPlatformIdentity({ ...proof, claims: { ...claims, scopes: ['world:read'] } }, expected), { ok: false, code: 'SCOPE_MISSING' })

console.log(JSON.stringify({
  ok: true,
  checks: ['verified-proof-only', 'issuer', 'audience', 'game-binding', 'expiry', 'not-before', 'short-ttl', 'required-scope'],
  boundary: 'claim validation after cryptographic verification; platform signature verification remains provider-specific and external',
}, null, 2))
