import assert from 'node:assert/strict'
import { createSharedRelayLab } from '../src/story/experimental/labWorld'
import {
  createLocalBoundAuthorityGateway,
  createLocalSharedWorldStore,
  submitWithConflictRefresh,
} from '../src/story/experimental/sharedWorldGateway'

const lab = createSharedRelayLab('zh')
const store = createLocalSharedWorldStore(lab.head)
const userA = createLocalBoundAuthorityGateway({ store, ruleset: lab.ruleset, actorUserId: 'user-a' })
const userB = createLocalBoundAuthorityGateway({ store, ruleset: lab.ruleset, actorUserId: 'user-b' })

const initialA = await userA.read()
const initialB = await userB.read()
assert.equal(initialA.version, 0)
assert.equal(initialB.version, 0)
assert.deepEqual(initialA.availableActions.map((action) => action.id), [
  'claim-signal-battery', 'handoff-weather-radio-to-user-b',
])
assert.deepEqual(initialB.availableActions.map((action) => action.id), [
  'claim-signal-battery', 'report-west-bridge-flooding',
])

const claimA = await submitWithConflictRefresh({
  gateway: userA,
  initialView: initialA,
  actionId: 'local-1',
  actionDefinitionId: 'claim-signal-battery',
})
assert.equal(claimA.status, 'committed')
assert.equal(claimA.attempts, 1)

const staleClaimB = await submitWithConflictRefresh({
  gateway: userB,
  initialView: initialB,
  actionId: 'local-1',
  actionDefinitionId: 'claim-signal-battery',
})
assert.equal(staleClaimB.status, 'stale')
assert.equal(staleClaimB.attempts, 1)
assert.equal(store.head.version, 1)

const handoffAView = await userA.read()
const handoffA = await submitWithConflictRefresh({
  gateway: userA,
  initialView: handoffAView,
  actionId: 'local-2',
  actionDefinitionId: 'handoff-weather-radio-to-user-b',
})
assert.equal(handoffA.status, 'committed')
assert.equal(store.head.snapshot.entities['weather-radio']?.status, 'held:user-b')

const reportB = await submitWithConflictRefresh({
  gateway: userB,
  initialView: initialB,
  actionId: 'local-2',
  actionDefinitionId: 'report-west-bridge-flooding',
})
assert.equal(reportB.status, 'committed')
assert.equal(reportB.attempts, 2)
assert.equal(store.head.version, 3)

const replayB = await userB.submit({
  actionId: 'local-2', expectedVersion: 0, actionDefinitionId: 'report-west-bridge-flooding',
})
assert.equal(replayB.replayed, true)
assert.equal(store.head.version, 3)

const caughtUpB = await userB.read(1)
assert.deepEqual(caughtUpB.events.map((event) => event.seq), [2, 3])
assert.deepEqual(caughtUpB.availableActions, [])

const pendingA = await userA.pendingReceipts()
const pendingB = await userB.pendingReceipts()
assert.equal(pendingA.length, 2)
assert.equal(pendingB.length, 2)
const wrongActorAck = await userB.acknowledge(pendingA[0]!.id, [pendingA[0]!.id])
assert.equal(wrongActorAck.ok, false)

console.log(JSON.stringify({
  ok: true,
  world: { version: store.head.version, cursor: store.head.cursor },
  checks: [
    'gateway-binds-one-actor',
    'conflict-refresh-reuses-action-id',
    'stale-action-stops-before-second-submit',
    'valid-action-retries-after-refresh',
    'same-local-id-isolated-by-bound-actor',
    'cursor-catch-up',
    'cross-actor-receipt-ack-blocked',
  ],
  boundary: 'local gateway only; remote transport and authenticated identity remain unverified',
}, null, 2))

