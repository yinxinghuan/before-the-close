import { createServer, type IncomingMessage, type ServerResponse } from 'node:http'
import { DatabaseSync } from 'node:sqlite'
import type { AuthorityRuleset } from '../../src/story/experimental/actionAuthority'
import { enumerateExecutableActions } from '../../src/story/experimental/actionAuthority'
import {
  acknowledgeReceipt,
  applySharedAction,
  eventsAfterCursor,
  listPendingReceipts,
  type SharedWorldHead,
} from '../../src/story/experimental/sharedWorldAuthority'

type JsonObject = Record<string, unknown>

function send(response: ServerResponse, status: number, payload: unknown) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' })
  response.end(JSON.stringify(payload))
}

async function readJson(request: IncomingMessage): Promise<JsonObject> {
  const chunks: Buffer[] = []
  for await (const chunk of request) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk))
  if (!chunks.length) return {}
  return JSON.parse(Buffer.concat(chunks).toString('utf8')) as JsonObject
}

function bearer(request: IncomingMessage): string | undefined {
  const value = request.headers.authorization
  return value?.startsWith('Bearer ') ? value.slice(7) : undefined
}

export function createSqliteSharedWorldService(options: {
  ruleset: AuthorityRuleset
  initialHead: SharedWorldHead
  actorTokens: Record<string, string>
  faults?: {
    dropActionResponseAfterCommit?: string[]
    failGrantAckOnce?: string[]
  }
}) {
  let activeRuleset = options.ruleset
  const dropActionResponseAfterCommit = new Set(options.faults?.dropActionResponseAfterCommit ?? [])
  const failedDroppedResponses = new Set<string>()
  const failGrantAckOnce = new Set(options.faults?.failGrantAckOnce ?? [])
  const failedGrantAcks = new Set<string>()
  const database = new DatabaseSync(':memory:')
  database.exec(`
    CREATE TABLE worlds (world_key TEXT PRIMARY KEY, head_json TEXT NOT NULL);
    CREATE TABLE actors (token TEXT PRIMARY KEY, user_id TEXT NOT NULL UNIQUE);
    CREATE TABLE transaction_audit (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      kind TEXT NOT NULL,
      actor_user_id TEXT NOT NULL,
      action_id TEXT,
      committed INTEGER NOT NULL
    );
  `)
  database.prepare('INSERT INTO worlds (world_key, head_json) VALUES (?, ?)')
    .run(options.initialHead.worldKey, JSON.stringify(options.initialHead))
  const insertActor = database.prepare('INSERT INTO actors (token, user_id) VALUES (?, ?)')
  for (const [token, userId] of Object.entries(options.actorTokens)) insertActor.run(token, userId)

  const readHead = database.prepare('SELECT head_json FROM worlds WHERE world_key = ?')
  const writeHead = database.prepare('UPDATE worlds SET head_json = ? WHERE world_key = ?')
  const readActor = database.prepare('SELECT user_id FROM actors WHERE token = ?')
  const audit = database.prepare('INSERT INTO transaction_audit (kind, actor_user_id, action_id, committed) VALUES (?, ?, ?, ?)')

  function head(worldKey: string): SharedWorldHead | undefined {
    const row = readHead.get(worldKey) as { head_json: string } | undefined
    return row ? JSON.parse(row.head_json) as SharedWorldHead : undefined
  }

  function actor(request: IncomingMessage): string | undefined {
    const token = bearer(request)
    if (!token) return undefined
    return (readActor.get(token) as { user_id: string } | undefined)?.user_id
  }

  const server = createServer(async (request, response) => {
    try {
      const url = new URL(request.url ?? '/', 'http://127.0.0.1')
      if (request.method === 'GET' && url.pathname === '/api/health') {
        send(response, 200, {
          storage: 'sqlite-transactional',
          identity_mode: 'qa-server-bound-session',
          ruleset_id: activeRuleset.id,
          ruleset_version: activeRuleset.version,
          deployment: false,
        })
        return
      }
      const actorUserId = actor(request)
      if (!actorUserId) {
        send(response, 401, { code: 'AUTH_REQUIRED' })
        return
      }
      const body = request.method === 'POST' ? await readJson(request) : {}
      const worldKey = String(body.world_key ?? url.searchParams.get('world_key') ?? '')
      const current = head(worldKey)
      if (!current) {
        send(response, 404, { code: 'WORLD_MISMATCH' })
        return
      }

      if (request.method === 'GET' && url.pathname === '/api/world/state') {
        const cursor = Number(url.searchParams.get('after_cursor') ?? 0)
        send(response, 200, {
          worldKey: current.worldKey,
          rulesetId: current.rulesetId,
          rulesetVersion: current.rulesetVersion,
          version: current.version,
          cursor: current.cursor,
          availableActions: enumerateExecutableActions(current.snapshot, activeRuleset, actorUserId),
          events: eventsAfterCursor(current, Number.isFinite(cursor) ? Math.max(0, cursor) : 0),
        })
        return
      }

      if (request.method === 'POST' && url.pathname === '/api/world/action') {
        database.exec('BEGIN IMMEDIATE')
        try {
          const lockedHead = head(worldKey)!
          const result = applySharedAction(lockedHead, activeRuleset, {
            worldKey,
            actorUserId,
            actionId: String(body.action_id ?? ''),
            expectedVersion: Number(body.expected_version),
            rulesetVersion: Number(body.ruleset_version),
            actionDefinitionId: String(body.action_definition_id ?? ''),
          })
          if (result.response.ok && !result.response.replayed) {
            writeHead.run(JSON.stringify(result.head), worldKey)
            audit.run('action', actorUserId, result.response.actionId, 1)
          }
          database.exec('COMMIT')
          if (
            result.response.ok
            && !result.response.replayed
            && dropActionResponseAfterCommit.has(result.response.actionId)
            && !failedDroppedResponses.has(result.response.actionId)
          ) {
            failedDroppedResponses.add(result.response.actionId)
            response.destroy(new Error('INJECTED_RESPONSE_LOSS_AFTER_COMMIT'))
            return
          }
          const status = result.response.ok ? 200 : result.response.code === 'VERSION_CONFLICT' ? 409 : 422
          send(response, status, result.response)
        } catch (error) {
          database.exec('ROLLBACK')
          throw error
        }
        return
      }

      if (request.method === 'GET' && url.pathname === '/api/world/grants') {
        send(response, 200, { receipts: listPendingReceipts(current, actorUserId) })
        return
      }

      if (request.method === 'POST' && url.pathname === '/api/world/grant/ack') {
        database.exec('BEGIN IMMEDIATE')
        try {
          const lockedHead = head(worldKey)!
          const receiptId = String(body.receipt_id ?? '')
          const persistedReceiptIds = Array.isArray(body.persisted_receipt_ids)
            ? body.persisted_receipt_ids.map(String)
            : []
          if (
            persistedReceiptIds.includes(receiptId)
            && failGrantAckOnce.has(receiptId)
            && !failedGrantAcks.has(receiptId)
          ) {
            failedGrantAcks.add(receiptId)
            database.exec('ROLLBACK')
            send(response, 503, { ok: false, reason: 'INJECTED_ACK_TRANSPORT_FAILURE' })
            return
          }
          const result = acknowledgeReceipt(lockedHead, actorUserId, receiptId, persistedReceiptIds)
          if (result.ok && result.head !== lockedHead) {
            writeHead.run(JSON.stringify(result.head), worldKey)
            audit.run('receipt-ack', actorUserId, receiptId, 1)
          }
          database.exec('COMMIT')
          send(response, result.ok ? 200 : 409, { ok: result.ok, reason: result.reason })
        } catch (error) {
          database.exec('ROLLBACK')
          throw error
        }
        return
      }

      send(response, 404, { code: 'ENTITY_NOT_FOUND' })
    } catch (error) {
      send(response, 500, { code: 'INTERNAL_ERROR', message: error instanceof Error ? error.message : String(error) })
    }
  })

  return {
    async listen() {
      await new Promise<void>((resolve, reject) => {
        server.once('error', reject)
        server.listen(0, '127.0.0.1', () => resolve())
      })
      const address = server.address()
      if (!address || typeof address === 'string') throw new Error('HTTP authority did not bind a TCP port')
      return { baseUrl: `http://127.0.0.1:${address.port}` }
    },
    async close() {
      await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()))
      database.close()
    },
    actionTransactionCount() {
      const row = database.prepare("SELECT COUNT(*) AS count FROM transaction_audit WHERE kind = 'action' AND committed = 1").get() as { count: number }
      return Number(row.count)
    },
    upgradeRuleset(nextRuleset: AuthorityRuleset) {
      if (nextRuleset.id !== activeRuleset.id) throw new Error('Ruleset id cannot change in-place')
      const current = head(options.initialHead.worldKey)
      if (!current) throw new Error('World missing during ruleset upgrade')
      current.rulesetVersion = nextRuleset.version
      current.snapshot.rulesetVersion = nextRuleset.version
      writeHead.run(JSON.stringify(current), current.worldKey)
      activeRuleset = nextRuleset
    },
  }
}
