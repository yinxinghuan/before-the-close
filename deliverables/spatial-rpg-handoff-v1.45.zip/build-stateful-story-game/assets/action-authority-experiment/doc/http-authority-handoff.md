# 异步多人行动权威候选适配合同

## 目的与边界

这份合同用于把已经通过纯 reducer、本地 gateway 和 HTTP + SQLite 实验的行动权威层接到接收方自己的后端。它不规定部署平台、仓库、域名、Worker 工具或数据库产品，也不包含发布流程。

当前已验证的是：稳定行动、版本冲突、幂等重放、稀缺资源、唯一物品双回执、事件游标、公私隔离、服务端会话绑定，以及本机真实 HTTP 边界下的提交后响应丢失、三次重复提交、回执保存/确认故障、规则升级和失效会话。尚未验证的是平台签名身份、接收方运行时多实例并发、两个真实认证设备和真实个人云存档故障注入。

## 身份合同

- 浏览器通过接收方认可的不透明会话凭据认证；示例客户端使用 `Authorization: Bearer <session>`。
- 行动请求体不发送 `actorUserId`、`user_id` 或可决定行动者的等价字段。
- 后端从已验证会话解析 actor，并用该 actor 执行前置条件、幂等键、事件作者和回执归属。
- 如果兼容旧客户端而暂时收到 actor 字段，后端必须忽略它；不得与会话身份二选一。
- 当前本地测试使用预注册 QA token，只证明绑定逻辑，不能对外宣称平台认证。
- `platformIdentity.ts` 只接受“已经由后端完成密码学验证”的 proof，并二次约束 issuer、audience、game id、subject、session、有效期、token id 和 scope；它不是签名验证器，也绝不能把 query 参数升级成 proof。完整适配见 `platform-identity-contract.md`。

## API 表面

所有路径都相对于游戏自己的 Remix-safe API base；客户端不得写死源游戏 URL。

| 方法与路径 | 请求 | 响应职责 |
| --- | --- | --- |
| `GET /api/health` | 无 | 存储类型、规则版本、身份模式；不得泄露凭据 |
| `GET /api/world/state` | `world_key`, `after_cursor` | 当前 `version/cursor`、该 actor 此刻可执行的行动、游标后的公开事件 |
| `POST /api/world/action` | `world_key`, `action_id`, `expected_version`, `ruleset_version`, `action_definition_id` | 原子提交或稳定错误；不接受 actor 字段 |
| `GET /api/world/grants` | `world_key`, `status=pending` | 仅当前 actor 的私人待处理回执 |
| `POST /api/world/grant/ack` | `world_key`, `receipt_id`, `persisted_receipt_ids` | 只在个人存档读回已包含 receipt id 后确认 |

生产多人基线中的 `ensure/history/report/media` 可以继续存在；它们不是本轮最小适配器的替代品，也不能绕过行动事务。

## 行动事务顺序

每个 `POST /api/world/action` 必须在一次数据库事务中执行：

1. 由会话解析 actor。
2. 用 `(world_key, actor_id, action_id)` 查询第一次结果；命中时原样返回，不再比较版本。
3. 锁定并读取世界头。
4. 校验 `ruleset_version` 与 `expected_version`。
5. 用当前快照重新枚举/验证 `action_definition_id`；不能信任客户端仍然看见该选项。
6. 一次性计算全部共享状态、事件和私人回执。
7. 原子写入新快照、递增后的 `version/cursor`、公共事件、回执和缓存结果。
8. 提交后再进行 AI 文案、图片、通知和分析；这些失败不能回滚世界。

候选实验用 SQLite `BEGIN IMMEDIATE` 验证了上述顺序。接收方可用 Durable Object、SQL 行锁、序列化事务或等价机制实现，但必须保留可证明的单次提交语义。

## 稳定错误

- `AUTH_REQUIRED`：无有效服务端身份。
- `WORLD_MISMATCH`：世界不存在或不属于当前游戏。
- `RULESET_MISMATCH`：客户端规则版本过期。
- `VERSION_CONFLICT`：世界已经变化；客户端读取新状态并用同一 action id 重新验证。
- `INVALID_ACTION`：行动不存在或当前前置不成立，返回具体玩家可理解原因。
- `RECEIPT_NOT_FOUND`：回执不存在或不属于当前 actor。
- `PRIVATE_SAVE_NOT_VERIFIED`：个人存档读回尚未包含该 receipt id。

`VERSION_CONFLICT` 不是故事失败。客户端最多重试三次；刷新后行动已不可执行时停止提交并展示新状态中的可行行动。

网络超时也不是故事失败，而是“提交结果未知”。客户端必须保留原 `action_id`，先从旧 cursor 拉取事件并按 action id 对账；未找到时才用相同 id 重试。若提交和对账都不可达，界面保持 pending/unknown，不得生成“没有成功”正文。实验中的 `submitWithAuthorityRecovery` 已验证提交落库后丢失 HTTP 响应仍可收敛到唯一事件。

## 最小验收

1. 两个独立会话从同一版本争抢一个单位，只提交一次。
2. 成功 action id 重放三次，世界版本只增加一次。
3. 失败客户端刷新后不再看到已失效行动。
4. 请求体显式伪造另一 actor，服务端仍按会话 actor 拒绝。
5. 唯一物品移交生成发送方 remove 和接收方 add 两张回执，公共保管人只改变一次。
6. 未经个人存档读回验证不能 ack；断线重进仍能看到 pending receipt。
7. 从旧 cursor 读取，每个公开事件只出现一次且顺序稳定。
8. 公开快照/事件不含私人关系、私聊、自由输入、私人背包或回执同步状态。
9. 关闭 AI、媒体、通知后，1–8 仍全部成立。
10. 提交成功后主动丢弃响应；客户端按原 action id 对账，不能叙述失败。
11. 个人存档写入失败以及第一次 ack 失败时，receipt 都保持 pending，重试后只入账一次。
12. 服务端规则升级后，旧客户端得到 `RULESET_MISMATCH` 且世界不写入；失效会话不得回退成请求体 actor。
13. 在接收方真实运行时、多实例、两个真实认证设备和个人云存档失败注入下重复 1–12。

前十二项的本地/合同部分可以由工程自动化完成；第十三项是冻结可复用多人模板前仍需接收方配合的门槛。
