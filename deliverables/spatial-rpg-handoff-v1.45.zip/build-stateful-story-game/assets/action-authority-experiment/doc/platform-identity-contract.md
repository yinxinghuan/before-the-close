# 平台身份适配合同（接收方后端）

## 目标

多人权威服务只能相信平台或接收方后端签发、且能由服务端验证的短期证明。URL 中的用户编号、浏览器 profile、请求体 `actor_user_id`、localStorage 和前端签名都不是身份凭据。

## 推荐交换

1. 宿主平台向游戏入口提供短期 bootstrap proof，或提供服务端 introspection 接口。
2. 游戏后端验证签名、`kid/alg`、issuer、audience、generated game id、有效期和唯一 token id。
3. 验证 membership/block 状态，并把稳定 `subject` 绑定为 actor。
4. 后端签发仅限该游戏、短期、可撤销的不透明 session；浏览器只持有这个 session。
5. 每次共享写入由后端 session 解析 actor；请求体中的 actor 字段一律忽略或拒绝。

最低 claims：`issuer`、`audience`、`gameId`、稳定 `subject`、`sessionId`、`issuedAt`、`expiresAt`、`tokenId/jti`、窄 scope（例如 `world:read/world:act`）。建议 bootstrap TTL 不超过 10 分钟，并允许小幅时钟偏差。签名算法和 JWKS/introspection 由接收方平台决定；本实验不捆绑供应商。

## 失败语义

- 签名、issuer、audience、game id、有效期或 scope 任一失败：`401 AUTH_REQUIRED`，不创建匿名 actor。
- membership/block 失败：稳定的 `403`，不能借刷新 token 绕过。
- session 过期：客户端重新走宿主身份交换；不得回退 raw user id。
- token id 重放：按平台合同拒绝或只返回第一次会话结果。

## 机械验收

- 正确 proof 绑定唯一 actor；不同 session 的同一 subject 仍属于同一 actor。
- wrong audience、wrong game、过期、尚未生效、过长 TTL、缺 scope、未验证 proof 全拒绝。
- 请求体伪造另一 actor 不改变事件作者、幂等命名空间或 receipt 归属。
- session 过期/撤销后读写都失败，且无 query/profile/anonymous 回退。
- 两个真实认证账号在真实权威运行时争抢一个单位，只能有一个事务赢家。

`src/story/experimental/platformIdentity.ts` 是密码学验证后的 claims 约束夹具，不负责验证真实签名。真实平台签名、密钥轮换、revocation、block 和删除审计仍是接收方后端职责。
