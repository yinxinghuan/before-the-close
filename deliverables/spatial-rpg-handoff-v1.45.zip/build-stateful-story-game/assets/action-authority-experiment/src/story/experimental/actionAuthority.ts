export type Locale = 'zh' | 'en'
export type FactValue = string | number | boolean | null

export interface LocalizedText {
  zh: string
  en: string
}

export interface AuthorityEntity {
  id: string
  kind: 'location' | 'object' | 'character'
  label: LocalizedText
  aliases: string[]
  locationId?: string
  status?: string
  capabilities?: string[]
}

export interface ActiveThread {
  id: string
  kind: string
  locationId: string
  participantIds: string[]
  phase: 'active' | 'resolved'
}

export type AuthorityRequirement =
  | { type: 'actor'; id: string; reason: LocalizedText }
  | { type: 'location'; id: string; reason: LocalizedText }
  | { type: 'stat'; id: string; min?: number; max?: number; reason: LocalizedText }
  | { type: 'fact'; id: string; equals?: FactValue; notEquals?: FactValue; reason: LocalizedText }
  | { type: 'item'; id: string; min: number; reason: LocalizedText }
  | { type: 'entity'; id: string; locationId?: string; status?: string; reason: LocalizedText }
  | { type: 'capability'; id: string; reason: LocalizedText }
  | { type: 'thread'; id?: string; kind?: string; phase: ActiveThread['phase']; reason: LocalizedText }

export type AuthorityEffect =
  | { type: 'stat'; id: string; delta: number }
  | { type: 'fact'; id: string; value: FactValue }
  | { type: 'fact-add'; id: string; delta: number }
  | { type: 'item'; id: string; delta: number }
  | { type: 'move'; locationId: string }
  | { type: 'entity'; id: string; locationId?: string; status?: string }
  | { type: 'thread-start'; thread: ActiveThread }
  | { type: 'thread-resolve' }
  | { type: 'clock'; scenes?: number; days?: number }
  | { type: 'grant-receipt'; itemId: string; count: number; actorUserId?: string }

export type RepeatPolicy =
  | { scope: 'once'; reason: LocalizedText }
  | { scope: 'actor-once'; reason: LocalizedText }
  | { scope: 'location-day'; reason: LocalizedText }
  | { scope: 'cooldown'; scenes: number; reason: LocalizedText }

export type ThreadPolicy = 'calm-only' | 'requires-active' | 'preserve' | 'resolve' | 'any'

export interface ActionDefinition {
  id: string
  label: LocalizedText
  intent: string
  matches: string[]
  targetId?: string
  toolId?: string
  rank?: number
  visibleWhen?: AuthorityRequirement[]
  requirements: AuthorityRequirement[]
  effects: AuthorityEffect[]
  repeat?: RepeatPolicy
  threadPolicy?: ThreadPolicy
  successText: LocalizedText
  publicEvent?: { type: string; payload: Record<string, FactValue> }
}

export interface ScheduledEventDefinition {
  id: string
  minimumScene: number
  probabilityBasisPoints: number
  once?: boolean
  requirements: AuthorityRequirement[]
  effects: AuthorityEffect[]
  text: LocalizedText
}

export interface AuthorityRuleset {
  id: string
  version: number
  locale: Locale
  locations: string[]
  locationCapabilities: Record<string, string[]>
  statBounds: Record<string, { min: number; max: number }>
  entities: Record<string, AuthorityEntity>
  actions: ActionDefinition[]
  events?: ScheduledEventDefinition[]
}

export interface ActionRecord {
  actionId: string
  definitionId: string
  actorId: string
  scene: number
  day: number
  locationId: string
  effects: AuthorityEffect[]
  eventIds: string[]
}

export interface ScheduledEventRecord {
  id: string
  scene: number
  sourceActionId: string
  effects: AuthorityEffect[]
}

export interface AuthorityState {
  schemaVersion: 1
  rulesetId: string
  rulesetVersion: number
  scene: number
  day: number
  currentLocationId: string
  stats: Record<string, number>
  facts: Record<string, FactValue>
  inventory: Record<string, number>
  entities: Record<string, { locationId?: string; status?: string }>
  activeThread?: ActiveThread
  actionLedger: ActionRecord[]
  eventLedger: ScheduledEventRecord[]
  eventSeed: string
}

export interface ExecutableAction {
  id: string
  label: string
  intent: string
  rank: number
}

export interface GrantEmission {
  itemId: string
  count: number
  actorUserId?: string
}

export interface CommitResult {
  status: 'committed' | 'rejected' | 'replayed' | 'clarify' | 'unmatched'
  state: AuthorityState
  action?: ActionDefinition
  reasons: string[]
  text: string
  choices: ExecutableAction[]
  emissions: GrantEmission[]
  replayOf?: ActionRecord
  candidates?: ExecutableAction[]
}

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T
}

function local(text: LocalizedText, locale: Locale): string {
  return text[locale]
}

function normalized(value: string): string {
  return value.toLocaleLowerCase()
    .normalize('NFKC')
    .replace(/[\s\p{P}\p{S}]+/gu, '')
}

function orderedSubsequence(needle: string, haystack: string): boolean {
  if (needle.length < 4 || needle.length / haystack.length < 0.45) return false
  let cursor = 0
  for (const character of haystack) {
    if (character === needle[cursor]) cursor += 1
    if (cursor === needle.length) return true
  }
  return false
}

function stableHash(value: string): number {
  let hash = 2166136261
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index)
    hash = Math.imul(hash, 16777619)
  }
  return hash >>> 0
}

function requirementMet(
  requirement: AuthorityRequirement,
  state: AuthorityState,
  ruleset: AuthorityRuleset,
  actorId: string,
): boolean {
  if (requirement.type === 'actor') return actorId === requirement.id
  if (requirement.type === 'location') return state.currentLocationId === requirement.id
  if (requirement.type === 'stat') {
    const value = state.stats[requirement.id]
    if (!Number.isFinite(value)) return false
    if (requirement.min !== undefined && value < requirement.min) return false
    if (requirement.max !== undefined && value > requirement.max) return false
    return true
  }
  if (requirement.type === 'fact') {
    const value = state.facts[requirement.id]
    if (requirement.equals !== undefined && value !== requirement.equals) return false
    if (requirement.notEquals !== undefined && value === requirement.notEquals) return false
    return true
  }
  if (requirement.type === 'item') return (state.inventory[requirement.id] ?? 0) >= requirement.min
  if (requirement.type === 'entity') {
    const entity = state.entities[requirement.id] ?? ruleset.entities[requirement.id]
    if (!entity) return false
    if (requirement.locationId !== undefined && entity.locationId !== requirement.locationId) return false
    if (requirement.status !== undefined && entity.status !== requirement.status) return false
    return true
  }
  if (requirement.type === 'capability') {
    return (ruleset.locationCapabilities[state.currentLocationId] ?? []).includes(requirement.id)
  }
  const thread = state.activeThread
  if (!thread) return false
  if (requirement.id !== undefined && thread.id !== requirement.id) return false
  if (requirement.kind !== undefined && thread.kind !== requirement.kind) return false
  return thread.phase === requirement.phase
}

function repeatReason(
  action: ActionDefinition,
  state: AuthorityState,
  actorId: string,
  ruleset: AuthorityRuleset,
): string | undefined {
  if (!action.repeat) return undefined
  const records = state.actionLedger.filter((record) => record.definitionId === action.id)
  if (action.repeat.scope === 'once' && records.length) return local(action.repeat.reason, ruleset.locale)
  if (action.repeat.scope === 'actor-once' && records.some((record) => record.actorId === actorId)) {
    return local(action.repeat.reason, ruleset.locale)
  }
  if (action.repeat.scope === 'location-day' && records.some((record) => (
    record.actorId === actorId && record.locationId === state.currentLocationId && record.day === state.day
  ))) return local(action.repeat.reason, ruleset.locale)
  if (action.repeat.scope === 'cooldown') {
    const latest = records.filter((record) => record.actorId === actorId).at(-1)
    if (latest && state.scene - latest.scene < action.repeat.scenes) return local(action.repeat.reason, ruleset.locale)
  }
  return undefined
}

function threadReason(action: ActionDefinition, state: AuthorityState, ruleset: AuthorityRuleset): string | undefined {
  const policy = action.threadPolicy ?? 'calm-only'
  const active = state.activeThread?.phase === 'active'
  if (active && policy === 'calm-only') {
    return ruleset.locale === 'zh' ? '当前冲突尚未解决，这个行动会让正在发生的事情消失。' : 'The active conflict must be addressed before this action.'
  }
  if (!active && (policy === 'requires-active' || policy === 'preserve' || policy === 'resolve')) {
    return ruleset.locale === 'zh' ? '当前没有需要这个行动处理的冲突。' : 'There is no active conflict for this action.'
  }
  return undefined
}

export function rejectionReasons(
  action: ActionDefinition,
  state: AuthorityState,
  ruleset: AuthorityRuleset,
  actorId = 'player',
): string[] {
  const reasons = action.requirements
    .filter((requirement) => !requirementMet(requirement, state, ruleset, actorId))
    .map((requirement) => local(requirement.reason, ruleset.locale))
  const thread = threadReason(action, state, ruleset)
  if (thread) reasons.push(thread)
  const repeat = repeatReason(action, state, actorId, ruleset)
  if (repeat) reasons.push(repeat)
  return [...new Set(reasons)]
}

export function enumerateExecutableActions(
  state: AuthorityState,
  ruleset: AuthorityRuleset,
  actorId = 'player',
): ExecutableAction[] {
  return ruleset.actions
    .filter((action) => (action.visibleWhen ?? []).every((requirement) => requirementMet(requirement, state, ruleset, actorId)))
    .filter((action) => rejectionReasons(action, state, ruleset, actorId).length === 0)
    .map((action, index) => ({
      id: action.id,
      label: local(action.label, ruleset.locale),
      intent: action.intent,
      rank: action.rank ?? index,
    }))
    .sort((left, right) => left.rank - right.rank || left.id.localeCompare(right.id))
}

export interface ParsedActionIntent {
  status: 'matched' | 'clarify' | 'unmatched'
  action?: ActionDefinition
  candidates: ActionDefinition[]
}

export function parseActionIntent(
  input: string,
  source: 'button' | 'free-input',
  ruleset: AuthorityRuleset,
): ParsedActionIntent {
  if (source === 'button') {
    const action = ruleset.actions.find((candidate) => candidate.id === input)
    return action ? { status: 'matched', action, candidates: [action] } : { status: 'unmatched', candidates: [] }
  }
  const value = normalized(input)
  if (!value) return { status: 'unmatched', candidates: [] }
  const scored = ruleset.actions.map((action) => {
    const phrases = [action.id, action.label.zh, action.label.en, ...action.matches]
      .map(normalized)
      .filter(Boolean)
    const score = phrases.reduce((best, phrase) => {
      if (value === phrase) return Math.max(best, 100_000 + phrase.length)
      if (value.includes(phrase)) return Math.max(best, 10_000 + phrase.length)
      if (phrase.includes(value) && value.length >= 2) return Math.max(best, 1_000 + value.length)
      if (orderedSubsequence(phrase, value)) return Math.max(best, 500 + phrase.length)
      return best
    }, 0)
    return { action, score }
  }).filter((entry) => entry.score > 0).sort((left, right) => right.score - left.score || left.action.id.localeCompare(right.action.id))
  if (!scored.length) return { status: 'unmatched', candidates: [] }
  const best = scored[0]!.score
  const candidates = scored.filter((entry) => entry.score === best).map((entry) => entry.action)
  return candidates.length === 1
    ? { status: 'matched', action: candidates[0], candidates }
    : { status: 'clarify', candidates }
}

function applyEffects(
  state: AuthorityState,
  effects: AuthorityEffect[],
  ruleset: AuthorityRuleset,
): { state: AuthorityState; emissions: GrantEmission[]; error?: string } {
  const next = clone(state)
  const emissions: GrantEmission[] = []
  for (const effect of effects) {
    if (effect.type === 'stat') {
      const bounds = ruleset.statBounds[effect.id]
      const current = next.stats[effect.id]
      if (!bounds || !Number.isFinite(current)) return { state, emissions: [], error: `Unknown stat: ${effect.id}` }
      next.stats[effect.id] = Math.min(bounds.max, Math.max(bounds.min, current + effect.delta))
    }
    if (effect.type === 'fact') next.facts[effect.id] = effect.value
    if (effect.type === 'fact-add') {
      const current = next.facts[effect.id] ?? 0
      if (typeof current !== 'number') return { state, emissions: [], error: `Fact is not numeric: ${effect.id}` }
      next.facts[effect.id] = current + effect.delta
    }
    if (effect.type === 'item') {
      const count = (next.inventory[effect.id] ?? 0) + effect.delta
      if (count < 0) return { state, emissions: [], error: `Negative inventory: ${effect.id}` }
      next.inventory[effect.id] = count
    }
    if (effect.type === 'move') {
      if (!ruleset.locations.includes(effect.locationId)) return { state, emissions: [], error: `Unknown location: ${effect.locationId}` }
      next.currentLocationId = effect.locationId
    }
    if (effect.type === 'entity') {
      const entity = next.entities[effect.id] ?? ruleset.entities[effect.id]
      if (!entity) return { state, emissions: [], error: `Unknown entity: ${effect.id}` }
      next.entities[effect.id] = {
        locationId: effect.locationId ?? entity.locationId,
        status: effect.status ?? entity.status,
      }
    }
    if (effect.type === 'thread-start') next.activeThread = clone(effect.thread)
    if (effect.type === 'thread-resolve') {
      // Resolving is intentionally idempotent. An action may still be valid after
      // another effect or actor has already closed the thread; that must not turn
      // an enumerated route into a dead choice at commit time.
      if (next.activeThread) next.activeThread = { ...next.activeThread, phase: 'resolved' }
    }
    if (effect.type === 'clock') {
      next.scene += effect.scenes ?? 0
      next.day += effect.days ?? 0
    }
    if (effect.type === 'grant-receipt') emissions.push({
      itemId: effect.itemId,
      count: effect.count,
      actorUserId: effect.actorUserId,
    })
  }
  return { state: next, emissions }
}

function scheduleEvents(
  state: AuthorityState,
  ruleset: AuthorityRuleset,
  sourceActionId: string,
  actorId: string,
): { state: AuthorityState; eventIds: string[] } {
  let next = clone(state)
  const eventIds: string[] = []
  for (const event of [...(ruleset.events ?? [])].sort((left, right) => left.id.localeCompare(right.id))) {
    if (next.scene < event.minimumScene) continue
    if (event.once && next.eventLedger.some((record) => record.id === event.id)) continue
    if (!event.requirements.every((requirement) => requirementMet(requirement, next, ruleset, actorId))) continue
    const roll = stableHash(`${next.eventSeed}|${ruleset.id}|${ruleset.version}|${event.id}|${next.scene}|${sourceActionId}`) % 10_000
    if (roll >= event.probabilityBasisPoints) continue
    const applied = applyEffects(next, event.effects, ruleset)
    if (applied.error) throw new Error(`Invalid event ${event.id}: ${applied.error}`)
    next = applied.state
    next.eventLedger.push({ id: event.id, scene: next.scene, sourceActionId, effects: clone(event.effects) })
    eventIds.push(event.id)
  }
  return { state: next, eventIds }
}

export function commitAction(
  state: AuthorityState,
  ruleset: AuthorityRuleset,
  action: ActionDefinition,
  actionId: string,
  actorId = 'player',
): CommitResult {
  // Client-generated action ids are only required to be unique per actor. Two
  // asynchronous players may legitimately produce the same local id.
  const replay = state.actionLedger.find((record) => record.actionId === actionId && record.actorId === actorId)
  if (replay) {
    return {
      status: 'replayed', state, action, replayOf: replay, reasons: [],
      text: local(action.successText, ruleset.locale),
      choices: enumerateExecutableActions(state, ruleset, actorId), emissions: [],
    }
  }
  const reasons = rejectionReasons(action, state, ruleset, actorId)
  if (reasons.length) {
    return {
      status: 'rejected', state, action, reasons, text: reasons.join(' '),
      choices: enumerateExecutableActions(state, ruleset, actorId), emissions: [],
    }
  }
  const applied = applyEffects(state, action.effects, ruleset)
  if (applied.error) {
    return {
      status: 'rejected', state, action, reasons: [applied.error], text: applied.error,
      choices: enumerateExecutableActions(state, ruleset, actorId), emissions: [],
    }
  }
  let next = applied.state
  next.scene += 1
  const scheduled = scheduleEvents(next, ruleset, actionId, actorId)
  next = scheduled.state
  const record: ActionRecord = {
    actionId,
    definitionId: action.id,
    actorId,
    scene: next.scene,
    day: next.day,
    locationId: state.currentLocationId,
    effects: clone(action.effects),
    eventIds: scheduled.eventIds,
  }
  next.actionLedger.push(record)
  return {
    status: 'committed', state: next, action, reasons: [],
    text: local(action.successText, ruleset.locale),
    choices: enumerateExecutableActions(next, ruleset, actorId), emissions: applied.emissions,
  }
}

export function resolveActionInput(
  state: AuthorityState,
  ruleset: AuthorityRuleset,
  input: string,
  options: { source: 'button' | 'free-input'; actionId: string; actorId?: string },
): CommitResult {
  const parsed = parseActionIntent(input, options.source, ruleset)
  const actorId = options.actorId ?? 'player'
  if (parsed.status === 'unmatched') {
    const text = ruleset.locale === 'zh'
      ? '这个行动还没有确定的规则；保持当前状态，交给开放叙事流程处理。'
      : 'No deterministic rule matches this action; state is unchanged for the open narrative flow.'
    return { status: 'unmatched', state, reasons: [], text, choices: enumerateExecutableActions(state, ruleset, actorId), emissions: [] }
  }
  if (parsed.status === 'clarify') {
    const candidates = parsed.candidates.map((action, index) => ({
      id: action.id, label: local(action.label, ruleset.locale), intent: action.intent, rank: action.rank ?? index,
    }))
    const text = ruleset.locale === 'zh' ? '这个说法对应多个行动，请说明具体目标。' : 'This could mean more than one action; choose a specific target.'
    return { status: 'clarify', state, reasons: [text], text, choices: enumerateExecutableActions(state, ruleset, actorId), emissions: [], candidates }
  }
  return commitAction(state, ruleset, parsed.action!, options.actionId, actorId)
}

export function serializeAuthorityState(state: AuthorityState): string {
  return JSON.stringify(state)
}

export function restoreAuthorityState(serialized: string, ruleset: AuthorityRuleset): AuthorityState {
  const parsed = JSON.parse(serialized) as AuthorityState
  if (parsed.schemaVersion !== 1) throw new Error('Unsupported authority state schema')
  if (parsed.rulesetId !== ruleset.id || parsed.rulesetVersion !== ruleset.version) throw new Error('Ruleset mismatch')
  return parsed
}
