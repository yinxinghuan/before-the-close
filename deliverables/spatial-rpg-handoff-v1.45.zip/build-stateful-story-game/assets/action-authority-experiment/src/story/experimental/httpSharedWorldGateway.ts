import type { GrantReceipt, SharedActionResponse } from './sharedWorldAuthority'
import type { BoundSharedAuthorityGateway, SharedWorldView } from './sharedWorldGateway'

type FetchLike = typeof fetch

type ApiError = Error & {
  code: string
  status: number
  payload?: unknown
}

async function decode(response: Response): Promise<unknown> {
  return response.json().catch(() => ({ code: `HTTP_${response.status}` }))
}

export function createHttpBoundAuthorityGateway(options: {
  apiBase: string
  worldKey: string
  rulesetVersion: number
  actorSessionToken: string
  fetchImpl?: FetchLike
}): BoundSharedAuthorityGateway {
  const apiBase = options.apiBase.replace(/\/+$/, '')
  const request = options.fetchImpl ?? fetch

  async function api<T>(path: string, init?: RequestInit): Promise<T> {
    const response = await request(`${apiBase}${path}`, {
      ...init,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${options.actorSessionToken}`,
        ...(init?.headers ?? {}),
      },
    })
    const payload = await decode(response) as T & { code?: string }
    if (!response.ok) {
      const error = new Error(payload.code ?? `HTTP_${response.status}`) as ApiError
      error.code = payload.code ?? `HTTP_${response.status}`
      error.status = response.status
      error.payload = payload
      throw error
    }
    return payload
  }

  async function submit(requestBody: {
    actionId: string
    expectedVersion: number
    actionDefinitionId: string
  }): Promise<SharedActionResponse> {
    const response = await request(`${apiBase}/api/world/action`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${options.actorSessionToken}`,
      },
      body: JSON.stringify({
        world_key: options.worldKey,
        action_id: requestBody.actionId,
        expected_version: requestBody.expectedVersion,
        ruleset_version: options.rulesetVersion,
        action_definition_id: requestBody.actionDefinitionId,
      }),
    })
    return await decode(response) as SharedActionResponse
  }

  return {
    async read(cursor = 0): Promise<SharedWorldView> {
      const query = new URLSearchParams({
        world_key: options.worldKey,
        after_cursor: String(Math.max(0, cursor)),
      })
      return api<SharedWorldView>(`/api/world/state?${query}`)
    },
    submit,
    async pendingReceipts(): Promise<GrantReceipt[]> {
      const query = new URLSearchParams({ world_key: options.worldKey, status: 'pending' })
      const payload = await api<{ receipts: GrantReceipt[] }>(`/api/world/grants?${query}`)
      return payload.receipts
    },
    async acknowledge(receiptId: string, persistedReceiptIds: string[]) {
      const response = await request(`${apiBase}/api/world/grant/ack`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${options.actorSessionToken}`,
        },
        body: JSON.stringify({
          world_key: options.worldKey,
          receipt_id: receiptId,
          persisted_receipt_ids: persistedReceiptIds,
        }),
      })
      return await decode(response) as { ok: boolean; reason?: string }
    },
  }
}
