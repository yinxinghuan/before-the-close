import type {
  ActionDefinition,
  AuthorityEntity,
  AuthorityRuleset,
  AuthorityState,
  Locale,
  LocalizedText,
} from './actionAuthority'
import type { SharedWorldHead } from './sharedWorldAuthority'

const text = (zh: string, en: string): LocalizedText => ({ zh, en })

function entity(
  id: string,
  kind: AuthorityEntity['kind'],
  zh: string,
  en: string,
  aliases: string[],
  locationId?: string,
): AuthorityEntity {
  return { id, kind, label: text(zh, en), aliases, locationId }
}

const locations = ['hotel-lobby', 'second-floor-corridor', 'room-seven']

function personalActions(): ActionDefinition[] {
  return [
    {
      id: 'inspect-directory', label: text('查看黄铜住客目录', 'Inspect the brass guest directory'),
      intent: 'inspect-directory', matches: ['查看黄铜目录', '检查住客目录', 'inspect guest directory'], rank: 10,
      requirements: [
        { type: 'location', id: 'hotel-lobby', reason: text('住客目录留在旅馆前台。', 'The directory is at the hotel desk.') },
        { type: 'capability', id: 'inspect-records', reason: text('这里没有可查阅的登记资料。', 'There are no records to inspect here.') },
      ],
      effects: [{ type: 'stat', id: 'clues', delta: 1 }, { type: 'fact', id: 'directory-read', value: true }],
      repeat: { scope: 'once', reason: text('目录中的有效线索已经记录，不会重复增加。', 'The useful directory clue is already recorded.') },
      successText: text('目录显示八号房之后本应直接到楼梯，却留下了一行被刮去的编号。', 'The directory jumps from Room Eight to the stairs, with one scraped-out line between them.'),
    },
    {
      id: 'ask-mara-red-lights', label: text('询问玛拉红灯熄灭的顺序', 'Ask Mara about the order of the red lights'),
      intent: 'ask-mara-red-lights', matches: ['问玛拉红灯', '询问玛拉', 'ask mara about the red lights'], rank: 20,
      requirements: [
        { type: 'location', id: 'hotel-lobby', reason: text('玛拉现在不在你身边。', 'Mara is not beside you now.') },
        { type: 'entity', id: 'mara', locationId: 'hotel-lobby', reason: text('玛拉已经离开前台。', 'Mara has left the desk.') },
      ],
      effects: [{ type: 'fact', id: 'mara-warning-heard', value: true }],
      repeat: { scope: 'once', reason: text('玛拉已经说完她知道的顺序。', 'Mara has already told you the order she knows.') },
      successText: text('玛拉说红灯从楼梯口向七号房逐盏熄灭，从未反向。', 'Mara says the red lights always go out from the stairs toward Room Seven, never in reverse.'),
    },
    {
      id: 'go-second-floor', label: text('沿楼梯前往二层红灯走廊', 'Take the stairs to the second-floor red corridor'),
      intent: 'go-second-floor', matches: ['去二层', '前往红灯走廊', 'go to the second floor'], rank: 30,
      requirements: [
        { type: 'location', id: 'hotel-lobby', reason: text('你已经不在通往二层的前台楼梯旁。', 'You are no longer beside the lobby stairs.') },
        { type: 'capability', id: 'travel-upstairs', reason: text('这里没有通向二层的路线。', 'There is no route upstairs from here.') },
      ],
      effects: [
        { type: 'move', locationId: 'second-floor-corridor' },
        { type: 'thread-start', thread: { id: 'red-lights-closing', kind: 'intrusion', locationId: 'second-floor-corridor', participantIds: [], phase: 'active' } },
      ],
      successText: text('你抵达二层时，身后的红灯依次熄灭，只剩七号房上方仍亮着。', 'When you reach the second floor, the red lights go out behind you in order; only the lamp above Room Seven remains lit.'),
    },
    {
      id: 'rest-lobby-chair', label: text('坐在前台高背椅上休息十分钟', 'Rest ten minutes in the lobby chair'),
      intent: 'rest-lobby-chair', matches: ['在前台休息', '坐椅子休息', 'rest in the lobby chair'], rank: 40,
      requirements: [
        { type: 'location', id: 'hotel-lobby', reason: text('前台高背椅不在这里。', 'The lobby chair is not here.') },
        { type: 'capability', id: 'rest', reason: text('这里现在不能安全休息。', 'This is not a safe place to rest.') },
        { type: 'stat', id: 'composure', max: 89, reason: text('你现在不需要继续休息。', 'You do not need more rest right now.') },
      ],
      effects: [{ type: 'stat', id: 'composure', delta: 10 }, { type: 'clock', scenes: 1 }],
      repeat: { scope: 'cooldown', scenes: 3, reason: text('刚休息过，需要先继续行动。', 'You have just rested; act before resting again.') },
      successText: text('十分钟后，你的呼吸恢复平稳，雨声也重新变得有层次。', 'Ten minutes later, your breathing steadies and the rain separates into distinct sounds again.'),
    },
    {
      id: 'inspect-key-rack', label: text('检查前台缺少九号牌的钥匙架', 'Inspect the key rack missing a Room Nine tag'),
      intent: 'inspect-key-rack', matches: ['检查钥匙架', '查看九号钥匙', 'inspect the key rack'], rank: 50,
      requirements: [{ type: 'location', id: 'hotel-lobby', reason: text('钥匙架留在前台。', 'The key rack remains at the desk.') }],
      effects: [{ type: 'stat', id: 'clues', delta: 1 }, { type: 'fact', id: 'key-rack-inspected', value: true }],
      repeat: { scope: 'once', reason: text('钥匙架已经检查完毕。', 'The key rack has already been inspected.') },
      successText: text('八号和楼梯牌之间有两枚旧钉孔，间距正好容下一块房牌。', 'Two old nail holes sit between Room Eight and the stairs, exactly wide enough for another tag.'),
    },
    {
      id: 'check-rain-ledger', label: text('比对雨夜值班记录的时间', 'Compare the times in the rainy-night duty log'),
      intent: 'check-rain-ledger', matches: ['看值班记录', '比对时间', 'compare the duty log'], rank: 60,
      requirements: [{ type: 'location', id: 'hotel-lobby', reason: text('值班记录留在前台。', 'The duty log remains at the desk.') }],
      effects: [{ type: 'fact', id: 'duty-log-checked', value: true }],
      repeat: { scope: 'once', reason: text('值班记录已经比对过。', 'The duty log has already been compared.') },
      successText: text('每次红灯熄灭前，值班记录都会凭空多出同一分钟。', 'Before every outage, the duty log gains the same impossible minute.'),
    },
    {
      id: 'name-red-light-pattern', label: text('说出红灯正朝七号房逼近', 'State that the red lights are closing on Room Seven'),
      intent: 'name-red-light-pattern', matches: ['说明红灯顺序', '说出红灯逼近七号房', 'state the red-light pattern'], rank: 10,
      threadPolicy: 'preserve',
      requirements: [
        { type: 'location', id: 'second-floor-corridor', reason: text('红灯走廊不在这里。', 'The red corridor is not here.') },
        { type: 'thread', id: 'red-lights-closing', phase: 'active', reason: text('红灯逼近的异常已经结束。', 'The advancing red-light threat is no longer active.') },
      ],
      effects: [{ type: 'stat', id: 'clues', delta: 1 }, { type: 'fact', id: 'pattern-named', value: true }],
      repeat: { scope: 'once', reason: text('红灯顺序已经记录。', 'The red-light order is already recorded.') },
      successText: text('你把顺序说出口后，熄灭停顿了一拍；七号房门后传来一次回应般的敲击。', 'When you say the order aloud, the darkness pauses for one beat and Room Seven answers with a knock.'),
    },
    {
      id: 'light-red-match', label: text('点燃一根红色火柴照亮七号房门', 'Light one red match at the door to Room Seven'),
      intent: 'light-red-match', matches: ['点燃红色火柴', '用火柴照七号房', 'light a red match'], rank: 20,
      threadPolicy: 'resolve',
      requirements: [
        { type: 'location', id: 'second-floor-corridor', reason: text('七号房门不在这里。', 'The door to Room Seven is not here.') },
        { type: 'item', id: 'red-match', min: 1, reason: text('你已经没有红色火柴。', 'You have no red matches left.') },
        { type: 'thread', id: 'red-lights-closing', phase: 'active', reason: text('红灯逼近的异常已经结束。', 'The advancing red-light threat is no longer active.') },
      ],
      effects: [{ type: 'item', id: 'red-match', delta: -1 }, { type: 'thread-resolve' }, { type: 'stat', id: 'clues', delta: 1 }],
      successText: text('火焰把最后一盏红灯推亮，逼近的黑暗停在门槛外。', 'The flame forces the final red lamp bright, stopping the advancing dark at the threshold.'),
    },
    {
      id: 'enter-room-seven', label: text('趁七号房仍亮着推门进去', 'Enter Room Seven while its lamp is still lit'),
      intent: 'enter-room-seven', matches: ['进入七号房', '推开七号房门', 'enter room seven'], rank: 30,
      threadPolicy: 'any',
      requirements: [
        { type: 'location', id: 'second-floor-corridor', reason: text('七号房门不在这里。', 'The door to Room Seven is not here.') },
        { type: 'stat', id: 'clues', min: 1, reason: text('你还不知道哪一扇门能避开熄灭的红灯。', 'You do not yet know which door can escape the extinguishing lights.') },
      ],
      effects: [{ type: 'thread-resolve' }, { type: 'move', locationId: 'room-seven' }],
      successText: text('你在最后一盏灯熄灭前进入七号房，门在身后自行合拢。', 'You enter Room Seven before the final lamp dies, and the door closes by itself behind you.'),
    },
    {
      id: 'retreat-to-lobby', label: text('沿仍亮着的楼梯灯撤回前台', 'Retreat to the lobby along the lit stair lamps'),
      intent: 'retreat-to-lobby', matches: ['撤回前台', '退回大厅', 'retreat to the lobby'], rank: 40,
      threadPolicy: 'resolve',
      requirements: [{ type: 'location', id: 'second-floor-corridor', reason: text('楼梯不在这里。', 'The stairs are not here.') }],
      effects: [{ type: 'thread-resolve' }, { type: 'move', locationId: 'hotel-lobby' }, { type: 'stat', id: 'composure', delta: -4 }],
      successText: text('你沿最后几盏亮灯撤回前台，代价是把七号房的敲击留在楼上。', 'You retreat along the last lit lamps, leaving the knocking at Room Seven upstairs.'),
    },
    {
      id: 'inspect-left-door', label: text('检查左侧门框', 'Inspect the left doorframe'),
      intent: 'inspect-left-door', matches: ['检查门', 'inspect the door'], rank: 10,
      requirements: [{ type: 'location', id: 'room-seven', reason: text('左侧门框不在这里。', 'The left doorframe is not here.') }],
      effects: [{ type: 'fact', id: 'left-frame-checked', value: true }],
      repeat: { scope: 'once', reason: text('左侧门框已经检查过。', 'The left doorframe is already checked.') },
      successText: text('左侧门框里嵌着一根烧黑的火柴。', 'A charred match is embedded in the left doorframe.'),
    },
    {
      id: 'inspect-right-door', label: text('检查右侧壁柜门', 'Inspect the right cabinet door'),
      intent: 'inspect-right-door', matches: ['检查门', 'inspect the door'], rank: 20,
      requirements: [{ type: 'location', id: 'room-seven', reason: text('右侧壁柜门不在这里。', 'The right cabinet door is not here.') }],
      effects: [{ type: 'fact', id: 'right-door-checked', value: true }],
      repeat: { scope: 'once', reason: text('右侧壁柜门已经检查过。', 'The right cabinet door is already checked.') },
      successText: text('壁柜门内侧写着一串没有日期的退房时间。', 'The cabinet door lists checkout times with no dates.'),
    },
  ]
}

export function createPersonalLab(locale: Locale = 'zh'): { ruleset: AuthorityRuleset; state: AuthorityState } {
  const entities = {
    'hotel-lobby': entity('hotel-lobby', 'location', '旅馆前台', 'Hotel Lobby', ['前台', '大厅', 'lobby']),
    'second-floor-corridor': entity('second-floor-corridor', 'location', '二层红灯走廊', 'Second-floor Red Corridor', ['二层', '红灯走廊', 'corridor']),
    'room-seven': entity('room-seven', 'location', '七号房', 'Room Seven', ['七号房', 'room seven']),
    mara: entity('mara', 'character', '玛拉', 'Mara', ['玛拉', 'mara'], 'hotel-lobby'),
  }
  const ruleset: AuthorityRuleset = {
    id: 'action-authority-personal-lab', version: 1, locale, locations,
    locationCapabilities: {
      'hotel-lobby': ['inspect-records', 'travel-upstairs', 'rest'],
      'second-floor-corridor': ['inspect-doors', 'retreat'],
      'room-seven': ['inspect-doors'],
    },
    statBounds: { composure: { min: 0, max: 100 }, clues: { min: 0, max: 8 } },
    entities, actions: personalActions(),
    events: [
      {
        id: 'corridor-whisper', minimumScene: 1, probabilityBasisPoints: 10_000, once: true,
        requirements: [
          { type: 'location', id: 'second-floor-corridor', reason: text('低语只会出现在二层走廊。', 'The whisper belongs to the second-floor corridor.') },
          { type: 'thread', id: 'red-lights-closing', phase: 'active', reason: text('红灯异常尚未发生。', 'The red-light anomaly is not active.') },
        ],
        effects: [{ type: 'fact', id: 'corridor-whisper-heard', value: true }],
        text: text('墙内响起与红灯同节奏的低语。', 'A whisper inside the wall keeps time with the red lights.'),
      },
      {
        id: 'rain-knock', minimumScene: 2, probabilityBasisPoints: 5_000, once: true,
        requirements: [{ type: 'location', id: 'hotel-lobby', reason: text('雨声只在前台窗边清楚可闻。', 'The rain is only clear beside the lobby windows.') }],
        effects: [{ type: 'fact', id: 'rain-knock-heard', value: true }],
        text: text('雨点中混进三下从玻璃内侧传来的敲击。', 'Three knocks join the rain from the inside of the glass.'),
      },
    ],
  }
  const state: AuthorityState = {
    schemaVersion: 1, rulesetId: ruleset.id, rulesetVersion: ruleset.version,
    scene: 0, day: 1, currentLocationId: 'hotel-lobby',
    stats: { composure: 68, clues: 0 }, facts: {}, inventory: { 'red-match': 3 },
    entities: { mara: { locationId: 'hotel-lobby', status: 'available' } },
    actionLedger: [], eventLedger: [], eventSeed: 'red-hotel-lab-seed',
  }
  return { ruleset, state }
}

export function createRoomSevenAmbiguityLab(locale: Locale = 'zh'): { ruleset: AuthorityRuleset; state: AuthorityState } {
  const lab = createPersonalLab(locale)
  return { ...lab, state: { ...lab.state, currentLocationId: 'room-seven' } }
}

export function createSharedAidLab(locale: Locale = 'zh', available = 1): { ruleset: AuthorityRuleset; head: SharedWorldHead } {
  const action: ActionDefinition = {
    id: 'claim-last-umbrella', label: text('领取最后一把公用雨伞', 'Claim the last community umbrella'),
    intent: 'claim-last-umbrella', matches: ['领取雨伞', '拿最后一把伞', 'claim the last umbrella'],
    requirements: [
      { type: 'location', id: 'community-desk', reason: text('公用物资柜不在这里。', 'The community supply desk is not here.') },
      { type: 'capability', id: 'claim-aid', reason: text('这里不能领取公用物资。', 'Community aid cannot be claimed here.') },
      { type: 'stat', id: 'umbrella-units', min: 1, reason: text('最后一把公用雨伞已经被别人领走。', 'Another player has already claimed the last community umbrella.') },
    ],
    effects: [{ type: 'stat', id: 'umbrella-units', delta: -1 }, { type: 'grant-receipt', itemId: 'community-umbrella', count: 1 }],
    repeat: { scope: 'actor-once', reason: text('你已经领取过这批公用物资。', 'You have already claimed aid from this batch.') },
    threadPolicy: 'any',
    successText: text('物资柜提交了一把雨伞的领取回执。', 'The supply desk commits a receipt for one umbrella.'),
    publicEvent: { type: 'aid_claimed', payload: { itemId: 'community-umbrella', count: 1 } },
  }
  const ruleset: AuthorityRuleset = {
    id: 'action-authority-shared-aid-lab', version: 1, locale,
    locations: ['community-desk'], locationCapabilities: { 'community-desk': ['claim-aid'] },
    statBounds: { 'umbrella-units': { min: 0, max: available } },
    entities: { 'community-desk': entity('community-desk', 'location', '公用物资柜', 'Community Supply Desk', ['物资柜', 'supply desk']) },
    actions: [action],
  }
  const snapshot: AuthorityState = {
    schemaVersion: 1, rulesetId: ruleset.id, rulesetVersion: ruleset.version,
    scene: 0, day: 1, currentLocationId: 'community-desk', stats: { 'umbrella-units': available },
    facts: {}, inventory: {}, entities: {}, actionLedger: [], eventLedger: [], eventSeed: 'shared-aid-lab-seed',
  }
  const head: SharedWorldHead = {
    worldKey: 'main', rulesetId: ruleset.id, rulesetVersion: ruleset.version,
    version: 0, cursor: 0, snapshot, events: [], receipts: [], actionCache: {},
  }
  return { ruleset, head }
}

export function createSharedRelayLab(locale: Locale = 'zh'): { ruleset: AuthorityRuleset; head: SharedWorldHead } {
  const relayStation = entity(
    'relay-station',
    'location',
    '风暴观测站物资间',
    'Storm Watch Supply Room',
    ['观测站', '物资间', 'weather station', 'supply room'],
  )
  const weatherRadio: AuthorityEntity = {
    id: 'weather-radio',
    kind: 'object',
    label: text('便携气象电台', 'Portable Weather Radio'),
    aliases: ['气象电台', '电台', 'weather radio'],
    locationId: 'relay-station',
    status: 'held:user-a',
  }
  const actions: ActionDefinition[] = [
    {
      id: 'claim-signal-battery',
      label: text('领取一枚备用信号电池', 'Claim one spare signal battery'),
      intent: 'claim-signal-battery',
      matches: ['领取信号电池', '拿备用电池', 'claim a signal battery'],
      rank: 10,
      requirements: [
        { type: 'location', id: 'relay-station', reason: text('备用电池存放在观测站物资间。', 'Spare batteries are stored in the watch-station supply room.') },
        { type: 'stat', id: 'signal-battery-units', min: 1, reason: text('最后一枚备用信号电池已经被领取。', 'The last spare signal battery has already been claimed.') },
      ],
      effects: [
        { type: 'stat', id: 'signal-battery-units', delta: -1 },
        { type: 'grant-receipt', itemId: 'signal-battery', count: 1 },
      ],
      repeat: { scope: 'actor-once', reason: text('你已经领取过这批备用电池。', 'You have already claimed from this battery batch.') },
      threadPolicy: 'any',
      successText: text('物资柜登记了这枚备用信号电池的领取记录。', 'The supply cabinet records the signal-battery claim.'),
      publicEvent: { type: 'signal_battery_claimed', payload: { itemId: 'signal-battery', count: 1 } },
    },
    {
      id: 'handoff-weather-radio-to-user-b',
      label: text('把便携气象电台移交给值守员 B', 'Hand the portable weather radio to Watchkeeper B'),
      intent: 'handoff-weather-radio',
      matches: ['移交气象电台', '把电台交给值守员b', 'handoff the weather radio'],
      rank: 20,
      requirements: [
        { type: 'actor', id: 'user-a', reason: text('这台电台目前不由你保管。', 'You are not the current custodian of this radio.') },
        { type: 'location', id: 'relay-station', reason: text('移交必须在观测站物资间登记。', 'The handoff must be logged in the supply room.') },
        { type: 'entity', id: 'weather-radio', status: 'held:user-a', reason: text('电台的公开保管人已经改变。', 'The radio has a different public custodian now.') },
      ],
      effects: [
        { type: 'entity', id: 'weather-radio', status: 'held:user-b' },
        { type: 'grant-receipt', itemId: 'weather-radio', count: -1, actorUserId: 'user-a' },
        { type: 'grant-receipt', itemId: 'weather-radio', count: 1, actorUserId: 'user-b' },
      ],
      repeat: { scope: 'once', reason: text('这次电台移交已经登记。', 'This radio handoff is already recorded.') },
      threadPolicy: 'any',
      successText: text('公开保管记录改为值守员 B，并生成两端同步回执。', 'Public custody moves to Watchkeeper B and both private mirrors receive sync receipts.'),
      publicEvent: {
        type: 'weather_radio_handoff',
        payload: { itemId: 'weather-radio', fromActorId: 'user-a', toActorId: 'user-b' },
      },
    },
    {
      id: 'report-west-bridge-flooding',
      label: text('登记西侧步桥积水警报', 'Log a flooding warning for the west footbridge'),
      intent: 'report-west-bridge-flooding',
      matches: ['登记步桥积水', '报告西侧步桥', 'log west bridge flooding'],
      rank: 30,
      requirements: [
        { type: 'actor', id: 'user-b', reason: text('只有现场值守员 B 能确认这条警报。', 'Only Watchkeeper B at the scene can verify this warning.') },
        { type: 'location', id: 'relay-station', reason: text('警报需要写入观测站记录。', 'The warning must be entered at the watch station.') },
      ],
      effects: [
        { type: 'fact-add', id: 'public-reputation:user-b', delta: 1 },
        { type: 'grant-receipt', itemId: 'verified-field-note', count: 1, actorUserId: 'user-b' },
      ],
      repeat: { scope: 'actor-once', reason: text('这条积水警报已经登记。', 'This flooding warning is already logged.') },
      threadPolicy: 'any',
      successText: text('西侧步桥的积水警报进入公共记录，来源标记为值守员 B。', 'The west-footbridge flood warning enters the public log with Watchkeeper B as its source.'),
      publicEvent: { type: 'bridge_flooding_reported', payload: { locationId: 'west-footbridge', severity: 2 } },
    },
  ]
  const ruleset: AuthorityRuleset = {
    id: 'action-authority-shared-relay-lab',
    version: 1,
    locale,
    locations: ['relay-station'],
    locationCapabilities: { 'relay-station': ['claim-aid', 'handoff', 'publish-warning'] },
    statBounds: { 'signal-battery-units': { min: 0, max: 1 } },
    entities: { 'relay-station': relayStation, 'weather-radio': weatherRadio },
    actions,
  }
  const snapshot: AuthorityState = {
    schemaVersion: 1,
    rulesetId: ruleset.id,
    rulesetVersion: ruleset.version,
    scene: 0,
    day: 1,
    currentLocationId: 'relay-station',
    stats: { 'signal-battery-units': 1 },
    facts: { 'public-reputation:user-b': 0 },
    inventory: {},
    entities: { 'weather-radio': { locationId: 'relay-station', status: 'held:user-a' } },
    actionLedger: [],
    eventLedger: [],
    eventSeed: 'shared-relay-lab-seed',
  }
  const head: SharedWorldHead = {
    worldKey: 'main',
    rulesetId: ruleset.id,
    rulesetVersion: ruleset.version,
    version: 0,
    cursor: 0,
    snapshot,
    events: [],
    receipts: [],
    actionCache: {},
  }
  return { ruleset, head }
}
