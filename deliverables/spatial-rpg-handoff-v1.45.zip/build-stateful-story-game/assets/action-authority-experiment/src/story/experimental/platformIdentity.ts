export interface PlatformIdentityClaims {
  issuer: string
  audience: string
  gameId: string
  subject: string
  sessionId: string
  issuedAt: number
  expiresAt: number
  tokenId: string
  scopes: string[]
}

export interface CryptographicallyVerifiedIdentity {
  signatureVerified: true
  keyId: string
  algorithm: string
  claims: PlatformIdentityClaims
}

export type IdentityValidationResult =
  | { ok: true; actorUserId: string; sessionId: string; claims: PlatformIdentityClaims }
  | { ok: false; code: 'UNVERIFIED' | 'ISSUER_MISMATCH' | 'AUDIENCE_MISMATCH' | 'GAME_MISMATCH' | 'EXPIRED' | 'NOT_YET_VALID' | 'TTL_TOO_LONG' | 'SCOPE_MISSING' | 'CLAIMS_INVALID' }

/**
 * Runs only after a platform-specific backend verifier has checked the proof's
 * signature. It binds a short-lived platform proof to one game and actor. Raw
 * query parameters, profile JSON, and browser supplied user ids must never be
 * converted into CryptographicallyVerifiedIdentity.
 */
export function validateVerifiedPlatformIdentity(
  proof: CryptographicallyVerifiedIdentity,
  expected: {
    issuer: string
    audience: string
    gameId: string
    requiredScope: string
    nowSeconds: number
    clockSkewSeconds?: number
    maxTtlSeconds?: number
  },
): IdentityValidationResult {
  if (proof.signatureVerified !== true || !proof.keyId || !proof.algorithm) return { ok: false, code: 'UNVERIFIED' }
  const claims = proof.claims
  if (!claims.subject || !claims.sessionId || !claims.tokenId || !Number.isFinite(claims.issuedAt) || !Number.isFinite(claims.expiresAt)) {
    return { ok: false, code: 'CLAIMS_INVALID' }
  }
  if (claims.issuer !== expected.issuer) return { ok: false, code: 'ISSUER_MISMATCH' }
  if (claims.audience !== expected.audience) return { ok: false, code: 'AUDIENCE_MISMATCH' }
  if (claims.gameId !== expected.gameId) return { ok: false, code: 'GAME_MISMATCH' }
  const skew = Math.max(0, expected.clockSkewSeconds ?? 30)
  if (claims.issuedAt > expected.nowSeconds + skew) return { ok: false, code: 'NOT_YET_VALID' }
  if (claims.expiresAt <= expected.nowSeconds - skew) return { ok: false, code: 'EXPIRED' }
  if (claims.expiresAt <= claims.issuedAt) return { ok: false, code: 'CLAIMS_INVALID' }
  if (claims.expiresAt - claims.issuedAt > (expected.maxTtlSeconds ?? 600)) return { ok: false, code: 'TTL_TOO_LONG' }
  if (!claims.scopes.includes(expected.requiredScope)) return { ok: false, code: 'SCOPE_MISSING' }
  return { ok: true, actorUserId: claims.subject, sessionId: claims.sessionId, claims }
}
