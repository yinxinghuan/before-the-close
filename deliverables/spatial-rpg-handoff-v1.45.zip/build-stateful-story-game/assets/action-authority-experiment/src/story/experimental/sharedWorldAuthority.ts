import {
  type ActionDefinition,
  type AuthorityRuleset,
  type AuthorityState,
  type FactValue,
  commitAction,
  rejectionReasons,
} from './actionAuthority'

export interface PublicWorldEvent {
  id: string
  seq: number
  worldVersion: number
  actionId: string
  actorUserId: string
  type: string
  payload: Record<string, FactValue>
  visibility: 'public'
}

export interface GrantReceipt {
  id: string
  actionId: string
  actorUserId: string
  itemId: string
  count: number
  status: 'pending' | 'acknowledged'
}

export interface SharedActionRequest {
  worldKey: string
  actionId: string
  actorUserId: string
  expectedVersion: number
  rulesetVersion: number
  actionDefinitionId: string
}

export type SharedErrorCode =
  | 'WORLD_MISMATCH'
  | 'RULESET_MISMATCH'
  | 'VERSION_CONFLICT'
  | 'INVALID_ACTION'

export interface SharedActionResponse {
  ok: boolean
  actionId: string
  version: number
  cursor: number
  replayed: boolean
  code?: SharedErrorCode
  reasons?: string[]
  event?: PublicWorldEvent
  receiptIds?: string[]
}

export interface SharedWorldHead {
  worldKey: string
  rulesetId: string
  rulesetVersion: number
  version: number
  cursor: number
  snapshot: AuthorityState
  events: PublicWorldEvent[]
  receipts: GrantReceipt[]
  actionCache: Record<string, SharedActionResponse>
}

export interface SharedCommitResult {
  head: SharedWorldHead
  response: SharedActionResponse
}

export interface PersonalSaveEnvelope {
  __alteruSaveEnvelope: 1
  namespaces: {
    story: Record<string, unknown>
    sharedInventory: {
      items: Record<string, number>
      receiptIds: string[]
    }
  }
}

function clone<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T
}

function failure(head: SharedWorldHead, request: SharedActionRequest, code: SharedErrorCode, reasons: string[] = []): SharedCommitResult {
  return {
    head,
    response: {
      ok: false,
      actionId: request.actionId,
      version: head.version,
      cursor: head.cursor,
      replayed: false,
      code,
      reasons,
    },
  }
}

function actionFor(request: SharedActionRequest, ruleset: AuthorityRuleset): ActionDefinition | undefined {
  return ruleset.actions.find((action) => action.id === request.actionDefinitionId)
}

function actionCacheKey(actorUserId: string, actionId: string): string {
  return `${encodeURIComponent(actorUserId)}:${encodeURIComponent(actionId)}`
}

export function applySharedAction(
  head: SharedWorldHead,
  ruleset: AuthorityRuleset,
  request: SharedActionRequest,
): SharedCommitResult {
  const cacheKey = actionCacheKey(request.actorUserId, request.actionId)
  const cached = head.actionCache[cacheKey]
  if (cached) return { head, response: { ...clone(cached), replayed: true } }
  if (request.worldKey !== head.worldKey) return failure(head, request, 'WORLD_MISMATCH')
  if (
    request.rulesetVersion !== head.rulesetVersion
    || request.rulesetVersion !== ruleset.version
    || head.rulesetId !== ruleset.id
  ) return failure(head, request, 'RULESET_MISMATCH')
  if (request.expectedVersion !== head.version) return failure(head, request, 'VERSION_CONFLICT')
  const action = actionFor(request, ruleset)
  if (!action) return failure(head, request, 'INVALID_ACTION', ['Unknown action definition'])
  const reasons = rejectionReasons(action, head.snapshot, ruleset, request.actorUserId)
  if (reasons.length) return failure(head, request, 'INVALID_ACTION', reasons)

  const committed = commitAction(head.snapshot, ruleset, action, request.actionId, request.actorUserId)
  if (committed.status !== 'committed') {
    return failure(head, request, 'INVALID_ACTION', committed.reasons)
  }
  const next = clone(head)
  next.version += 1
  next.cursor += 1
  next.snapshot = committed.state
  const event: PublicWorldEvent = {
    id: `${head.worldKey}:${next.cursor}`,
    seq: next.cursor,
    worldVersion: next.version,
    actionId: request.actionId,
    actorUserId: request.actorUserId,
    type: action.publicEvent?.type ?? action.id,
    payload: clone(action.publicEvent?.payload ?? { action: action.id }),
    visibility: 'public',
  }
  next.events.push(event)
  const receiptIds = committed.emissions.map((emission, index) => {
    const receiptActorUserId = emission.actorUserId ?? request.actorUserId
    const receipt: GrantReceipt = {
      id: `${encodeURIComponent(receiptActorUserId)}:${encodeURIComponent(request.actionId)}:grant:${index}`,
      actionId: request.actionId,
      actorUserId: receiptActorUserId,
      itemId: emission.itemId,
      count: emission.count,
      status: 'pending',
    }
    next.receipts.push(receipt)
    return receipt.id
  })
  const response: SharedActionResponse = {
    ok: true,
    actionId: request.actionId,
    version: next.version,
    cursor: next.cursor,
    replayed: false,
    event,
    receiptIds,
  }
  next.actionCache[cacheKey] = clone(response)
  return { head: next, response }
}

export function listPendingReceipts(head: SharedWorldHead, actorUserId: string): GrantReceipt[] {
  return head.receipts.filter((receipt) => receipt.actorUserId === actorUserId && receipt.status === 'pending').map(clone)
}

export function eventsAfterCursor(head: SharedWorldHead, cursor: number): PublicWorldEvent[] {
  return head.events.filter((event) => event.seq > cursor).map(clone)
}

export function mergeReceiptsIntoEnvelope(
  envelope: PersonalSaveEnvelope,
  receipts: GrantReceipt[],
): PersonalSaveEnvelope {
  const next = clone(envelope)
  const known = new Set(next.namespaces.sharedInventory.receiptIds)
  for (const receipt of receipts) {
    if (known.has(receipt.id)) continue
    const updatedCount = (next.namespaces.sharedInventory.items[receipt.itemId] ?? 0) + receipt.count
    if (updatedCount < 0) throw new Error(`Receipt would create negative private inventory: ${receipt.id}`)
    next.namespaces.sharedInventory.items[receipt.itemId] = updatedCount
    next.namespaces.sharedInventory.receiptIds.push(receipt.id)
    known.add(receipt.id)
  }
  return next
}

export function acknowledgeReceipt(
  head: SharedWorldHead,
  actorUserId: string,
  receiptId: string,
  persistedReceiptIds: string[],
): { head: SharedWorldHead; ok: boolean; reason?: string } {
  const receipt = head.receipts.find((candidate) => candidate.id === receiptId)
  if (!receipt || receipt.actorUserId !== actorUserId) return { head, ok: false, reason: 'RECEIPT_NOT_FOUND' }
  if (receipt.status === 'acknowledged') return { head, ok: true }
  if (!persistedReceiptIds.includes(receiptId)) return { head, ok: false, reason: 'PRIVATE_SAVE_NOT_VERIFIED' }
  const next = clone(head)
  const mutable = next.receipts.find((candidate) => candidate.id === receiptId)!
  mutable.status = 'acknowledged'
  return { head: next, ok: true }
}

export function initialEnvelope(
  story: Record<string, unknown> = {},
  sharedItems: Record<string, number> = {},
): PersonalSaveEnvelope {
  return {
    __alteruSaveEnvelope: 1,
    namespaces: {
      story: clone(story),
      sharedInventory: { items: clone(sharedItems), receiptIds: [] },
    },
  }
}

export function replaceStoryNamespace(
  envelope: PersonalSaveEnvelope,
  story: Record<string, unknown>,
): PersonalSaveEnvelope {
  const next = clone(envelope)
  next.namespaces.story = clone(story)
  return next
}
