import type { AuthorityRuleset, ExecutableAction } from './actionAuthority'
import { enumerateExecutableActions } from './actionAuthority'
import type {
  GrantReceipt,
  PublicWorldEvent,
  SharedActionResponse,
  SharedWorldHead,
} from './sharedWorldAuthority'
import {
  acknowledgeReceipt,
  applySharedAction,
  eventsAfterCursor,
  listPendingReceipts,
} from './sharedWorldAuthority'

export interface SharedWorldView {
  worldKey: string
  rulesetId: string
  rulesetVersion: number
  version: number
  cursor: number
  availableActions: ExecutableAction[]
  events: PublicWorldEvent[]
}

export interface BoundSharedAuthorityGateway {
  read(cursor?: number): Promise<SharedWorldView>
  submit(request: {
    actionId: string
    expectedVersion: number
    actionDefinitionId: string
  }): Promise<SharedActionResponse>
  pendingReceipts(): Promise<GrantReceipt[]>
  acknowledge(receiptId: string, persistedReceiptIds: string[]): Promise<{ ok: boolean; reason?: string }>
}

export interface LocalSharedWorldStore {
  head: SharedWorldHead
}

export function createLocalSharedWorldStore(head: SharedWorldHead): LocalSharedWorldStore {
  return { head }
}

export function createLocalBoundAuthorityGateway(options: {
  store: LocalSharedWorldStore
  ruleset: AuthorityRuleset
  actorUserId: string
}): BoundSharedAuthorityGateway {
  const { store, ruleset, actorUserId } = options
  return {
    async read(cursor = 0) {
      return {
        worldKey: store.head.worldKey,
        rulesetId: store.head.rulesetId,
        rulesetVersion: store.head.rulesetVersion,
        version: store.head.version,
        cursor: store.head.cursor,
        availableActions: enumerateExecutableActions(store.head.snapshot, ruleset, actorUserId),
        events: eventsAfterCursor(store.head, cursor),
      }
    },
    async submit(request) {
      const result = applySharedAction(store.head, ruleset, {
        worldKey: store.head.worldKey,
        rulesetVersion: ruleset.version,
        actorUserId,
        ...request,
      })
      store.head = result.head
      return result.response
    },
    async pendingReceipts() {
      return listPendingReceipts(store.head, actorUserId)
    },
    async acknowledge(receiptId, persistedReceiptIds) {
      const result = acknowledgeReceipt(store.head, actorUserId, receiptId, persistedReceiptIds)
      store.head = result.head
      return { ok: result.ok, reason: result.reason }
    },
  }
}

export type ConflictRetryResult =
  | { status: 'committed'; attempts: number; response: SharedActionResponse; view: SharedWorldView }
  | { status: 'stale'; attempts: number; response?: SharedActionResponse; view: SharedWorldView }
  | { status: 'rejected'; attempts: number; response: SharedActionResponse; view: SharedWorldView }
  | { status: 'exhausted'; attempts: number; response: SharedActionResponse; view: SharedWorldView }

export type AuthorityRecoveryResult =
  | { status: 'committed'; attempts: number; response: SharedActionResponse; view: SharedWorldView }
  | { status: 'committed-reconciled'; attempts: number; event: PublicWorldEvent; view: SharedWorldView }
  | { status: 'stale'; attempts: number; response?: SharedActionResponse; view: SharedWorldView }
  | { status: 'rejected'; attempts: number; response: SharedActionResponse; view: SharedWorldView }
  | { status: 'exhausted'; attempts: number; response?: SharedActionResponse; view: SharedWorldView }
  | { status: 'unknown'; attempts: number; error: unknown; view: SharedWorldView }

export async function submitWithConflictRefresh(options: {
  gateway: BoundSharedAuthorityGateway
  initialView: SharedWorldView
  actionId: string
  actionDefinitionId: string
  maxAttempts?: number
}): Promise<ConflictRetryResult> {
  const maxAttempts = Math.max(1, Math.min(3, options.maxAttempts ?? 3))
  let view = options.initialView
  let attempts = 0
  let lastResponse: SharedActionResponse | undefined
  while (attempts < maxAttempts) {
    if (!view.availableActions.some((action) => action.id === options.actionDefinitionId)) {
      return { status: 'stale', attempts, response: lastResponse, view }
    }
    attempts += 1
    const response = await options.gateway.submit({
      actionId: options.actionId,
      expectedVersion: view.version,
      actionDefinitionId: options.actionDefinitionId,
    })
    lastResponse = response
    if (response.ok) {
      return { status: 'committed', attempts, response, view: await options.gateway.read(view.cursor) }
    }
    if (response.code !== 'VERSION_CONFLICT') {
      return { status: 'rejected', attempts, response, view: await options.gateway.read(view.cursor) }
    }
    view = await options.gateway.read(view.cursor)
  }
  return { status: 'exhausted', attempts, response: lastResponse!, view }
}

/**
 * Production-shaped submission path. A transport error is never translated into
 * a story failure: the client first reconciles by action id, then retries the
 * exact same id. The authority's actor-scoped idempotency cache makes that retry
 * safe even when the first request committed before its response was lost.
 */
export async function submitWithAuthorityRecovery(options: {
  gateway: BoundSharedAuthorityGateway
  initialView: SharedWorldView
  actionId: string
  actionDefinitionId: string
  maxAttempts?: number
}): Promise<AuthorityRecoveryResult> {
  const maxAttempts = Math.max(1, Math.min(3, options.maxAttempts ?? 3))
  let view = options.initialView
  let attempts = 0
  let lastResponse: SharedActionResponse | undefined
  let lastError: unknown

  while (attempts < maxAttempts) {
    const alreadyCommitted = view.events.find((event) => event.actionId === options.actionId)
    if (alreadyCommitted) return { status: 'committed-reconciled', attempts, event: alreadyCommitted, view }
    if (!view.availableActions.some((action) => action.id === options.actionDefinitionId)) {
      return { status: 'stale', attempts, response: lastResponse, view }
    }

    attempts += 1
    try {
      const response = await options.gateway.submit({
        actionId: options.actionId,
        expectedVersion: view.version,
        actionDefinitionId: options.actionDefinitionId,
      })
      lastResponse = response
      if (response.ok) {
        return { status: 'committed', attempts, response, view: await options.gateway.read(view.cursor) }
      }
      if (response.code !== 'VERSION_CONFLICT') {
        return { status: 'rejected', attempts, response, view: await options.gateway.read(view.cursor) }
      }
      view = await options.gateway.read(view.cursor)
    } catch (error) {
      lastError = error
      try {
        view = await options.gateway.read(view.cursor)
      } catch {
        if (attempts >= maxAttempts) return { status: 'unknown', attempts, error, view }
        continue
      }
      const committedEvent = view.events.find((event) => event.actionId === options.actionId)
      if (committedEvent) {
        return { status: 'committed-reconciled', attempts, event: committedEvent, view }
      }
    }
  }

  if (lastResponse) return { status: 'exhausted', attempts, response: lastResponse, view }
  return { status: 'unknown', attempts, error: lastError, view }
}
