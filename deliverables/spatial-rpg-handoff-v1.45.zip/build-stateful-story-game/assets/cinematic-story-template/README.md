> 第三方运行时：React、React DOM 与 Scheduler 18.3.1/0.23.2，Meta 及贡献者，MIT License；完整声明见 `public/THIRD_PARTY_NOTICES.txt`。

# Cinematic Story Template

AlterU 的第二套角色扮演模板：每个回合都有一张当前场景图，正文压缩为少量叙述和对话，图片始终留在固定舞台中；章节、传奇物品、重大同行者变化或高强度危险结算可进一步异步生成短视频。

它与 `stateful-story-template` 并行存在，不替代旧模板：

- 旧模板适合对话流、长文本回顾和慢节奏连续叙事。
- 本模板适合画面密度高、节奏更快的探索、对话与战斗 RPG。
- 两者复用权威存档、人物/同行者连续性、物品交易、数值边界、危险导演和自由行动协议。

## 当前交互

- 当前场景固定显示，不会随剧情增长离开视野。
- 每回合恰好排队一张场景图；AI 漏写或格式错误时，本地影像导演补建。
- 生成时保留上一张场景并显示非阻塞显影状态，玩家可以继续行动。
- 当前回合只显示理解下一步所需的短叙述、最多两句对话和关键结算。
- 所有旧场景进入“分镜历史”，点击可预览，但不会回滚存档。
- 普通选项点击一次立即提交；自由行动保留独立输入入口。
- 里程碑视频使用前一张已完成场景图和当前里程碑图作为首尾帧；失败时保留静态图。

## 本地运行

```bash
npm install
npm run dev -- --host 127.0.0.1 --port 4177
```

推荐先用确定性演示检查界面：

- `http://127.0.0.1:4177/?cartridge=the-wild-road&story_mode=demo`
- `http://127.0.0.1:4177/?cartridge=the-wild-road&story_mode=demo&lang=en`
- `http://127.0.0.1:4177/?cartridge=the-wild-road&story_mode=demo&avatar_url=<public-https-url>&user_name=Alex`

普通入口使用 Aigram `game-chat`。场景图默认调用 AlterU Media Service v1，并显式提交 `fast-small` 与目标宽高；`?media_backend=legacy` 仅用于回滚到旧 `gen-image`。玩家头像保持原始公开 HTTPS 图片，只作为 `edit` 模式的身份参考；输出比例由 `size` 决定，不再把头像裁成场景画幅或重新上传。

## 验证

```bash
npm run test:cinematic
npm run build
```

- 需求与玩法：`doc/requirements.md`
- 视觉与响应式：`doc/visual.md`
- 技术和媒体接口：`doc/technical.md`
- 截图证据：`_qa/ui/`

## 制作新游戏

1. 从母版导出一个独立项目目录，不要覆盖母版或把多个游戏写进同一源码目录。
2. 为游戏生成新的 `uuid.uuid4()` 和独立存档命名空间；交接后保持稳定。
3. 在 `src/story/cartridges/` 新增中英文 Cartridge，定义世界规则、3 个主数值、人物、行囊、危险导演、美术方向和演示回合。
4. 保持“每回合一图、当前舞台固定、旧场景入分镜、媒体失败不阻塞”四条核心合同。
5. 只在真正的章节/关系/宝物/高危里程碑启用视频，不把视频变成每回合必需资源。
