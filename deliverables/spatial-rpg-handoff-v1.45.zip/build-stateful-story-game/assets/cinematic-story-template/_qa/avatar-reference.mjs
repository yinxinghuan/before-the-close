import { chromium } from 'playwright'

const testCase = process.argv[2] || 'direct-civic'
const baseUrl = process.env.STORY_QA_URL || 'http://127.0.0.1:4180/'
const avatarUrl = 'https://qa.invalid/generated-player-avatar.png'
const transparentGif = 'R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw=='
const civic = testCase !== 'direct-living'

function installProfileBridge() {
  return ({ avatarUrl, kind }) => {
    let profileCalls = 0
    if (kind === 'transient' || kind === 'slow') window.Aigram = { isInAigram: true, telegramId: `${kind}-template-player` }
    window.addEventListener('message', (event) => {
      if (typeof event.data !== 'string' || !event.data.startsWith('callAPI-')) return
      try {
        const request = JSON.parse(decodeURIComponent(escape(atob(event.data.slice(8)))))
        if (!String(request.url).includes('/note/telegram/user/get/info/by/telegram_id')) return
        profileCalls += 1
        const callback = window[`__aigram_cb_${String(request.request_id).replace(/-/g, '_')}`]
        if (kind === 'transient' && profileCalls === 1) {
          callback?.(JSON.stringify({ request_id: request.request_id, success: false, error: 'temporary profile bridge failure' }))
          return
        }
        if (kind === 'slow' && profileCalls === 1) return
        callback?.(JSON.stringify({
          request_id: request.request_id,
          success: true,
          data: { retcode: 0, msg: 'ok', data: { name: 'Covered Ghost Player', head_url: avatarUrl } },
        }))
      } catch { /* bridge timeout exposes regressions */ }
    })
  }
}

const browser = await chromium.launch({ headless: true })
const context = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: 'zh-CN' })
if (testCase === 'late') {
  await context.addInitScript(({ avatarUrl }) => {
    window.addEventListener('message', (event) => {
      if (typeof event.data !== 'string' || !event.data.startsWith('callAPI-')) return
      try {
        const request = JSON.parse(decodeURIComponent(escape(atob(event.data.slice(8)))))
        if (!String(request.url).includes('/note/telegram/user/get/info/by/telegram_id')) return
        window[`__aigram_cb_${String(request.request_id).replace(/-/g, '_')}`]?.(JSON.stringify({
          request_id: request.request_id,
          success: true,
          data: { retcode: 0, msg: 'ok', data: { name: 'Late Template Player', head_url: avatarUrl } },
        }))
      } catch { /* bridge timeout exposes regressions */ }
    })
    window.setTimeout(() => {
      window.Aigram = { isInAigram: true, telegramId: 'late-template-player' }
      window.postMessage('qa-shell-identity-ready', '*')
    }, 4_200)
  }, { avatarUrl })
}
if (testCase === 'platform-query' || testCase === 'transient' || testCase === 'slow') {
  await context.addInitScript(installProfileBridge(), { avatarUrl, kind: testCase })
}

const page = await context.newPage()
const imageRequests = []
let uploadRequests = 0
await page.route('https://images.aiwaves.tech/alteru/guest-shell.js', (route) => route.fulfill({ contentType: 'application/javascript', body: '' }))
await page.route(avatarUrl, (route) => route.fulfill({ contentType: 'image/gif', body: Buffer.from(transparentGif, 'base64') }))
await page.route('https://chat.aiwaves.tech/aigram/api/upload', (route) => { uploadRequests += 1; return route.fulfill({ status: 500, body: '{}' }) })
await page.route('https://game.aiwaves.tech/alteru-media/api/v1/images/generations', (route) => {
  const payload = route.request().postDataJSON()
  imageRequests.push({ ...payload, ref_url: payload.reference_urls?.[0] })
  const now = Date.now()
  return route.fulfill({ contentType: 'application/json', body: JSON.stringify({
    request_id: payload.request_id,
    task_id: `qa-template-image-${imageRequests.length}`,
    type: 'image', status: 'succeeded',
    media: { type: 'image', url: `data:image/gif;base64,${transparentGif}`, width: payload.size.width, height: payload.size.height, format: 'png' },
    created_at: now, updated_at: now,
  }) })
})

const query = new URLSearchParams({ cartridge: 'before-we-get-home', story_mode: 'demo', lang: 'zh' })
if (civic) query.set('ui', 'civic')
if (testCase === 'platform-query') {
  query.set('api_origin', new URL(baseUrl).origin)
  query.set('telegram_id', '987654321')
} else if (testCase !== 'late' && testCase !== 'transient' && testCase !== 'slow') {
  query.set('avatar_url', avatarUrl)
  query.set('user_name', 'Covered Ghost Player')
}
await page.goto(`${baseUrl}?${query}`, { waitUntil: 'networkidle' })
await page.evaluate(() => window.alteruLocalStorage.clear())
await page.reload({ waitUntil: 'networkidle' })
await page.locator('.st-primary').click()
for (let index = 0; index < 60 && imageRequests.length < 1; index += 1) await page.waitForTimeout(200)

const opening = imageRequests[0]
if (!opening) throw new Error('opening image was not generated')
if (opening.ref_url !== avatarUrl) throw new Error(`opening did not use the original avatar URL: ${JSON.stringify(opening)}`)
if (opening.mode !== 'edit') throw new Error(`opening used ${opening.mode} instead of edit`)
if (!String(opening.prompt).includes('HARD FULL-VISUAL-IDENTITY CAST MAP')) throw new Error('opening omitted the full visual identity cast map')
for (const required of ['exact complete visible identity', 'sheet ghost', 'MUST NOT be invented', 'silhouette', 'costume', 'CURRENT SCENE']) {
  if (!String(opening.prompt).includes(required)) throw new Error(`opening omitted full-appearance rule: ${required}`)
}
if (String(opening.prompt).length > 4000) throw new Error(`opening prompt exceeded 4000: ${String(opening.prompt).length}`)
if (uploadRequests !== 0) throw new Error('the original avatar was unexpectedly cropped and re-uploaded')

if (testCase === 'saved-repair') {
  const firstChoice = page.locator('.st-quick-replies button').first()
  for (let pageIndex = 0; pageIndex < 12 && !(await firstChoice.isVisible()); pageIndex += 1) {
    const nextOpeningPage = page.locator('.ct-stage__caption-page')
    const nextResultPage = page.locator('.ct-result-story button')
    const revealChoices = page.locator('.ct-turn-next')
    if (await nextOpeningPage.isVisible()) await nextOpeningPage.click()
    else if (await nextResultPage.isVisible()) await nextResultPage.click()
    else if (await revealChoices.isVisible()) await revealChoices.click()
    else await page.waitForTimeout(100)
  }
  await firstChoice.waitFor({ state: 'visible' })
  await firstChoice.click()
  for (let index = 0; index < 80 && imageRequests.length < 2; index += 1) await page.waitForTimeout(200)
  if (imageRequests.length < 2) throw new Error('second story image was not generated before migration setup')
  await page.evaluate(() => {
    const key = 'cinematic-story-template-save'
    const archive = JSON.parse(window.alteruLocalStorage.getItem(key) || '{}')
    archive.worlds['before-we-get-home'].blocks = archive.worlds['before-we-get-home'].blocks.map((block) => {
      if (block.id !== 'image-0' && block.id !== 'image-1') return block
      const data = { ...block.data, status: 'ready', url: `https://qa.invalid/legacy-${block.id}.png`, playerVisible: 'true' }
      delete data.identityRefVersion
      return { ...block, data }
    })
    window.alteruLocalStorage.setItem(key, JSON.stringify(archive))
  })
  const beforeRepair = imageRequests.length
  await page.reload({ waitUntil: 'networkidle' })
  await page.waitForFunction(() => {
    const archive = JSON.parse(window.alteruLocalStorage.getItem('cinematic-story-template-save') || '{}')
    const early = archive.worlds?.['before-we-get-home']?.blocks?.filter((block) => block.id === 'image-0' || block.id === 'image-1') ?? []
    return early.length === 2 && early.every((block) => block.data?.status === 'ready' && block.data?.identityRefVersion === 2)
  }, null, { timeout: 15000 })
  const repaired = imageRequests.slice(beforeRepair)
  if (repaired.length !== 2 || repaired.some((request) => request.ref_url !== avatarUrl || request.mode !== 'edit')) {
    throw new Error(`saved opening images were not repaired with the player reference: ${JSON.stringify(repaired)}`)
  }
}

console.log(JSON.stringify({ ok: true, case: testCase, ui: civic ? 'civic' : 'living', mode: opening.mode, originalAvatar: opening.ref_url === avatarUrl, uploadRequests }))
await browser.close()
