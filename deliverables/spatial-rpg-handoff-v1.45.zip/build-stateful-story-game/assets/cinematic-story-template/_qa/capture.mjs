import { chromium } from 'playwright'
import fs from 'node:fs/promises'

const origin = process.env.QA_BASE_URL ?? 'http://127.0.0.1:4181/'
const cartridge = process.env.QA_CARTRIDGE ?? 'the-wild-road'
const base = `${origin}?cartridge=${encodeURIComponent(cartridge)}&story_mode=demo`
const out = process.env.QA_OUT_DIR ?? new URL('./ui/', import.meta.url).pathname
await fs.mkdir(out, { recursive: true })
console.log('capture output', out)

const browser = await chromium.launch({ headless: true })

function sceneUrl(index = 0) {
  const palettes = [['#17263b', '#d9a441'], ['#213c32', '#d8704f'], ['#3a263d', '#84a7c5']]
  const [sky, sun] = palettes[index % palettes.length]
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="450"><defs><linearGradient id="g" x2="0" y2="1"><stop stop-color="${sky}"/><stop offset="1" stop-color="#090b0f"/></linearGradient></defs><rect width="800" height="450" fill="url(#g)"/><circle cx="620" cy="90" r="54" fill="${sun}" opacity=".8"/><path d="M0 360 170 225 280 330 440 150 610 310 800 205V450H0Z" fill="#111820"/><path d="M90 410Q260 330 410 392T760 320" stroke="${sun}" stroke-width="8" fill="none" opacity=".75"/><circle cx="390" cy="285" r="24" fill="#ece5d6"/><path d="m368 450 16-143 15 0 30 143" fill="#29323c"/></svg>`
  return `data:image/svg+xml,${encodeURIComponent(svg)}`
}

async function pageAt(width, height, name, variant = 'living') {
  const page = await browser.newPage({ viewport: { width, height }, locale: 'zh-CN' })
  let imageIndex = 0
  await page.route('**/aigram/api/gen-image', (route) => route.fulfill({ contentType: 'application/json', body: JSON.stringify({ url: sceneUrl(imageIndex++) }) }))
  await page.route('**/note/telegram/user/get/info/**', (route) => route.fulfill({ contentType: 'application/json', body: JSON.stringify({ data: { name: '远行者', head_url: '' } }) }))
  await page.route('**:8443/video', (route) => route.fulfill({ status: 503, contentType: 'application/json', body: '{}' }))
  await page.route('**:8443/video_task', (route) => route.fulfill({ status: 503, contentType: 'application/json', body: '{}' }))
  await page.goto(`${base}${variant === 'civic' ? '&ui=civic' : ''}`, { waitUntil: 'networkidle' })
  await page.addStyleTag({ content: '#alteru-guest-banner,#alteru-guest-login{display:none!important}' })
  await page.waitForSelector('.st-primary', { state: 'visible' })
  await page.screenshot({ path: `${out}${name}-entry-platform-layout-${width}x${height}.png`, fullPage: true })
  await page.locator('.st-primary').click()
  await page.waitForSelector('.ct-stage')
  await page.waitForTimeout(300)
  if (process.env.QA_EXPECT_PAGER === '1') {
    const pager = page.locator('.ct-stage__caption-page')
    if (!(await pager.count())) throw new Error('long civic captions must render an explicit pager')
    const before = await page.locator('.ct-stage__caption p').textContent()
    await pager.click()
    const after = await page.locator('.ct-stage__caption p').textContent()
    if (!before || !after || before === after) throw new Error('caption pager must reveal the next text segment')
  }
  if (variant === 'civic' || process.env.QA_EXPECT_CHOICE_STATES === '1') {
    const choice = page.locator('.st-quick-replies button').first()
    await page.waitForFunction(() => {
      const node = document.querySelector('.st-quick-replies button')
      return node instanceof HTMLButtonElement && !node.disabled
    })
    const activeBorder = await choice.evaluate((node) => getComputedStyle(node).borderColor)
    const disabledBorder = await choice.evaluate(async (node) => {
      node.setAttribute('disabled', '')
      await new Promise((resolve) => requestAnimationFrame(() => requestAnimationFrame(resolve)))
      const color = getComputedStyle(node).borderColor
      node.removeAttribute('disabled')
      return color
    })
    console.log(`${name} choice borders`, { activeBorder, disabledBorder })
    if (activeBorder === disabledBorder) throw new Error('available and unavailable civic choices must have distinct borders')
  }
  await page.screenshot({ path: `${out}${name}-opening-platform-layout-${width}x${height}.png`, fullPage: true })
  const customAction = process.env.QA_CUSTOM_ACTION
  if (customAction) {
    await page.locator('.st-composer input').fill(customAction)
    await page.locator('.st-composer form button').click()
  } else {
    const choiceIndex = Number(process.env.QA_CHOICE_INDEX ?? 0)
    await page.locator('.st-quick-replies button').nth(choiceIndex).click()
  }
  await page.waitForFunction(() => document.querySelector('.ct-stage__media figcaption small')?.textContent?.includes('2'))
  await page.waitForTimeout(180)
  if (variant === 'civic') {
    await page.waitForSelector('.ct-civic-viewport.is-result')
    if (await page.locator('.ct-civic-viewport.is-result .st-quick-replies').count()) throw new Error('result phase must not render choices')
    if (process.env.QA_EXPECT_SPEAKER === '1' && !(await page.locator('.ct-stage__speaker').count())) throw new Error('dialogue phase must render a speaker identity marker')
    const resultBeatHeight = await page.locator('.ct-stage__beat').evaluate((node) => node.getBoundingClientRect().height)
    const maxBeatHeight = Number(process.env.QA_MAX_BEAT_HEIGHT ?? 0)
    if (maxBeatHeight && resultBeatHeight > maxBeatHeight) throw new Error(`result beat height ${resultBeatHeight} exceeds ${maxBeatHeight}`)
    console.log(`${name} result beat height`, resultBeatHeight)
    await page.screenshot({ path: `${out}${name}-result-platform-layout-${width}x${height}.png`, fullPage: true })
    await page.locator('.ct-civic-next').click()
    await page.waitForSelector('.ct-civic-viewport.is-decision')
    if ((await page.locator('.ct-civic-viewport.is-decision .st-quick-replies button').count()) < 2) throw new Error('decision phase must render the next choices')
    await page.screenshot({ path: `${out}${name}-decision-platform-layout-${width}x${height}.png`, fullPage: true })
  } else {
    await page.waitForSelector('.ct-stage.is-result')
    if (await page.locator('.ct-stage.is-result .st-quick-replies').count()) throw new Error('living result phase must not render choices')
    if (process.env.QA_EXPECT_SPEAKER === '1' && !(await page.locator('.ct-stage__speaker').count())) throw new Error('living dialogue phase must render a speaker identity marker')
    const resultBeatHeight = await page.locator('.ct-stage__beat').evaluate((node) => node.getBoundingClientRect().height)
    console.log(`${name} result beat height`, resultBeatHeight)
    await page.screenshot({ path: `${out}${name}-result-platform-layout-${width}x${height}.png`, fullPage: true })
    await page.locator('.ct-living-next').click()
    await page.waitForSelector('.ct-stage.is-decision')
    if ((await page.locator('.st-quick-replies button').count()) < 2) throw new Error('living decision phase must render the next choices')
    await page.screenshot({ path: `${out}${name}-decision-platform-layout-${width}x${height}.png`, fullPage: true })
  }
  if (width === 390) {
    await page.locator('.st-history-button').click()
    await page.waitForSelector('.ct-storyboard__list button')
    await page.screenshot({ path: `${out}${name}-history-platform-layout-${width}x${height}.png`, fullPage: true })
    await page.locator('.ct-storyboard>section>header button').click()
  }
  const metrics = await page.evaluate(() => ({
    viewport: [innerWidth, innerHeight],
    body: [document.body.scrollWidth, document.body.scrollHeight],
    stage: (() => { const node = document.querySelector('.ct-stage'); const r = node?.getBoundingClientRect(); return r ? [r.x, r.y, r.width, r.height] : null })(),
    media: (() => { const node = document.querySelector('.ct-stage__media'); const r = node?.getBoundingClientRect(); return r ? [r.x, r.y, r.width, r.height] : null })(),
    beat: (() => { const node = document.querySelector('.ct-stage__beat'); const r = node?.getBoundingClientRect(); return r ? [r.x, r.y, r.width, r.height] : null })(),
    choices: [...document.querySelectorAll('.st-quick-replies button')].map((node) => { const r = node.getBoundingClientRect(); return [r.width, r.height] }),
  }))
  console.log(name, JSON.stringify(metrics))
  await page.close()
}

async function externalGuest() {
  const page = await browser.newPage({ viewport: { width: 390, height: 844 }, locale: 'en-US' })
  await page.goto(base, { waitUntil: 'networkidle' })
  await page.waitForSelector('.st-primary', { state: 'visible' })
  await page.screenshot({ path: `${out}cinematic-entry-external-guest-390x844.png`, fullPage: true })
  const close = page.locator('#alteru-guest-login button').first()
  if (await close.count()) {
    await close.click()
    await page.waitForTimeout(180)
    await page.screenshot({ path: `${out}cinematic-entry-external-dismissed-390x844.png`, fullPage: true })
  }
  await page.close()
}

const only = process.env.QA_VARIANT
const onlyViewport = process.env.QA_VIEWPORT
if (!only || only === 'living') {
  if (!onlyViewport || onlyViewport === '320') await pageAt(320, 568, 'cinematic')
  if (!onlyViewport || onlyViewport === '390') await pageAt(390, 844, 'cinematic')
  if (!onlyViewport || onlyViewport === '1280') await pageAt(1280, 800, 'cinematic')
}
if (!only || only === 'civic') {
  if (!onlyViewport || onlyViewport === '320') await pageAt(320, 568, 'cinematic-civic', 'civic')
  if (!onlyViewport || onlyViewport === '390') await pageAt(390, 844, 'cinematic-civic', 'civic')
  if (!onlyViewport || onlyViewport === '1280') await pageAt(1280, 800, 'cinematic-civic', 'civic')
}
if (!only || only === 'external') await externalGuest()
await browser.close()
