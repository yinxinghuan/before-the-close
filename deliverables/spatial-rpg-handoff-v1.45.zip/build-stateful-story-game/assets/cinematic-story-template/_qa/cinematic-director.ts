import { CARTRIDGES } from '../src/story/cartridges'
import { parseStoryProtocol } from '../src/story/engine/protocol'
import { applyParsedScene, createInitialSave } from '../src/story/engine/reducer'

function ok(value: unknown, message: string): asserts value {
  if (!value) throw new Error(message)
}

const cartridge = CARTRIDGES['the-wild-road']
let save = createInitialSave(cartridge)

for (let scene = 1; scene <= 3; scene += 1) {
  save = applyParsedScene(save, parseStoryProtocol(`你在熟悉的路边停下，与同行者交换一句简短的观察。
[choices: "观察路边"|"询问同行者"|"继续前进"]`, 'zh'), cartridge, `普通行动 ${scene}`)
  const image = save.blocks.find((block) => block.id === `image-${scene}`)
  ok(image?.kind === 'image', `scene ${scene} must always schedule an image`)
  ok(image.data?.status === 'queued', `scene ${scene} image must enter the queue`)
  ok(String(image.data?.prompt ?? '').includes('Ignore all cover art and opening-scene imagery'), `scene ${scene} must use the fresh-shot prompt contract`)
}

save = applyParsedScene(save, parseStoryProtocol(`你从风暴中心取回了失落的王冠。
[inventory: action="add" item="风暴王冠" count="1" rarity="legendary"]
[choices: "戴上王冠"|"交给同行者"|"封存王冠"]`, 'zh'), cartridge, '取回王冠')
const milestone = save.blocks.find((block) => block.id === 'image-4')
ok(milestone?.data?.milestone === 'legendary-item', 'legendary discovery must mark a milestone')
ok(milestone.data?.videoStatus === 'queued', 'milestone may retain an inert video queue marker')
ok(cartridge.mediaDirector?.videoEnabled !== true, 'shared handoff must disable video transmission without separate authorization')

const portraitCartridge = {
  ...cartridge,
  mediaDirector: { ...cartridge.mediaDirector!, imageTarget: { width: 512, height: 640 } },
}
let portraitSave = createInitialSave(portraitCartridge)
portraitSave = applyParsedScene(portraitSave, parseStoryProtocol(`你推开废塔石门，正面对上守门人。
[choices: "表明来意"|"寻找侧门"|"准备迎战"]`, 'zh'), portraitCartridge, '推开石门')
const portraitPrompt = String(portraitSave.blocks.find((block) => block.id === 'image-1')?.data?.prompt ?? '')
ok(portraitPrompt.includes('4:5 portrait'), 'portrait media target must create a portrait prompt')
ok(!portraitPrompt.includes('16:9 widescreen'), 'portrait media target must not retain the landscape frame contract')

console.log('cinematic director ok · every turn image · fresh shot · inert milestone marker · video transport disabled · portrait frame')
