import assert from 'node:assert/strict'
import { seventhDock } from '../src/story/cartridges/seventhDock'
import { resolveDomainAction } from '../src/story/engine/domainRules'
import { parseStoryProtocol } from '../src/story/engine/protocol'
import { applyParsedScene, createInitialSave } from '../src/story/engine/reducer'
import type { StoryCartridge } from '../src/story/types'

const cartridge: StoryCartridge = {
  ...seventhDock,
  initialFacts: { ...seventhDock.initialFacts, 'signal-used': false },
  domainRules: {
    derivedFacts: [{ factId: 'lamp-count', mode: 'owned-item-count', itemIds: ['lamp'] }],
    rules: [{
      id: 'use-signal-lamp',
      intent: 'use-signal-lamp',
      match: ['点亮信号灯', '使用信号灯'],
      requirements: [
        { type: 'map', nodeId: 'outer', reason: '信号只能从外堤发出' },
        { type: 'fact', id: 'signal-used', notEquals: true, reason: '信号已经发出' },
        { type: 'item', id: 'lamp', minCount: 1, reason: '防潮灯已经不在行囊中' },
      ],
      effects: [
        { type: 'stat', id: 'supplies', delta: -2 },
        { type: 'fact', id: 'signal-used', value: true },
        { type: 'inventory', action: 'remove', itemId: 'lamp', count: 1 },
        { type: 'map', nodeId: 'wreck' },
        { type: 'objective', value: '登上回应信号的渡船' },
        { type: 'clock', value: '退潮前十分钟' },
        { type: 'session', ended: false },
      ],
      successText: '灯光引来渡船，代价与位置一次结清。',
      successChoices: ['靠岸', '观察回应', '掩护同伴'],
      rejectionChoices: ['检查行囊', '观察潮位', '寻找其他信号'],
    }],
  },
}

let save = createInitialSave(cartridge)
const resolution = resolveDomainAction(save, cartridge, '现在点亮信号灯')
assert.equal(resolution?.status, 'accepted')
save = applyParsedScene(save, parseStoryProtocol(`模型试图夹带另一个行动。
[widget: alert, add: 80]
[widget: supplies, add: 9]
[inventory: action="add" item="凭空物资" count="7"]
[map_update: new_location="模型地点"]
[state: value="模型目标"]
[clock: value="模型时间"]
[session_end: reason="模型提前结束"]
[choices: "错误一"|"错误二"|"错误三"]`, 'zh'), cartridge, '现在点亮信号灯', undefined, undefined, undefined, resolution)

assert.equal(save.stats.supplies, 6)
assert.equal(save.stats.alert, 15)
assert.equal(save.facts['signal-used'], true)
assert.equal(save.inventory.some((item) => item.label === '凭空物资'), false)
assert.equal(save.inventory.some((item) => item.id === 'lamp'), false)
assert.equal(save.map.find((node) => node.current)?.id, 'wreck')
assert.equal(save.objective, '登上回应信号的渡船')
assert.equal(save.time, '退潮前十分钟')
assert.equal(save.sessionEnded, false)
assert.equal(save.facts['lamp-count'], 0)
assert.deepEqual(save.choices.map((choice) => choice.label), ['靠岸', '观察回应', '掩护同伴'])

const repeated = resolveDomainAction(save, cartridge, '再使用信号灯')
assert.equal(repeated?.status, 'rejected')
save.danger = { ...save.danger, phase: 'confrontation', safeTurns: 0, severity: 3 }
const afterRepeat = applyParsedScene(save, parseStoryProtocol('[widget: supplies, add: 9]\n[choices: "检查行囊"|"观察潮位"|"寻找其他信号"]', 'zh'), cartridge, '再使用信号灯', undefined, undefined, undefined, repeated)
assert.equal(afterRepeat.stats.supplies, 6)
assert.equal(afterRepeat.map.find((node) => node.current)?.id, 'wreck')
assert.equal(afterRepeat.danger.phase, 'confrontation')
assert.equal(afterRepeat.danger.safeTurns, 0)
assert.deepEqual(afterRepeat.choices.map((choice) => choice.label), ['检查行囊', '观察潮位', '寻找其他信号'])

console.log(JSON.stringify({ ok: true, atomicTurn: true, repeatRejected: true }))
