import assert from 'node:assert/strict'
import { CARTRIDGES, CARTRIDGES_EN, resolveCartridge } from '../src/story/cartridges'
import { buildDangerDirective, repairLegacyDangerMethodChoices } from '../src/story/engine/dangerDirector'
import { createInitialSave } from '../src/story/engine/reducer'

const cartridge = resolveCartridge(undefined, 'en')
assert(cartridge.dangerDirector)
for (const candidate of [...Object.values(CARTRIDGES), ...Object.values(CARTRIDGES_EN)]) {
  candidate.dangerDirector?.methods.forEach((method) => assert(!/[、,/;；]|\sor\s|(?:^|[^如])或(?:[^者]|$)/i.test(method), `${candidate.id}: danger method must be one concrete action: ${method}`))
}
const save = createInitialSave(cartridge)
save.danger.safeTurns = cartridge.dangerDirector.maxSafeTurns + 1
const warning = buildDangerDirective(save, cartridge, 'inspect the road')
assert.equal(warning?.phase, 'warning')

save.danger = { ...save.danger, phase: 'warning', currentThreat: warning?.threat, severity: warning?.severity ?? 2 }
const confrontation = buildDangerDirective(save, cartridge, 'protect the witness')
assert.equal(confrontation?.phase, 'confrontation')

save.danger = { ...save.danger, phase: 'confrontation', currentThreat: confrontation?.threat, severity: confrontation?.severity ?? 2 }
const resolution = buildDangerDirective(save, cartridge, 'use the map')
assert.equal(resolution?.phase, 'resolution')
assert(resolution?.check)

const legacy = ['old method one', 'old method two', 'old method three'] as [string, string, string]
const migrationCartridge = { ...cartridge, dangerDirector: { ...cartridge.dangerDirector, legacyMethods: [legacy] } }
const migrated = repairLegacyDangerMethodChoices({ ...save, facts: { ...save.facts }, choices: legacy.map((label, index) => ({ id: `legacy-${index}`, label })) }, migrationCartridge)
assert.deepEqual(migrated.choices.map((choice) => choice.label), migrationCartridge.dangerDirector.methods)

console.log(JSON.stringify({ ok: true, threat: warning?.threat, outcome: resolution?.check?.outcome }))
