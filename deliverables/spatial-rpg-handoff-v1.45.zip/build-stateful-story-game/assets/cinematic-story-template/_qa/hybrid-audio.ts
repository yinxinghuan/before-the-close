import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import { createAmbientTexture, isRecordedFeatureReady, RECORDED_SOUND_PROFILE, resolveRecordedAmbience, shouldReplayRecordedBed, SFX_OUTPUT_PROFILE, StorySynth, SYNTH_AMBIENT_PROFILE } from '../src/story/audio/StorySynth'
import { listCartridges } from '../src/story/cartridges'
import type { StoryAudioTheme } from '../src/story/types'

const theme: StoryAudioTheme = {
  material: 'apartment', bpm: 64, rootHz: 130.81, scale: [0, 2, 5, 7, 9],
  levels: { music: .08, ambient: .12, sfx: .045, master: .6 }, tension: [],
  recorded: {
    music: { src: 'theme.mp3', gain: .2 },
    ambience: { src: 'world.mp3', gain: .3 },
    ambienceByLocationId: { station: { src: 'station.mp3', gain: .32 } },
    cues: { summary: { src: 'feature.mp3', gain: .18, role: 'feature', cooldownMs: 180_000 } },
  },
}

assert.equal(resolveRecordedAmbience(theme, 'station')?.src, 'station.mp3')
assert.equal(resolveRecordedAmbience(theme, 'unknown')?.src, 'world.mp3')
assert.equal(resolveRecordedAmbience({ ...theme, recorded: undefined }, 'station'), undefined)
assert.ok(RECORDED_SOUND_PROFILE.musicRepeatDelayMs >= 30_000)
assert.equal(RECORDED_SOUND_PROFILE.ambienceReplay, 'once-per-visit')
assert.equal(shouldReplayRecordedBed('ambient'), false)
assert.equal(shouldReplayRecordedBed('music'), true)
assert.equal(RECORDED_SOUND_PROFILE.maxCueVoices, 2)
assert.ok(SFX_OUTPUT_PROFILE.gainScale <= .52)
assert.ok(SFX_OUTPUT_PROFILE.minimumCueIntervalSeconds >= .18)
assert.ok(RECORDED_SOUND_PROFILE.featureCooldownMs >= 180_000)
const feature = theme.recorded?.cues?.summary
assert.ok(feature)
assert.equal(isRecordedFeatureReady(feature, false, 0, 179_999), false)
assert.equal(isRecordedFeatureReady(feature, false, 0, 180_000), true)
assert.equal(isRecordedFeatureReady(feature, true, 0, 360_000), false)
assert.equal(isRecordedFeatureReady({ src: 'effect.mp3', gain: .12, role: 'effect' }, false, 0, 360_000), false)
for (const locale of ['zh', 'en'] as const) {
  for (const cartridge of listCartridges(locale)) {
    assert.ok(cartridge.audioTheme.levels.sfx <= .045, `${cartridge.id} synthesized SFX must stay at or below the reading-first cap`)
    for (const cue of Object.values(cartridge.audioTheme.recorded?.cues ?? {})) {
      if (cue?.role === 'effect') assert.ok(cue.gain <= .12, `${cartridge.id} recorded effect must stay at or below the reading-first cap`)
    }
  }
}

class FakeAudioElement {
  preload = ''
  currentTime = 0
  volume = 1
  playCount = 0
  pauseCount = 0
  onended: (() => void) | null = null
  onerror: (() => void) | null = null
  constructor(public readonly src: string) {}
  play(): Promise<void> { this.playCount += 1; return Promise.resolve() }
  pause(): void { this.pauseCount += 1 }
}

Object.assign(globalThis, {
  window: { setTimeout, clearTimeout },
  document: { hidden: false },
  Audio: FakeAudioElement,
})
const visitSynth = new StorySynth() as unknown as {
  theme: StoryAudioTheme
  unlocked: boolean
  recordedAmbience: FakeAudioElement
  syncRecordedAmbience: (track: NonNullable<StoryAudioTheme['recorded']>['ambience'], restartVisit?: boolean) => void
  resumeRecordedBeds: () => void
}
visitSynth.theme = theme
visitSynth.unlocked = true
const visitTrack = resolveRecordedAmbience(theme, 'station')!
visitSynth.syncRecordedAmbience(visitTrack)
await Promise.resolve()
assert.equal(visitSynth.recordedAmbience.playCount, 1, 'ambience starts once on location entry')
visitSynth.recordedAmbience.onended?.()
visitSynth.resumeRecordedBeds()
assert.equal(visitSynth.recordedAmbience.playCount, 1, 'mute/page resume cannot restart completed ambience in the same visit')
visitSynth.syncRecordedAmbience(visitTrack, true)
await Promise.resolve()
assert.equal(visitSynth.recordedAmbience.playCount, 2, 'a genuine new location visit permits one fresh ambience play')

const [left, right] = createAmbientTexture(1_000, 'apartment', () => .625)
assert.equal(left.length, SYNTH_AMBIENT_PROFILE.textureSeconds * 1_000)
assert.equal(right.length, left.length)

const shell = await readFile(new URL('../src/story/StoryShell.tsx', import.meta.url), 'utf8')
assert.doesNotMatch(shell, /audio\.cue\('image'\)/, 'image completion must stay silent')
assert.doesNotMatch(shell, /const discovery = added\.some/, 'generic prose arrival must not be treated as a discovery cue')
assert.doesNotMatch(shell, /else audio\.cue\('change'\)/, 'a prose-only turn must not receive a fallback result cue')

console.log('hybrid recorded/synth audio contract passed')
