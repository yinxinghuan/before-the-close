import assert from 'node:assert/strict'
import { resolveCartridge } from '../src/story/cartridges'
import { isRedundantChoicePrompt, stageNarrativeBlocks } from '../src/story/engine/stageNarrative'

for (const locale of ['zh', 'en'] as const) {
  const cartridge = resolveCartridge(null, locale)
  const beats = stageNarrativeBlocks(cartridge.opening.blocks)
  assert(beats.length >= 4 && beats.length <= 7, `${locale} opening must contain 4–7 player-lived beats`)
  assert(beats.every((beat) => beat.text.trim() && !isRedundantChoicePrompt(beat.text)))
  assert.notEqual(beats[0]?.text, beats.at(-1)?.text)
  assert(cartridge.opening.choices.length >= 2 && cartridge.opening.choices.length <= 4)
}

console.log(JSON.stringify({ ok: true, opening: 'player-lived-sequence', control: 'choices-after-final-beat' }))
