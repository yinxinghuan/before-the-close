# 影像优先角色扮演模板：技术文档

## 1. 技术栈

- React 18 + TypeScript + Less + Vite 5，构建 `base: './'`。
- Aigram `game-chat` 负责连续剧情，协议解析器将可见剧情与机器命令拆分。
- 本地 reducer 是数值、物品、人物、同行者、关系、地点与危险结果的权威执行层。
- `useGameSave` 同时写平台云存档与本地降级；本模板使用独立命名空间 `cinematic-story-template`，不读取或覆盖旧 RPG 模板存档。
- 场景图默认使用 AlterU Media Service v1；旧 Aigram transit 只作为显式灰度回滚路径。
- 里程碑视频使用 `/video` 提交、`/video_task` 查询；混合声音导演播放 Cartridge 的本地录制音乐/环境层，Web Audio 继续负责精确反馈和失败降级。
- 阅读音效采用单回合前景预算：普通选择一次轻确认，普通正文、图片完成和常规数值变化静音；环境录音每次地点访问只播放一次，短音效每个权威事件只播放一次，恢复/重连不补播。Cartridge SFX 不高于 `0.045` 后再乘 `0.52`，录制普通/effect 增益不高于 `0.12`，`180 ms` 内合并，合成/录制短音效并发上限为 6/2，只有独立持久后果追加结果提示。

## 2. 目录结构

```text
src/
  story/
    StoryShell.tsx          固定媒体舞台、短回合卡、行动区、分镜与世界抽屉
    story.less              移动/桌面布局、舞台、显影、分镜和旧世界抽屉样式
    useStoryEngine.ts       存档镜像、行动、图片串行队列、视频里程碑队列
    types.ts                Cartridge、存档、媒体导演和协议类型
    audio/StorySynth.ts     录制音乐/环境层与 Web Audio 反馈的混合播放、静音、后台暂停和失败降级
    adapters/
      aigram.ts             AI 系统合同：短文本、每回合一个图片提议
      remote.ts             连续世界后端适配
      mock.ts               确定性演示
    engine/
      reducer.ts            权威状态结算、每回合媒体块、里程碑标记
      imageDirector.ts      新镜头重建、封面残留过滤、主角可见性判断
      dangerDirector.ts     本地危险阶段与固定骰点
      protocol.ts           文本协议解析
      worldContext.ts       发送给 AI 的权威世界上下文
    cartridges/             题材、数值、人物、物品、演示与美术配置
  shared/runtime/
    media.ts               新媒体服务图片/视频任务客户端
    useGenImage.ts          生图适配边界、幂等恢复与旧 transit 回滚
    useUpload.ts            其他用户文件上传能力；玩家头像场景图不再经过此链路
    useGenVideo.ts          首尾帧视频提交与轮询
  shared/save/useGameSave.ts
doc/                       需求、视觉与技术文档
_qa/                       媒体导演测试和多尺寸截图
```

## 3. 核心模块

### 状态与回合

`useStoryEngine()` 从 Aigram/本地存档恢复 `StorySave v6`，用本地镜像作为本次运行的真源。点击行动后，Adapter 返回短剧情和协议命令，`applyParsedScene()` 原子更新所有状态。AI 不能直接覆盖本地危险骰点、超出数值范围、凭空删除同行者或只在文字里获得物品。

每个回合结束时 `chooseSceneImage()` 必须返回一个新 prompt。AI 提议可作为当前镜头素材，但最终 prompt 由本地根据当前地点和本轮可见事件重建，并明确忽略封面/开场构图。图片块使用稳定的 `image-{scene}`；任务完成只更新该块，不能覆盖后来回合。

### 固定媒体舞台

`CinematicStage` 从 `image-{scene}` 读取当前媒体；生成未完成时回退到最近一张 `ready` 场景，并覆盖显影状态。`stageNarrative.ts` 把同一回合的第一段主要叙事解释为行动结果，把最后一段主要叙事解释为下一决策前提。结果阶段隐藏常驻画面字幕，由 `compactBeat()` 将首段结果放入自适应薄层；玩家主动推进后，薄层关闭，末段决策前提才作为 `overlayBlock` 与选项同步出现。行动记录也不占短屏正文空间。

`ui=civic` 使用单向信息层级：场景图中的地点标签和本轮行动 → 一条关键剧情结果 → 最多两个检定/数值变化 → 下一步行动。`ct-civic-viewport` 把 `CinematicStage` 与 `Composer` 放进同一个全画幅内容区；媒体绝对铺满，关键剧情、`88–138 px` 可滚动结果薄层和操作码头依次覆盖在图片底部。地点只在图片左上角出现一次；本轮行动显示在图片右上角蓝色条中；普通状态不再渲染中部标题。`compactBeat()` 在此分支只保留一条未被图片字幕使用的旁白/对话与最多两个结果块。默认 `living` 分支使用“媒体舞台 + 自适应纸色结果区 + 独立行动区”，但遵守相同信息次序与阶段合同。

共享 `TurnPhase` 明确约束 `decision → resolving → result → decision`。`act()` 在提交前记录场景号与行动文字并进入 `resolving`；响应写入新场景或错误出现后进入 `result`，此时常驻字幕和选项都隐藏；玩家点击 `ct-civic-next` 或 `ct-living-next` 才回到 `decision`，新的决策字幕与选项同时出现。CSS 依据 `is-decision / is-resolving / is-result / has-error / is-preview` 互斥显示结果区、行动条和 Composer，数字键也只在 `decision` 生效。错误状态只能重试，不能越过错误直接展示下一组选项。

`splitCaptionPages()` 按句末标点和视觉字符单元切分普通长字幕；CJK 字符按两个单元计，单页上限 62 单元。第 0 场改由 `stageNarrativeBlocks()` 把 `4–7` 个作者节拍作为单向页面，`openingReady` 在最后一拍前阻止 Composer 与数字快捷键，末拍移除页控件并交还控制权。普通回合仍可在同一字幕块内循环分页。AI 适配器同时要求单条约 30 个中文字或 65 个英文字符，形成生成约束与运行时分页双保险。

两种表现层的结果区都使用内容驱动高度，超出短屏上限才内部滚动。Civic 以 `max-height:138px` 为薄层上限，并由 `ResizeObserver` 读取 `ct-stage__beat` 的实测高度写入局部 `--ct-civic-local-tray`；结果阶段不再渲染常驻画面铭牌，因此无需为重复字幕留出避让空间。Living 使用 `auto` 行轨与 `max-height:min(34dvh,260px)`，让纸色结果区随玩家行动、旁白和数值变化自然收缩。`is-compact-beat / is-empty-beat` 继续处理 Civic 单个短 `event` 的 52 px 路径回执和完全空结果。

画面字幕来自角色对话时，两种表现层都渲染 `ct-stage__speaker`：稳定使用角色姓名的第一个 Unicode 字符作为身份牌，并在旁边显示完整角色名。Living 使用 36 px 黑银身份牌，Civic 使用 42 px 墨线身份牌。它不是 Aigram 用户头像；未来给 `StoryCharacter` 增加正式肖像 URL 后可以在同一位置替换为图片。

`Storyboard` 按媒体块生成历史列表。预览只改变 React 的 `previewScene`，不写存档；返回当前场景后恢复 Composer。

### 图片身份与尺寸

`image_subject` 是头像参考归属合同：只有主角是主要可见人物并执行镜头主动作时才使用玩家头像；同伴/NPC 主导（即使玩家陪衬或远景）、环境和物品空镜都使用 txt2img。`useAvatarImageReference()` 等玩家资料就绪后直接返回原始公开 HTTPS 头像，不读取像素、不裁成场景比例、也不经过 `useUpload()`。Media Service 的 `size` 决定最终画布，参考图只提供身份证据。

`usePlayerProfile()` 在初始阶段、宿主消息、页面聚焦和恢复可见时实时检查 shell 身份。外部页面给宿主 `10.5s` 注入窗口；若已确认是平台环境但资料桥第一次超时，则继续重试到 `30.5s`，不能在中途释放无头像首图。场景队列在身份未定时只暂停玩家场景图，物品图仍可串行生成。开场 `image-0` 与下一张 `image-1` 记录 `PLAYER_IMAGE_REFERENCE_VERSION=2`；旧存档里版本落后的玩家前两张图会自动清空 URL 并重做一次。

`imageIdentity.ts` 把短身份合同放在镜头提示最前面，并把总长度限制为 `2400` 字符。它将玩家别名统一改写成 `SUBJECT A`，移除“信使 / 旅行者 / 中世纪服装 / 自然人体”等会覆盖头像外形的角色描述。参考图定义完整可见身份而不只是脸：轮廓、形态、身体比例、材质、遮盖、面具、服装、颜色和配件均需保留；原图未出现的脸、皮肤、头发、手臂和腿禁止被补出。若 AI 把玩家亲自执行的动作误标为 `others`，本地导演只在动作没有委托语义且镜头明确提及玩家时纠正；NPC 主导仍不传头像。

`StoryMediaDirector.imageTarget` 默认 `640×360`（16:9）、`imageProfile` 默认 `fast-small`。`cartridgeForUi()` 为 Civic 派生 `512×640`（4:5）运行时 Cartridge；`imageDirector`、Aigram 适配器和远端适配器都从目标宽高生成一致的画幅提示，并要求主体处在中央 58% 安全列。Media Service 客户端把任意目标拟合到供应商允许的 64 像素网格和像素预算；Civic 的 `512×640` 可原样通过。`useGenImage()` 默认调用新服务，缺少游戏 UUID 或显式 `?media_backend=legacy` 时走旧 transit；旧路径仍不发送未确认字段。

同一次网络不确定请求会复用 request UUID，以免响应丢失后重复计费；收到结构化服务错误后释放该 UUID，让故事引擎下一次显式重试可以创建新任务。服务端仍是最终幂等权威。

界面通过根节点 `data-ui-variant` 分离表现层：默认 `living`，查询参数 `ui=civic` 使用 Modern Civic System 对照样式。`UiVariant` 控制标题信息、全画幅舞台、覆盖层、短回合内容预算、行动按钮宽度和媒体母版比例；状态、存档 key、剧情 reducer 和媒体队列完全共用，保证比较的是界面而不是两套不同玩法。

### 里程碑视频

Reducer 对以下事件写入 `milestone` 和 `videoStatus=queued`：章节节点、传奇物品、同行者变化、严重度 ≥4 的危险结算。视频 worker 等当前图 `ready` 后，取前一张已完成图为首帧、当前图为尾帧，默认生成 5 秒 4:3 视频；相邻视频至少间隔 6 回合。

视频不阻塞行动。CORS、超时、任务失败或无首帧时，状态变为 `failed/idle` 并继续显示静态图。生产接入前必须在真实域名验证 `/video` 和 `/video_task` 的浏览器 CORS；若平台改为后端代理，只替换 `useGenVideo.ts`。

Media Service 视频 v1 固定为 9:16，而当前 Civic 里程碑首尾帧是 4:5。本轮灰度只迁移图片；`useGenVideo.ts` 暂时保持原通道。后续先生成独立 9:16 视频关键帧，再迁移视频调用，不能直接把 4:5 场景图喂入新服务并宣称完成。

### 响应式和输入

默认分支在移动端使用“顶部状态—媒体—自适应短回合—行动”，桌面 ≥900 px 改为媒体左、短回合右、行动在底部。Living 的决策态用两列弹性选项，第三项可占整行；可选项使用 Cartridge 主题色外框、左侧内嵌色条和同色投影，按下时改为主题色底与白字，禁用时取消投影并降低对比。Civic 在所有尺寸都让媒体铺满状态栏下方内容区：移动端形成竖幅，桌面形成宽幅叙事墙，覆盖层自身调整宽高而不是把手机框放大。页面 body 不滚动，短回合、分镜和世界面板各自滚动。Civic 的决策码头使用由透明到深墨色的图片内渐隐背景，不再铺独立灰色板；2–4 个普通行动使用单行横向轨道，按钮按文字在 `168–286 px` 之间自适应并露出下一项。可选按钮使用 `--ct-blue` 外框、4 px 同色硬阴影和蓝底白字序号块；按下时整块蓝底白字并消除阴影。`:disabled` 使用灰色外框、灰色序号块、低对比文字且取消硬阴影。两种分支按钮均使用 `onClick`，可滚动区域拖动不会误提交；自由输入保持独立次级入口；触控目标至少 44 px。

## 4. 扩展点

- 改世界/玩法：新增或修改 `src/story/cartridges/*.ts`；不要在 Shell 硬编码题材。
- 改文字密度：调整 `compactBeat()` 的块预算和 Aigram 系统提示，两处必须同步。
- 改回合节奏：修改共享 `TurnPhase` 的转换和两个表现层对应的 `is-*` 样式；不能只改其中一个分支，也不能让 Composer 与结果区同时常驻。
- 接角色肖像：给角色数据增加肖像 URL，并在 `ct-stage__speaker` 原位替换首字身份牌；角色名仍需保留为文本和可访问语义。
- 改每回合出图：核心合同在 `engine/imageDirector.ts`；本模板不得恢复为“隔几轮才出图”。
- 接新图片模型/尺寸：在 `StoryMediaDirector` 声明目标；玩家头像保持原始身份参考，后端尺寸与模式只改 `shared/runtime/useGenImage.ts`。
- 改里程碑与间隔：修改 `reducer.ts` 的 `milestoneReason()` 和 Cartridge 的 `mediaDirector`。
- 换视频后端：只改 `shared/runtime/useGenVideo.ts`，保持 `{firstFrameUrl,lastFrameUrl,prompt,duration}` 输入与 `{url,taskId}` 输出。
- 改界面主题：优先改 Cartridge theme 与 `doc/visual.md` 定义的 token；舞台固定、选项一次提交和分镜历史属于不可随意移除的结构层。
- 导出新游戏：生成新的 uuid4 和独立存档命名空间，不得复用模板开发 UUID；部署由接收环境另行处理。
