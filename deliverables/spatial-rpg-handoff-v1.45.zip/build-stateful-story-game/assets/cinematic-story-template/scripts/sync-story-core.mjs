import { copyFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const gamesRoot = resolve(root, '..')

const sharedFiles = [
  'src/story/StoryShell.tsx',
  'src/story/Icons.tsx',
  'src/story/i18n.ts',
  'src/story/story.less',
  'src/story/types.ts',
  'src/story/useStoryEngine.ts',
  'src/story/engine/protocol.ts',
  'src/story/engine/reducer.ts',
  'src/story/engine/imageDirector.ts',
  'src/story/adapters/aigram.ts',
  'src/story/adapters/remote.ts',
  'src/story/audio/StorySynth.ts',
  'src/story/audio/useStoryAudio.ts',
]

const targets = [
  { id: 'seventh-dock', cartridge: 'seventhDock.ts' },
  { id: 'rooftop-apartment', cartridge: 'rooftopApartment.ts' },
  { id: 'the-wild-road', cartridge: 'theWildRoad.ts' },
]

for (const target of targets) {
  const targetRoot = resolve(gamesRoot, target.id)
  if (!existsSync(targetRoot)) throw new Error(`Missing target: ${targetRoot}`)
  for (const relative of sharedFiles) {
    const destination = resolve(targetRoot, relative)
    mkdirSync(dirname(destination), { recursive: true })
    copyFileSync(resolve(root, relative), destination)
  }
  copyFileSync(
    resolve(root, 'src/story/cartridges', target.cartridge),
    resolve(targetRoot, 'src/story/cartridges', target.cartridge),
  )
  const enginePath = resolve(targetRoot, 'src/story/useStoryEngine.ts')
  const engine = readFileSync(enginePath, 'utf8').replace(
    "useGameSave<PersistedStoryData>('stateful-story-template')",
    `useGameSave<PersistedStoryData>('${target.id}')`,
  )
  writeFileSync(enginePath, engine)
  console.log(`synced ${target.id}`)
}
