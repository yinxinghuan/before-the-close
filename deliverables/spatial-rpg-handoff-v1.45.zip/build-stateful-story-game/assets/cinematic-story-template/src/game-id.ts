// Development UUID for this independent template. A game created from the
// template must receive its own uuid4 before publishing and must never copy
// this value into a production cartridge.
(window as any).__GAME_UUID__ = '70ea3a95-206c-4a2b-88a2-42be26b39b85';
