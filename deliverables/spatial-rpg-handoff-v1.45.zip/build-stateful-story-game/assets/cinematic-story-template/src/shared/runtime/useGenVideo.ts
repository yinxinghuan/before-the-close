import { useCallback, useState } from 'react'

export interface GenVideoRequest {
  firstFrameUrl: string
  lastFrameUrl: string
  prompt: string
  duration?: 5 | 10
  taskId?: string
}

export interface GenVideoResult { url: string; taskId: string }

export function useGenVideo() {
  const [loading] = useState(false)
  const [error, setError] = useState<Error | null>(null)
  const generate = useCallback(async (_request: GenVideoRequest): Promise<GenVideoResult> => {
    const next = new Error('Video generation is disabled in the shared handoff package and requires separate authorization for frame URLs and video prompts.')
    setError(next)
    throw next
  }, [])
  return { generate, loading, error }
}
