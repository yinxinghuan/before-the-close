import { t } from '../i18n'
import type { EntityMetric, Locale, ParsedCommand, ParsedScene, SceneImageSubject, SkillDefinition, StoryBlock } from '../types'

const commandNames = new Set([
  'choices', 'widget', 'skill_check', 'state', 'clock', 'map_update', 'inventory',
  'reputation', 'character_update', 'party_change', 'encounter', 'fact', 'true_ending', 'session_end',
])

function uid(prefix: string, index: number, text: string): string {
  let hash = 2166136261
  for (let i = 0; i < text.length; i += 1) {
    hash ^= text.charCodeAt(i)
    hash = Math.imul(hash, 16777619)
  }
  return `${prefix}-${index}-${(hash >>> 0).toString(36)}`
}

function attrs(source: string): Record<string, string> {
  const output: Record<string, string> = {}
  const quoted = /([\w_]+)\s*=\s*(["'])(.*?)\2/g
  let match: RegExpExecArray | null
  while ((match = quoted.exec(source))) output[match[1]] = match[3]
  const bare = /([\w_]+)\s*[:=]\s*([^,\]\s]+)/g
  while ((match = bare.exec(source))) if (output[match[1]] == null) output[match[1]] = match[2]
  return output
}

function number(value: string | undefined, fallback = 0): number {
  const parsed = Number(value)
  return Number.isFinite(parsed) ? parsed : fallback
}

function parseChoices(source: string): string[] {
  const body = source.replace(/^\s*choices\s*:/i, '').replace(/\]\s*$/, '').trim()
  return body.replace(/^\[/, '').replace(/\]$/, '').split(/[|｜]/).map((choice) => {
    const trimmed = choice.trim()
    const paired = trimmed.match(/^(?:"([\s\S]*)"|'([\s\S]*)'|“([\s\S]*)”|‘([\s\S]*)’)$/)
    return (paired ? paired.slice(1).find((value) => value != null) ?? '' : trimmed).trim()
  }).filter(Boolean)
}

function extractNaturalChoices(source: string): { prose: string; choices: string[] } {
  const lines = source.split('\n')
  const nonEmptyIndexes = lines.map((line, index) => line.trim() ? index : -1).filter((index) => index >= 0)
  if (!nonEmptyIndexes.length) return { prose: source, choices: [] }
  const optionLine = /^\s*(?:(?:选项|选择|行动)\s*[一二三四五\dA-Ea-e]+\s*[：:.、)]|(?:\d{1,2}|[A-Ea-e]|[一二三四五])\s*[.、:：)]|[①②③④⑤]|[-*•])\s*(.+?)\s*$/
  const choices: string[] = []
  const choiceIndexes: number[] = []
  let cursor = nonEmptyIndexes.at(-1)!
  while (cursor >= 0 && choices.length < 5) {
    if (!lines[cursor].trim()) { cursor -= 1; continue }
    const match = lines[cursor].match(optionLine)
    if (!match) break
    const label = match[1].replace(/[。.;；]+$/, '').trim()
    if (label.length < 2 || label.length > 96) break
    choices.unshift(label)
    choiceIndexes.unshift(cursor)
    cursor -= 1
  }
  if (choices.length < 2 || choices.length > 5 || new Set(choices).size !== choices.length) return { prose: source, choices: [] }
  const previous = lines.slice(0, choiceIndexes[0]).reverse().find((line) => line.trim())?.trim() ?? ''
  const hasChoiceCue = /(?:你可以|可选择|选项|下一步|接下来|决定|打算|choose|choice|options?|next|you can|what (?:will|do) you)/i.test(previous)
  const beginsLikeAction = /^(?:先|去|前往|沿|循|跟随|返回|留下|等待|观察|检查|调查|搜索|询问|告诉|帮助|拒绝|接受|进入|使用|带|把|让|与|继续|尝试|绕|登|走|停|休息|follow|ask|return|stay|wait|watch|inspect|investigate|search|tell|help|refuse|accept|enter|use|take|continue|try|climb|walk|go|leave)/i
  if (!hasChoiceCue && (choices.length !== 3 || !choices.every((choice) => beginsLikeAction.test(choice)))) return { prose: source, choices: [] }
  choiceIndexes.forEach((index) => { lines[index] = '' })
  return { prose: lines.join('\n'), choices }
}

function parseList(value: string | undefined): string[] | undefined {
  const items = value?.split('|').map((item) => item.trim()).filter(Boolean)
  return items?.length ? items : undefined
}

function parseMetrics(value: string | undefined): EntityMetric[] | undefined {
  const metrics = parseList(value)?.map((entry) => {
    const divider = entry.search(/[:=]/)
    return divider > 0 ? { label: entry.slice(0, divider).trim(), value: entry.slice(divider + 1).trim() } : null
  }).filter((entry): entry is EntityMetric => Boolean(entry?.label && entry.value))
  return metrics?.length ? metrics : undefined
}

function optionalNumber(value: string | undefined): number | undefined {
  if (value == null || value === '') return undefined
  const parsed = Number(value)
  return Number.isFinite(parsed) ? parsed : undefined
}

function factValue(value: string | undefined): string | number | boolean {
  const clean = (value ?? '').trim()
  if (/^(?:true|false)$/i.test(clean)) return clean.toLowerCase() === 'true'
  const parsed = Number(clean)
  return clean !== '' && Number.isFinite(parsed) ? parsed : clean
}

function parseSkills(value: string | undefined): SkillDefinition[] | undefined {
  const skills = parseList(value)?.map((entry, index) => {
    const divider = entry.search(/[:=]/)
    if (divider <= 0) return null
    const label = entry.slice(0, divider).trim()
    const skillValue = optionalNumber(entry.slice(divider + 1).trim())
    if (!label || skillValue == null) return null
    return { id: `skill-${index}-${label.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || index}`, label, value: skillValue }
  }).filter((entry): entry is SkillDefinition => Boolean(entry))
  return skills?.length ? skills : undefined
}

function parseCommand(name: string, source: string, locale: Locale): ParsedCommand | null {
  const data = attrs(source)
  switch (name) {
    case 'choices': return { type: 'choices', choices: parseChoices(source) }
    case 'widget': {
      const head = source.replace(/^\s*widget\s*:/i, '').split(',')[0].trim()
      const operation = (['value', 'count', 'add', 'remove'] as const).find((key) => data[key] != null) ?? 'value'
      return head ? { type: 'widget', id: head, operation, value: operation === 'add' || operation === 'remove' ? number(data[operation]) : number(data[operation]) } : null
    }
    case 'skill_check': return {
      type: 'skill_check', skill: data.skill ?? t(locale, 'unknownAbility'), dc: number(data.dc),
      roll: number(data.rolls ?? data.roll), modifier: number(data.modifier), total: number(data.total), result: data.result ?? 'unknown',
    }
    case 'state': return { type: 'state', value: data.value ?? source.replace(/^\s*state\s*:/i, '').trim() }
    case 'clock': return { type: 'clock', value: data.value ?? source.replace(/^\s*clock\s*:/i, '').trim() }
    case 'map_update': return data.new_location || data.location ? {
      type: 'map_update', location: data.new_location ?? data.location, connectedTo: data.connected_to,
      detail: data.detail, lore: data.lore, facts: parseList(data.facts),
    } : null
    case 'inventory': {
      const rarity = data.rarity === 'rare' || data.rarity === 'legendary' ? data.rarity : data.rarity === 'common' ? 'common' : undefined
      return data.item ? {
        type: 'inventory', action: data.action === 'remove' ? 'remove' : 'add', itemId: data.item_id, item: data.item,
        count: Math.max(1, number(data.count, 1)), rarity, detail: data.detail, effect: data.effect,
        lore: data.lore, metrics: parseMetrics(data.metrics), imagePrompt: data.image_prompt,
      } : null
    }
    case 'reputation': return data.npc ? { type: 'reputation', npc: data.npc, action: data.action ?? 'changed' } : null
    case 'character_update': return data.character ? {
      type: 'character_update', characterId: data.character_id, character: data.character, role: data.role,
      detail: data.detail, lore: data.lore, vitality: optionalNumber(data.vitality), stress: optionalNumber(data.stress), skills: parseSkills(data.skills),
    } : null
    case 'party_change': return data.character ? {
      type: 'party_change', characterId: data.character_id, character: data.character, change: data.change === 'remove' ? 'remove' : 'add',
      role: data.role, detail: data.detail, lore: data.lore, vitality: optionalNumber(data.vitality), stress: optionalNumber(data.stress), skills: parseSkills(data.skills),
    } : null
    case 'encounter': {
      const phase = data.phase === 'warning' || data.phase === 'confrontation' ? data.phase : data.phase === 'resolution' ? 'resolution' : null
      const outcomes = ['none', 'critical-success', 'success', 'costly-success', 'failure', 'critical-failure'] as const
      const outcome = outcomes.find((value) => value === data.outcome)
      return phase ? { type: 'encounter', phase, kind: data.kind, severity: optionalNumber(data.severity), outcome } : null
    }
    case 'fact': return data.id && /^[a-z0-9][a-z0-9._-]{1,79}$/i.test(data.id)
      ? { type: 'fact', id: data.id, value: factValue(data.value) }
      : null
    case 'true_ending': return { type: 'true_ending', reason: data.reason ?? t(locale, 'finaleReady') }
    case 'session_end': return { type: 'session_end', reason: data.reason ?? t(locale, 'chapterPaused') }
    default: return null
  }
}

function commandSpans(raw: string, locale: Locale): Array<{ start: number; end: number; command: ParsedCommand }> {
  const spans: Array<{ start: number; end: number; command: ParsedCommand }> = []
  const pattern = /\[([a-z_]+)\s*:/gi
  let match: RegExpExecArray | null
  while ((match = pattern.exec(raw))) {
    const name = match[1].toLowerCase()
    if (!commandNames.has(name)) continue
    let cursor = pattern.lastIndex
    let quote = ''
    let depth = 1
    for (; cursor < raw.length; cursor += 1) {
      const char = raw[cursor]
      if (quote) {
        if (char === quote && raw[cursor - 1] !== '\\') quote = ''
      } else if (char === '"' || char === "'") quote = char
      else if (char === '[') depth += 1
      else if (char === ']') {
        depth -= 1
        if (depth === 0) break
      }
    }
    if (cursor >= raw.length) continue
    const source = raw.slice(match.index + 1, cursor)
    const command = parseCommand(name, source, locale)
    if (command) spans.push({ start: match.index, end: cursor + 1, command })
    pattern.lastIndex = cursor + 1
  }
  return spans
}

export function parseStoryProtocol(raw: string, locale: Locale = 'zh'): ParsedScene {
  const spans = commandSpans(raw, locale)
  let prose = raw
  for (const span of [...spans].reverse()) prose = prose.slice(0, span.start) + '\n' + prose.slice(span.end)
  prose = prose.replace(/\[[a-z_]+\s*:[^\]\n]*\]/gi, '\n')
  // Image directives are transport metadata, not story copy. Some model
  // responses omit one or both square brackets, so strip the whole line even
  // when the otherwise valid directive is malformed.
  prose = prose.replace(/^\s*\[?\s*(?:image_prompt|image_subject)\s*:\s*.*?\]?\s*$/gim, '\n')
  prose = prose.replace(/^\s*(?:请做出选择|请选择(?:下一步)?|接下来(?:你)?(?:要)?怎么做|what (?:will|do) you do next\??|make (?:a|your) choice|choose (?:your )?next action)\s*[。.!?？]*\s*$/gim, '\n')
  // Remove a protocol line that was cut off before its closing bracket. It is
  // machine residue, and leaving it at the tail prevents natural-choice scan.
  prose = prose.replace(/^\s*\[[a-z_]+\s*:.*$/gim, '\n')
  // A truncated/empty structured tag must not suppress otherwise recoverable
  // numbered choices in the visible prose.
  const hasStructuredChoices = spans.some((span) => span.command.type === 'choices' && span.command.choices.length >= 2)
  const natural = hasStructuredChoices ? { prose, choices: [] } : extractNaturalChoices(prose)
  prose = natural.prose

  const blocks: StoryBlock[] = []
  const dialogue = /^\[([^\]]+)]\s*\[([^\]]+)](?:\s*\[([^\]]+)])?\s*:\s*["“]?(.*?)["”]?\s*$/
  const lenientDialogue = /^([^\[\]:]{1,40})\s+\[([^\]]+)](?:\s*\[([^\]]+)])?\s*:\s*["“]?(.*?)["”]?\s*$/
  const bareChannelDialogue = /^\[([^\]]+)]\s+([^:\s]+)\s+([^:\s]+)\s*:\s*["“]?(.*?)["”]?\s*$/
  prose.split(/\n+/).map((line) => line.trim()).filter(Boolean).forEach((line, index) => {
    const match = line.match(dialogue) ?? line.match(lenientDialogue) ?? line.match(bareChannelDialogue)
    if (match) {
      blocks.push({ id: uid('line', index, line), kind: 'dialogue', speaker: match[1], tone: match[3] ?? match[2], text: match[4].replace(/["”]$/, '') })
    } else {
      blocks.push({ id: uid('line', index, line), kind: 'narration', text: line })
    }
  })
  return {
    blocks,
    commands: [...spans.map((span) => span.command), ...(natural.choices.length ? [{ type: 'choices' as const, choices: natural.choices }] : [])],
    raw,
  }
}

export function isProtocolResidueText(value: string): boolean {
  return /^\s*(?:\[?\s*(?:image_prompt|image_subject)\s*:\s*.*?\]?|请做出选择|请选择(?:下一步)?|接下来(?:你)?(?:要)?怎么做|what (?:will|do) you do next\??|make (?:a|your) choice|choose (?:your )?next action)\s*[。.!?？]*\s*$/i.test(value)
}

export function extractSceneImagePrompt(content: string): string | undefined {
  const match = content.match(/(?:^|\n)\s*\[?\s*image_prompt\s*:\s*(?:"([^"]+)"|'([^']+)'|([^\]\n]+?))\s*\]?\s*(?=\n|$)/i)
  return (match?.[1] ?? match?.[2] ?? match?.[3])?.trim()
}

export function extractSceneImageSubject(content: string): SceneImageSubject | undefined {
  const match = content.match(/(?:^|\n)\s*\[?\s*image_subject\s*:\s*(?:"([^"]+)"|'([^']+)'|([^\]\n]+?))\s*\]?\s*(?=\n|$)/i)
  const value = (match?.[1] ?? match?.[2] ?? match?.[3])?.trim().toLowerCase()
  return value === 'player' || value === 'environment' || value === 'others' ? value : undefined
}
