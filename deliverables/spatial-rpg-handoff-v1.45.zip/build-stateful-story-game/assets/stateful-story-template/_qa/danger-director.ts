import { CARTRIDGES, CARTRIDGES_EN } from '../src/story/cartridges/index'
import { buildDangerDirective, contextualDangerChoiceLabels, dangerDirectiveChoices, dangerDirectiveContract, repairLegacyDangerMethodChoices } from '../src/story/engine/dangerDirector'
import { parseStoryProtocol } from '../src/story/engine/protocol'
import { applyParsedScene, createChoiceRecordBlock, createInitialSave } from '../src/story/engine/reducer'
import type { DangerDirective, StoryCartridge, StorySave } from '../src/story/types'

function ok(value: unknown, message: string): asserts value { if (!value) throw new Error(message) }
function equal(actual: unknown, expected: unknown, message: string) { if (actual !== expected) throw new Error(`${message}: ${String(actual)} !== ${String(expected)}`) }

function ordinaryScene(save: StorySave, cartridge: StoryCartridge, label: string, directive?: DangerDirective): StorySave {
  const threat = directive?.threat
  const prose = threat
    ? (cartridge.locale === 'zh' ? `眼前的危险已经清楚显现：${threat}。` : `The immediate danger is now clear: ${threat}.`)
    : (cartridge.locale === 'zh' ? '局面继续推进。' : 'The situation continues.')
  const choices = directive && directive.phase !== 'resolution'
    ? (cartridge.locale === 'zh'
        ? [`确认“${threat}”的具体情况`, `立即应对“${threat}”`, `撤离“${threat}”影响的现场`]
        : [`Confirm the facts about ${threat}`, `Respond directly to ${threat}`, `Withdraw from the scene of ${threat}`])
    : (cartridge.locale === 'zh' ? ['观察周围', '改变路线', '准备工具'] : ['Observe', 'Change route', 'Prepare a tool'])
  const encounter = directive
    ? `\n[encounter: phase="${directive.phase}" kind="${directive.threat}" severity="${directive.severity}" outcome="${directive.check?.outcome ?? 'active'}"]`
    : ''
  const parsed = parseStoryProtocol(`${prose}${encounter}\n[scene_location: location="${save.location}"]\n[choices: "${choices.join('"|"')}"]`, cartridge.locale)
  return applyParsedScene(save, parsed, cartridge, label, undefined, undefined, directive)
}

for (const cartridge of [...Object.values(CARTRIDGES), ...Object.values(CARTRIDGES_EN)]) {
  const config = cartridge.dangerDirector
  ok(config, `${cartridge.id}/${cartridge.locale}: danger director is configured`)
  ok(cartridge.director, `${cartridge.id}/${cartridge.locale}: story director is configured`)
  ok(config.minSafeTurns <= config.maxSafeTurns, `${cartridge.id}: valid cadence range`)
  equal(config.resolution.dcBySeverity.length, 5, `${cartridge.id}: five severity DCs`)
  config.methods.forEach((method) => ok(!/[、,/;；]|\sor\s|(?:^|[^如])或(?:[^者]|$)/i.test(method), `${cartridge.id}: danger method is one concrete action, not a list: ${method}`))
}

{
  const base = Object.values(CARTRIDGES)[0]
  const legacy = ['旧方法一', '旧方法二', '旧方法三'] as [string, string, string]
  const cartridge = { ...base, dangerDirector: { ...base.dangerDirector!, legacyMethods: [legacy] } }
  const initial = createInitialSave(cartridge)
  const choices = legacy.map((label, index) => ({ id: `legacy-${index}`, label }))
  const save = { ...initial, scene: 9, facts: { ...initial.facts }, choices, blocks: [...initial.blocks, createChoiceRecordBlock(9, choices)] }
  const migrated = repairLegacyDangerMethodChoices(save, cartridge)
  equal(migrated.choices[0].label, cartridge.dangerDirector.methods[0], 'legacy live danger methods migrate')
  equal(JSON.parse(migrated.blocks.find((block) => block.id === 'choices-9')!.text)[2], cartridge.dangerDirector.methods[2], 'legacy choice record migrates')
}

for (const cartridge of [...Object.values(CARTRIDGES), ...Object.values(CARTRIDGES_EN)]) {
  let save = createInitialSave(cartridge)
  equal(save.version, 10, `${cartridge.id}: save schema carries facts, jobs and danger state`)
  equal(save.danger.phase, 'calm', `${cartridge.id}: starts calm`)
  let warning: DangerDirective | undefined
  const searchTurns = (cartridge.dangerDirector!.graceScenes ?? 6) + cartridge.dangerDirector!.maxSafeTurns + 2
  for (let turn = 0; turn <= searchTurns; turn += 1) {
    const action = `safe action ${turn}`
    warning = buildDangerDirective(save, cartridge, action)
    if (warning) break
    save = ordinaryScene(save, cartridge, action)
  }
  ok(warning, `${cartridge.id}: cadence guarantees a threat`)
  equal(warning.phase, 'warning', `${cartridge.id}: scheduled encounter begins with warning`)
  const warningContract = dangerDirectiveContract(warning)
  ok(warningContract.includes('DANGER DIRECTIVE IS AUTHORITATIVE'), `${cartridge.id}: AI receives authoritative danger contract`)
  ok(warningContract.includes('[encounter:'), `${cartridge.id}: AI receives structured encounter tag`)
  ok(cartridge.dangerDirector!.methods.every((method) => warningContract.includes(method)), `${cartridge.id}: AI receives all configured response methods`)
  const contextual = contextualDangerChoiceLabels(warning.threat, warning.methods, cartridge.locale)
  equal(dangerDirectiveChoices(warning, save.scene).length, contextual.length, `${cartridge.id}: replyless danger keeps a bounded contextual action set`)
  dangerDirectiveChoices(warning, save.scene).forEach((choice) => ok(choice.label.includes(warning!.threat.slice(0, cartridge.locale === 'zh' ? 8 : 12)), `${cartridge.id}: emergency button names the active threat`))
  equal(buildDangerDirective(save, cartridge, 'stable action')?.threat, buildDangerDirective(save, cartridge, 'stable action')?.threat, `${cartridge.id}: threat is stable`)

  save = ordinaryScene(save, cartridge, 'notice the warning', warning)
  equal(save.danger.phase, 'warning', `${cartridge.id}: warning persists`)
  const confrontation = buildDangerDirective(save, cartridge, 'prepare for danger')
  equal(confrontation?.phase, 'confrontation', `${cartridge.id}: warning advances to confrontation`)
  save = ordinaryScene(save, cartridge, 'prepare for danger', confrontation)
  equal(save.danger.phase, 'confrontation', `${cartridge.id}: confrontation persists for a player response`)

  let action = 'resolve danger'
  let resolution = buildDangerDirective(save, cartridge, action)
  for (let attempt = 0; resolution?.check && !['failure', 'critical-failure', 'costly-success'].includes(resolution.check.outcome) && attempt < 80; attempt += 1) {
    action = `resolve danger ${attempt}`
    resolution = buildDangerDirective(save, cartridge, action)
  }
  equal(resolution?.phase, 'resolution', `${cartridge.id}: confrontation advances to local resolution`)
  ok(resolution?.check, `${cartridge.id}: resolution owns a local check`)
  const repeated = buildDangerDirective(save, cartridge, action)
  equal(repeated?.check?.roll, resolution.check.roll, `${cartridge.id}: refresh cannot reroll`)
  const beforeCost = { ...save.stats }
  const deceptive = parseStoryProtocol(`${cartridge.locale === 'zh' ? `你处理了${resolution.threat}，结果由世界兑现。` : `You address ${resolution.threat}, and the world enforces the result.`}\n[encounter: phase="resolution" kind="${resolution.threat}" severity="${resolution.severity}" outcome="${resolution.check.outcome}"]\n[skill_check: skill="Fake" dc="1" rolls="20" modifier="9" total="29" result="success"]\n[scene_location: location="${save.location}"]\n[choices: "检查余波"|"照顾同伴"|"继续前进"]`, cartridge.locale)
  save = applyParsedScene(save, deceptive, cartridge, action, undefined, undefined, resolution)
  equal(save.danger.phase, 'calm', `${cartridge.id}: resolution returns to calm`)
  equal(save.danger.cycle, 1, `${cartridge.id}: encounter cycle advances`)
  const check = save.blocks.find((block) => block.kind === 'check' && block.id.startsWith('effect-'))
  equal(check?.data?.roll, resolution.check.roll, `${cartridge.id}: AI roll is replaced by local roll`)
  const cost = cartridge.dangerDirector!.resolution.fallbackCosts[0]
  if (['failure', 'critical-failure', 'costly-success'].includes(resolution.check.outcome)) {
    const changed = save.stats[cost.statId] !== beforeCost[cost.statId]
    ok(changed, `${cartridge.id}: missing AI consequence gets deterministic fallback cost`)
  }
  const restored = JSON.parse(JSON.stringify(save)) as StorySave
  equal(restored.danger.lastOutcome, resolution.check.outcome, `${cartridge.id}: encounter outcome survives save reload`)
}

const city = CARTRIDGES['city-of-tides']
const lowBondOnly = createInitialSave(city)
lowBondOnly.stats['city-bond'] = 0
equal(buildDangerDirective(lowBondOnly, city, 'inspect bond'), undefined, 'city bond alone does not trigger physical danger')

const dock = CARTRIDGES['seventh-dock']
const criticalDock = createInitialSave(dock)
criticalDock.stats.alert = 85
const critical = buildDangerDirective(criticalDock, dock, 'cross the quay')
equal(critical?.phase, 'confrontation', 'critical stat skips ordinary warning')
equal(critical?.severity, 5, 'critical stat forces severity five')

const encounterCommand = parseStoryProtocol('[encounter: phase="warning" kind="closing gate" severity="4" outcome="active"]', 'en').commands[0]
equal(encounterCommand?.type, 'encounter', 'encounter protocol command parses')
if (encounterCommand?.type === 'encounter') equal(encounterCommand.severity, 4, 'encounter severity parses')

equal(CARTRIDGES['rooftop-apartment'].dangerDirector?.physicalCombat, 'none', 'rooftop crises never default to physical combat')
console.log(`danger director ok · cartridges=${Object.keys(CARTRIDGES).length * 2} · cadence=stable · local_roll=authoritative · fallback_cost=verified`)
