import assert from 'node:assert/strict'
import { listCartridges } from '../src/story/cartridges/index'
import { resolveDeterministicChoiceTurn } from '../src/story/engine/authoredTurns'
import { parseStoryProtocol } from '../src/story/engine/protocol'
import { applyConsistencyRecovery, createInitialSave } from '../src/story/engine/reducer'
import { canonicalizeTurnMetadata, semanticallyRepeatsCurrentAction } from '../src/story/engine/turnConsistency'
import { normalizeSave } from '../src/story/useStoryEngine'

const cartridge = listCartridges('zh')[0]
const initial = createInitialSave(cartridge)
const failed = initial.choices[0].label
const quarantined = applyConsistencyRecovery(initial, cartridge, failed)

assert.ok(!quarantined.choices.some((choice) => choice.label === failed))
assert.ok(!quarantined.choices.some((choice) => choice.label === initial.objective))
assert.ok(!quarantined.choices.some((choice) => /查看.+现在能做的事|放弃原计划/.test(choice.label)))
assert.deepEqual(
  quarantined.choices.map((choice) => choice.label),
  initial.choices.filter((choice) => choice.label !== failed).map((choice) => choice.label),
  'a rejected recommendation keeps only trustworthy siblings',
)

const secondFailed = quarantined.choices[0].label
const quarantinedTwice = applyConsistencyRecovery(quarantined, cartridge, secondFailed)
assert.equal(quarantinedTwice.choices.length, quarantined.choices.length - 1)
assert.notDeepEqual(
  quarantinedTwice.choices.map((choice) => choice.label),
  quarantined.choices.map((choice) => choice.label),
  'consecutive failures cannot recreate the same choice-state fixed point',
)

const soleAction = '询问路边的人是否看见新的脚印'
const sole = applyConsistencyRecovery({ ...initial, choices: [{ id: 'sole', label: soleAction }] }, cartridge, soleAction)
assert.equal(sole.choices.length, 0, 'free input is the escape when no recommended sibling remains')
assert.equal(normalizeSave(sole, cartridge).choices.length, 0, 'reload does not recreate an abstract objective button')

const legacyWithoutFacts = {
  ...sole,
  blocks: sole.blocks.filter((block) => block.kind !== 'choices' || block.id === `choices-${sole.scene}`),
} as typeof sole & { facts?: typeof sole.facts }
delete legacyWithoutFacts.facts
const normalizedLegacyWithoutFacts = normalizeSave(legacyWithoutFacts, cartridge)
assert.equal(normalizedLegacyWithoutFacts.choices.length, 0, 'very old saves without a facts field cannot recreate a recovery button')
assert.equal(normalizedLegacyWithoutFacts.facts.consistency_quarantined_action, soleAction)

assert.equal(semanticallyRepeatsCurrentAction('触摸旧路牌左下角的缺口', '查看旧路牌左下角的缺口', 'zh'), true)
assert.equal(semanticallyRepeatsCurrentAction('Ask the porter about the locked gate', 'Inspect the brass directory', 'en'), false)

const otherLocation = initial.map.find((node) => node.label !== initial.location)?.label
assert.ok(otherLocation)
const scopedAction = '检查只在起点存在的旧路牌'
const scopedCartridge = {
  ...cartridge,
  deterministicChoiceTurns: [{
    action: scopedAction,
    when: { locations: [initial.location] },
    turn: { match: [], content: '你检查了起点的旧路牌。' },
  }],
}
const misplaced = { ...initial, location: otherLocation!, sceneLocation: otherLocation!, choices: [{ id: 'stale', label: scopedAction }] }
assert.equal(resolveDeterministicChoiceTurn(misplaced, scopedCartridge, scopedAction), undefined)
const misplacedDraft = canonicalizeTurnMetadata(misplaced, parseStoryProtocol(`你仍在${otherLocation}。路边放着一个破木箱。
[scene_location: location="${otherLocation}"]
[choices: "${scopedAction}"|"检查路边的破木箱"]`, 'zh'), scopedCartridge)
const misplacedChoices = misplacedDraft.parsed.commands.find((command) => command.type === 'choices')
assert.equal(misplacedChoices?.type, 'choices')
assert.deepEqual(misplacedChoices.choices, ['检查路边的破木箱'], 'an authored label cannot re-enter from the wrong scope')

const debutFollowup = '询问刚登场的值夜人钥匙从哪里来'
const debutCartridge = {
  ...cartridge,
  deterministicChoiceTurns: [{
    action: debutFollowup,
    when: { characterIds: ['night-warden'] },
    turn: { match: [], content: '值夜人回答了钥匙的来历。' },
  }],
}
const trustedDebut = canonicalizeTurnMetadata(initial, parseStoryProtocol(`一个佩旧钥匙串的成年值夜人从侧门进来，自称今晚负责巡楼。
[character_update: character_id="night-warden" character="值夜人" role="夜间看守" detail="负责巡楼" visual_appearance="One adult night warden with an old key ring" visual_traits="adult|old key ring"]
[scene_location: location="${initial.location}"]
[choices: "${debutFollowup}"|"检查侧门门闩"]`, 'zh'), debutCartridge, undefined, '请值夜人说明身份', true)
const trustedDebutChoices = trustedDebut.parsed.commands.find((command) => command.type === 'choices')
assert.equal(trustedDebutChoices?.type, 'choices')
assert.ok(trustedDebutChoices.choices.includes(debutFollowup), 'trusted authored follow-up survives a same-turn character debut')

console.log(JSON.stringify({
  ok: true,
  checks: [
    'failed-recommendation-retired',
    'siblings-preserved',
    'consecutive-failure-no-fixed-point',
    'free-input-only-reload-safe',
    'factless-legacy-reload-safe',
    'semantic-retry-filter',
    'authored-action-scope',
    'trusted-authored-same-turn-debut',
  ],
}))
