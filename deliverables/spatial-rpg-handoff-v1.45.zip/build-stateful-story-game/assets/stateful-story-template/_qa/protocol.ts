import { CARTRIDGES, CARTRIDGES_EN } from '../src/story/cartridges/index'
import { detectTextLocale } from '../src/story/i18n'
import { extractSceneImageSubject, isStoryProtocolResidue, parseStoryProtocol } from '../src/story/engine/protocol'
import { applyParsedScene, createInitialSave, normalizeCharacterState } from '../src/story/engine/reducer'
import { buildWorldContext } from '../src/story/engine/worldContext'
import { prepareTurnCandidate } from '../src/story/engine/turnPipeline'

function ok(value: unknown, message: string): asserts value { if (!value) throw new Error(message) }
function equal(actual: unknown, expected: unknown, message = 'values differ') { if (actual !== expected) throw new Error(`${message}: ${String(actual)} !== ${String(expected)}`) }
function deepEqual(actual: unknown, expected: unknown, message = 'structures differ') {
  const left = JSON.stringify(actual); const right = JSON.stringify(expected)
  if (left !== right) throw new Error(`${message}: ${left} !== ${right}`)
}

for (const cartridge of [...Object.values(CARTRIDGES), ...Object.values(CARTRIDGES_EN)]) {
  const initial = createInitialSave(cartridge)
  deepEqual(Object.keys(initial.stats), cartridge.statDefinitions.map((stat) => stat.id))
  const parsed = parseStoryProtocol(cartridge.demoTurns[0].content, cartridge.locale)
  ok(parsed.blocks.length >= 2, `${cartridge.id}: prose parsed`)
  ok(parsed.commands.some((command) => command.type === 'choices'), `${cartridge.id}: choices parsed`)
  ok(parsed.commands.some((command) => command.type === 'skill_check'), `${cartridge.id}: skill check parsed`)
  const prepared = prepareTurnCandidate({
    save: initial, parsed, cartridge, action: 'QA action',
    imagePrompt: cartridge.demoTurns[0].imagePrompt, trustedAuthored: true,
  })
  ok(prepared.violations.length === 0 || prepared.canCommitWithoutReplies, `${cartridge.id}: authored fixture is safe at the public turn boundary`)
  const next = applyParsedScene(initial, prepared.parsed, cartridge, 'QA action', prepared.imagePrompt)
  equal(next.scene, 1)
  ok(next.blocks.some((block) => block.kind === 'check'), `${cartridge.id}: check block applied`)
  ok(next.choices.length >= 1 || prepared.canCommitWithoutReplies, `${cartridge.id}: invalid replies are removed without fabricating replacements`)
  const nextGroundedLabel = next.choices[0]?.label ?? (cartridge.locale === 'en' ? `Observe ${next.location}` : `观察${next.location}`)
  const continuation = cartridge.locale === 'en'
    ? `You consider this established action: ${nextGroundedLabel}.\n[scene_location: location="${next.location}"]\n[image_location: location="${next.location}"]\n[choices: "${nextGroundedLabel}"]`
    : `你确认眼下仍能执行“${nextGroundedLabel}”。\n[scene_location: location="${next.location}"]\n[image_location: location="${next.location}"]\n[choices: "${nextGroundedLabel}"]`
  const continuationParsed = parseStoryProtocol(continuation, cartridge.locale)
  const continuationPrepared = prepareTurnCandidate({ save: next, parsed: continuationParsed, cartridge, action: 'QA image action', imagePrompt: 'QA image prompt' })
  ok(continuationPrepared.violations.length === 0, `${cartridge.id}: concrete continuation passes the public turn boundary`)
  const withImage = applyParsedScene(next, continuationPrepared.parsed, cartridge, 'QA image action', continuationPrepared.imagePrompt)
  const inlineImage = withImage.blocks.find((block) => block.id === `image-${withImage.scene}`)
  equal(inlineImage?.kind, 'image', `${cartridge.id}: image remains inline at the triggering turn`)
  equal(inlineImage?.data?.status, 'queued', `${cartridge.id}: inline image queued`)
  equal(withImage.blocks.at(-1)?.kind, 'choices', `${cartridge.id}: the story article records the same choices as the tray`)

  const remote = createInitialSave(cartridge, `qa-${cartridge.id}`)
  equal(remote.version, 10, `${cartridge.id}: current save schema`)
  equal(remote.locale, cartridge.locale, `${cartridge.id}: save locale`)
  equal(remote.remoteChatId, `qa-${cartridge.id}`, `${cartridge.id}: remote chat id is part of the save`)
}

const contextCartridge = Object.values(CARTRIDGES)[0]
const contextInitial = createInitialSave(contextCartridge)
const ordinaryContext = applyParsedScene(contextInitial, parseStoryProtocol(`铁匠说明车轮仍然松动。\n[choices: "固定车轴"|"寻找绳索"|"询问原因"]`, 'zh'), contextCartridge, '检查车轮')
equal(ordinaryContext.decisionContext, '', 'ordinary visible prose does not create a duplicate context row')
const authoredContext = applyParsedScene(contextInitial, parseStoryProtocol(`车轮仍然松动。\n[situation: "道路要等车轴固定后才能通行"]\n[choices: "固定车轴"|"寻找绳索"|"询问原因"]`, 'zh'), contextCartridge, '检查车轮')
equal(authoredContext.decisionContext, '道路要等车轴固定后才能通行', 'an independent concise situation is preserved')
const statusDump = parseStoryProtocol(`铁匠请你查看水井。\n\n【当前状态更新】\n体力：75\n补给：6\n位置：铁匠铺\n角色身份：帮工\n\n[widget: vitality, value: 75]\n[choices: "查看水井"|"寻找绳索"|"先休息"]`, 'zh')
ok(statusDump.blocks.some((block) => block.text.includes('铁匠')), 'story prose remains visible around a rejected status report')
ok(statusDump.blocks.every((block) => !/当前状态更新|体力：75|角色身份：帮工/.test(block.text)), 'narrated status reports never enter visible prose')
ok(statusDump.commands.some((command) => command.type === 'widget'), 'authoritative widget commands survive status-report filtering')

const malformed = parseStoryProtocol(`一段正文\n[choices: ["甲", "乙", "丙"] ]\n[widget: tide, value: 61]\n[unknown: value="ignored"]`)
deepEqual(malformed.commands.find((command) => command.type === 'choices'), { type: 'choices', choices: ['甲', '乙', '丙'] })
deepEqual(malformed.commands.find((command) => command.type === 'widget'), { type: 'widget', id: 'tide', operation: 'value', value: 61 })
equal(malformed.blocks.length, 1, 'unknown tags are hidden and cannot mutate state')

const curlyChoices = parseStoryProtocol('正文\n[choices: “查看屋顶”｜“询问住户”｜“检查账本”]', 'zh')
deepEqual(curlyChoices.commands.find((command) => command.type === 'choices'), { type: 'choices', choices: ['查看屋顶', '询问住户', '检查账本'] }, 'curly quotes and full-width separators are accepted')

const missingColonFocus = parseStoryProtocol('她放松地笑了。\n[dialogue_focus speaker="短发女人" expression="感激而轻松的笑容"]', 'zh')
deepEqual(missingColonFocus.commands.find((command) => command.type === 'dialogue_focus'), { type: 'dialogue_focus', speaker: '短发女人', expression: '感激而轻松的笑容' }, 'missing-colon attribute command is canonicalized')
ok(missingColonFocus.blocks.every((block) => !block.text.includes('dialogue_focus')), 'missing-colon protocol never leaks into visible prose')
ok(isStoryProtocolResidue('[dialogue_focus speaker="短发女人" expression="微笑"]'), 'saved missing-colon protocol residue is detectable for migration')

const naturalChoices = parseStoryProtocol(`风从岔路口吹来。你接下来可以：
1. 沿森林边缘寻找蓝烟
2. 前往灰瓦村查看翻倒的货车
3. 先观察北丘旧塔的铜光`, 'zh')
deepEqual(naturalChoices.commands.find((command) => command.type === 'choices'), { type: 'choices', choices: ['沿森林边缘寻找蓝烟', '前往灰瓦村查看翻倒的货车', '先观察北丘旧塔的铜光'] }, 'numbered prose choices become buttons')
ok(!naturalChoices.blocks.some((block) => /^\d+[.、]/.test(block.text)), 'recovered prose choice lines are not duplicated in narration')

const naturalEnglishChoices = parseStoryProtocol(`The rain exposes three possible routes. You can:
- Follow the fresh cart tracks
- Ask the ferryman about the lantern
- Wait under the bridge until dusk`, 'en')
deepEqual(naturalEnglishChoices.commands.find((command) => command.type === 'choices'), { type: 'choices', choices: ['Follow the fresh cart tracks', 'Ask the ferryman about the lantern', 'Wait under the bridge until dusk'] }, 'English bullet choices become buttons')

const singleChoice = parseStoryProtocol('钟声响起，眼下只有一条通道。\n[choices: "沿已确认的通道前进"]', 'zh')
deepEqual(singleChoice.commands.find((command) => command.type === 'choices'), { type: 'choices', choices: ['沿已确认的通道前进'] }, 'one valid structured choice is accepted without padding')

const fiveChoices = parseStoryProtocol('公告牌列出五项都能立即处理的事。\n[choices: "查看公告"|"检查门锁"|"询问守门人"|"留在原地等待"|"返回驿站"]', 'zh')
equal((fiveChoices.commands.find((command) => command.type === 'choices') as { choices?: string[] } | undefined)?.choices?.length, 5, 'five valid structured choices are preserved')

const bareActionChoices = parseStoryProtocol(`风雨暂时停了。
一、检查桥下的新脚印
二、询问守桥人昨夜的动静
三、返回村庄寻找失主`, 'zh')
equal((bareActionChoices.commands.find((command) => command.type === 'choices') as { choices?: string[] } | undefined)?.choices?.length, 3, 'three explicit actions recover without a cue sentence')

const factualList = parseStoryProtocol(`你确认了三件事实：
- 桥面仍然潮湿
- 守桥人昨夜当班
- 村庄距离这里两里`, 'zh')
equal(factualList.commands.some((command) => command.type === 'choices'), false, 'three factual bullets are not misread as player actions')

const choiceTestWorld = CARTRIDGES['the-wild-road']
const noDecision = applyParsedScene(createInitialSave(choiceTestWorld), parseStoryProtocol('你完成了这次短暂休息。', 'zh'), choiceTestWorld, '休息')
ok(noDecision.choices.length <= 5, 'missing choices never create a padded tray')
ok(!noDecision.choices.some((choice) => choice.label === '休息'), 'the just-completed action is not immediately re-offered')
ok(!noDecision.blocks.some((block) => block.id.startsWith('consistency-recovery-')), 'replyless consequence does not become a synthetic consistency recovery')
ok(noDecision.choices.every((choice) => choice.label !== choiceTestWorld.copy.continue), 'choice recovery never invents a generic continue button')

const truncatedStructured = parseStoryProtocol(`桥下传来水声，桥墩有新刻痕，守桥人听见了昨夜的动静，村庄正在寻找失主。你接下来可以：
1. 检查桥墩上的新刻痕
2. 询问守桥人昨夜的动静
3. 返回村庄寻找失主
[choices: "检查桥墩上的新刻痕"`, 'zh')
equal((truncatedStructured.commands.find((command) => command.type === 'choices' && command.choices.length >= 2) as { choices?: string[] } | undefined)?.choices?.length, 3, 'truncated structured choices do not suppress visible numbered actions')
const recoveredTruncated = applyParsedScene(createInitialSave(choiceTestWorld), truncatedStructured, choiceTestWorld, '查看桥下')
deepEqual(recoveredTruncated.choices.map((choice) => choice.label), ['检查桥墩上的新刻痕', '询问守桥人昨夜的动静', '返回村庄寻找失主'], 'visible actions become the exact buttons after a truncated tag')

const emptyAfterValid = applyParsedScene(createInitialSave(choiceTestWorld), {
  blocks: [{ id: 'qa-empty-after-valid', kind: 'narration', text: '林间出现三条可辨认的路径：溪谷、带树上记号的小径与返回营地的旧路。' }],
  commands: [
    { type: 'choices', choices: ['沿溪谷前进', '检查树上的记号', '返回营地'] },
    { type: 'choices', choices: [] },
  ],
  raw: '',
}, choiceTestWorld, '辨认道路')
deepEqual(emptyAfterValid.choices.map((choice) => choice.label), ['沿溪谷前进', '检查树上的记号', '返回营地'], 'a malformed late tag cannot erase valid choices')

const checkpointWithChoices = applyParsedScene(createInitialSave(choiceTestWorld), parseStoryProtocol(`这一段旅程暂时记在这里；脚印仍可追踪，十字路口可以返回，溪谷也允许扎营。
[choices: "继续追踪脚印"|"返回十字路口"|"在溪谷扎营"]
[session_end: reason="阶段记录"]`, 'zh'), choiceTestWorld, '记录')
equal(checkpointWithChoices.sessionEnded, true, 'checkpoint state is retained')
equal(checkpointWithChoices.choices.length, 3, 'real choices survive a checkpoint instead of being replaced by generic continue')

const wildRoad = CARTRIDGES['the-wild-road']
const wildStart = createInitialSave(wildRoad)
const wildParsed = parseStoryProtocol(`时间和道路发生变化。\n[clock: value="初夏第 1 天 · 11:40"]\n[widget: vitality, value: 10]\n[map_update: new_location="无名溪谷" connected_to="旧十字路口" detail="有废弃石龛的狭长溪谷" lore="守路人曾在这里确认商旅是否平安通过" facts="水源稳定|有旧驿路徽记"]\n[inventory: action="add" item="守路人的路镜" count="1" rarity="rare" detail="嵌在铜框里的透明薄片" effect="显出近期脚印；每次使用都会增加裂纹" lore="旧驿站守路人的工具" metrics="完整度: 4 次|范围: 60 米" image_prompt="single cracked pathglass, object only, no text, square"]`, 'zh')
const wildNext = applyParsedScene(wildStart, wildParsed, wildRoad, 'QA open-world turn')
equal(wildNext.time, '初夏第 1 天 · 11:40', 'clock command persists visible time')
equal(wildNext.stats.vitality, 57, 'per-turn stat delta is clamped by cartridge')
equal(wildNext.inventory.at(-1)?.rarity, 'rare', 'treasure rarity is persisted')
ok(wildNext.inventory.at(-1)?.detail?.includes('铜框'), 'treasure description is persisted')
ok(wildNext.inventory.at(-1)?.effect?.includes('裂纹'), 'treasure effect and limitation are persisted')
equal(wildNext.inventory.at(-1)?.metrics?.[0]?.value, '4 次', 'treasure metrics are parsed')
ok(wildNext.inventory.at(-1)?.imagePrompt?.includes('object only'), 'item illustration prompt is persisted')
equal(wildNext.map.find((node) => node.label === '无名溪谷')?.facts?.length, 2, 'place facts are persisted')

const firstRecruit = applyParsedScene(wildStart, parseStoryProtocol(`林边一个扎着深色短辫的成年向导把弓背到肩后，旧营牌上写着“阿岚”。阿岚说明自己熟悉溪谷与兽径，答应和你一起赶路。
[character_update: character_id="alan-guide" character="阿岚" role="林地向导" detail="熟悉溪谷与兽径" lore="来自灰瓦村北面的猎户营" vitality="78" stress="12" skills="观察: 3|追踪: 4" visual_appearance="One adult woodland guide, dark short braid, weathered green cloak" visual_traits="adult|dark short braid|weathered green cloak"]
[party_change: character_id="alan-guide" character="阿岚" change="add"]
[choices: "与阿岚继续赶路"|"询问她的来历"|"先在林边扎营"]`, 'zh'), wildRoad, '邀请阿岚同行')
equal(firstRecruit.partyMemberIds.length, 1, 'first recruited companion enters the authoritative party')
const alan = firstRecruit.characters.find((character) => character.name === '阿岚')
ok(alan, 'recruited dynamic character is persisted')
equal(alan.status, 'companion', 'recruited character has companion status')
equal(alan.role, '林地向导', 'character_update details survive party_change merge')

const secondRecruit = applyParsedScene(firstRecruit, parseStoryProtocol(`商车旁一个背草药箱的成年医师正在包扎手腕，药箱铜牌写着“伊芙”。伊芙说明草药有限，但同意与现有队伍一起前往河谷，而阿岚仍在你身边。
[character_update: character_id="eve-medic" character="伊芙" role="商队医师" detail="携带有限的草药" vitality="66" stress="24" skills="治疗: 4" visual_appearance="One adult caravan medic, chestnut hair, gray herb satchel" visual_traits="adult|chestnut hair|gray herb satchel"]
[party_change: character_id="eve-medic" character="伊芙" change="add"]
[choices: "让两位同伴交换路线情报"|"四人一起前往河谷"|"先确认商队的目的"]`, 'zh'), wildRoad, '邀请伊芙加入现有队伍')
equal(secondRecruit.partyMemberIds.length, 2, 'new recruit merges instead of replacing the old party')
ok(secondRecruit.partyMemberIds.includes(alan.id), 'old companion remains after meeting and recruiting a new group')

let longJourney = secondRecruit
for (let index = 0; index < 24; index += 1) {
  longJourney = applyParsedScene(longJourney, parseStoryProtocol(`第 ${index + 1} 段旅程继续推进。\n[choices: "继续观察"|"与同伴交谈"|"检查道路"]`, 'zh'), wildRoad, `长线行动 ${index + 1}`)
}
const restoredJourney = JSON.parse(JSON.stringify(longJourney)) as typeof longJourney
deepEqual(restoredJourney.partyMemberIds, secondRecruit.partyMemberIds, 'party survives more than twenty recent story blocks and JSON save reload')
const context = buildWorldContext({ cartridge: wildRoad, save: restoredJourney, actionId: '遇见另一群陌生人', locale: 'zh' })
deepEqual(context.current.activeParty.map((character) => character.name).sort(), ['伊芙', '阿岚'], 'AI context always receives the complete authoritative active party')

const knownStranger = applyParsedScene(restoredJourney, parseStoryProtocol(`石桥边一个戴旧毡帽的成年看守正用木杆测量水深，桥头值班牌写着“守桥人”。守桥人说明上游水势正在上涨，可以回答你的问题，但没有表示要同行。\n[character_update: character_id="bridge-warden" character="守桥人" role="河桥看守" detail="知道上游水势" visual_appearance="One adult bridge warden, old felt hat, wooden depth gauge" visual_traits="adult|old felt hat|wooden depth gauge"]\n[choices: "询问水势"|"与同伴商量"|"离开石桥"]`, 'zh'), wildRoad, '向守桥人介绍自己')
equal(knownStranger.partyMemberIds.length, 2, 'meeting a known stranger cannot replace current companions')
equal(knownStranger.characters.find((character) => character.name === '守桥人')?.status, 'known', 'recurring stranger is recorded without being forced into the party')

const silentDeparture = applyParsedScene(knownStranger, parseStoryProtocol(`[party_change: character_id="${alan.id}" character="阿岚" change="remove"]\n[choices: "继续赶路"|"检查地图"|"准备晚餐"]`, 'zh'), wildRoad, '继续赶路')
ok(silentDeparture.partyMemberIds.includes(alan.id), 'a remove command without a visible departure cannot silently erase a companion')

const explicitDeparture = applyParsedScene(knownStranger, parseStoryProtocol(`阿岚决定留在石桥照顾伤员。你们明确告别，她暂时离开队伍。\n[party_change: character_id="${alan.id}" character="阿岚" change="remove"]\n[choices: "向阿岚道别"|"和伊芙继续走"|"在原地休息"]`, 'zh'), wildRoad, '与阿岚道别')
equal(explicitDeparture.partyMemberIds.length, 1, 'explicit departure removes exactly one companion')
ok(explicitDeparture.partyMemberIds.every((id) => id !== alan.id), 'departing character id is removed')
ok(explicitDeparture.partyMemberIds.some((id) => explicitDeparture.characters.find((character) => character.id === id)?.name === '伊芙'), 'other companions survive an explicit departure')

const legacyCharacterState = normalizeCharacterState({
  blocks: [
    { id: 'effect-2-0', kind: 'event', text: '旧旅伴加入了同行者' },
    { id: 'effect-8-0', kind: 'event', text: '第二旅伴加入了同行者' },
    { id: 'effect-9-0', kind: 'event', text: '旧旅伴离开了同行者' },
  ],
  relationships: [],
}, wildRoad)
deepEqual(legacyCharacterState.partyMemberIds.map((id) => legacyCharacterState.characters.find((character) => character.id === id)?.name), ['第二旅伴'], 'v4 migration reconstructs only protocol-confirmed join/leave history')

const lenientDialogue = parseStoryProtocol('Mira [main] [thoughtful]: "The marks lead toward Wreck Alley."', 'en')
equal(lenientDialogue.blocks[0]?.kind, 'dialogue', 'unbracketed AI speaker is parsed as dialogue')
equal(lenientDialogue.blocks[0]?.speaker, 'Mira', 'unbracketed AI speaker name is preserved')

const bareChannelDialogue = parseStoryProtocol('[Shepherd] main neutral: "Not many take this path."', 'en')
equal(bareChannelDialogue.blocks[0]?.kind, 'dialogue', 'AI dialogue with bare channel and tone is parsed')
equal(bareChannelDialogue.blocks[0]?.speaker, 'Shepherd', 'bare-channel speaker is preserved')
equal(bareChannelDialogue.blocks[0]?.tone, 'neutral', 'bare-channel tone is preserved')

equal(detectTextLocale('我们先看看潮位', 'en'), 'zh', 'Chinese reply switches to zh')
equal(detectTextLocale('Let us inspect the quay', 'zh'), 'en', 'English reply switches to en')
equal(detectTextLocale('Mira', 'zh'), 'zh', 'single proper name preserves locale')
equal(detectTextLocale('42?!', 'zh'), 'zh', 'symbols and numbers preserve locale')
equal(extractSceneImageSubject('[image_prompt: "wide bridge scene"]\n[image_subject: "player"]'), 'player', 'player-visible scene metadata parses')
equal(extractSceneImageSubject('[image_subject: environment]'), 'environment', 'bare environment scene metadata parses')

console.log(`protocol ok · localized_cartridges=${Object.keys(CARTRIDGES).length * 2}`)
