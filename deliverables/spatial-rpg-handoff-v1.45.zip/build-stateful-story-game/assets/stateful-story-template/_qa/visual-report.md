# Game Visual QA Report

## Context

- Game/build: Stateful Story Template 0.5.0 主角头像、双语与世界母图
- Review target: A2「对话世界志」双 Cartridge、zh/en、用户头像主角、英文-only 平台海报
- Requirements and visual bible: `doc/requirements.md`, `doc/visual.md`, `doc/screen-contract.md`
- Viewports: 390×844 与 320×568；platform-layout 为主验收，external-guest 为发布检查
- Evidence: `_qa/ui/*v04-pass1*.png`、`*v04-final*.png` 与 `dock-player-avatar-*-v05-*.png`

## Executive assessment

- Decision: Pass
- Strongest quality: 两个世界已有各自的叙事母图，入口与未出图消息在保持世界身份的同时明确区分“封面”和“记录中”。
- Localization: 英文系统首开、中文回答切换、英文回答切回、最后语言恢复均通过自动化；旧消息不重写，已知世界资料跟随当前语言。
- Player identity: 玩家行动右侧显示当前头像，人物页以主角记录置顶；HTTPS 用户头像作为关键剧情生图 `ref_url`，默认 `U` 不发送给 img2img。
- Poster: 正式文件只有英文 `SEVENTH DOCK`；1024×1024 与 160×160 均人工复验，无中文或中英混排。
- P0/P1/P2 counts: 0 / 0 / 1

## Scorecard

| Category | Score 1–5 | Evidence | Required action |
|---|---:|---|---|
| Hierarchy | 5 | dock/apartment entry and core final | 无 |
| Coherence | 5 | 独立世界母图、主题色与 Cartridge 文案 | 无 |
| Readability | 4 | 英文 390、中文 320、语言切换、超长用户名 final | 正式接口继续观察极长 AI 选项 |
| Game feel | 4 | 原位图片、pending、检定、数值批注 | 后续增加事件音效 |
| Asset quality | 5 | 两张 1024 世界母图与英文正式海报 | 无 |
| Responsive UX | 5 | 390×844 / 320×568 final | 无 |
| Polish | 5 | 入口、对话、抽屉、占位与海报 | 无 |

## Findings and resolutions

### P1 · 语言切换后页眉地点残留英文（已修复）

第一轮截图中，英文开场后用中文行动，Shell 和新回复已切中文，但页眉仍显示 `Seventh Dock · Outer Quay`。历史消息应保留，当前世界资料不应残留旧语言。新增 `localizeKnownState()`，只按稳定 id 映射 Cartridge 已登记的地点、时间、目标、地图和初始物品；AI 新造专名与历史 block 不翻译。最终证据 `dock-language-switch-v04-final-platform-layout-390x844.png` 显示页眉为“第七码头 · 外堤 · 潮前 02:10”。

### P1 · 平台海报错误出现中文（已修复并升级门禁）

曾错误制作中文与中英双语候选。最终候选由 Aigram transit 重做为英文-only `SEVENTH DOCK`，同时覆盖游戏 repo 与 games repo。项目全局 `CORE_RULES.md` 已增加强制规则：AlterU 正式海报禁止中文和中英混排，制作提示与 1024/160 复验都要执行中文字符 absence 检查。来源与拒绝记录见 `doc/poster-source.md`。

### P2 · 历史图片标题保留产生时语言（按设计保留）

语言切换截图中，开场图片标题仍为英文，而页眉、数值、新行动和新回复已切中文。这是历史记录不可覆写合同的可见结果，不是漏译；后续新生成图片使用新语言地点。

### P1 · 主角只有抽象“你的行动”，缺少当前用户形象（已修复）

玩家原先只通过右侧气泡存在，人物页只列 NPC，剧情图也只能生成固定陌生人。0.5.0 增加 32 px 玩家行动身份章和 48 px 主角记录，并把公开 HTTPS 用户头像传入同一串行生图队列。390×844 与 320×568 均验证长用户名省略、头像裁切、世界抽屉和生图请求体；没有真实头像时使用默认 `U` UI 回退并继续 txt2img。

### P1 · 320 px 长行动将玩家头像推到屏幕外（已修复）

第一轮窄屏证据显示聊天区隐式网格列按长内容扩张到约 401 px，页面外层虽隐藏横向溢出，右侧头像实际落在视口之外。Shell 现显式使用 `minmax(0,1fr)` 列，Conversation 允许收缩，玩家气泡宽度为扣除头像与间距后的可用宽度；自动化新增头像 bounding-box 与页面横向溢出断言。最终 `dock-player-avatar-action-v05-final-platform-layout-320x568.png` 中消息、头像和快速回复均完整可见。

## Foundation audit

- Functional emoji icons: 无；严格审计通过。
- Touch targets: 世界、关闭、发送、重试和快速回复至少 44 px。
- Scroll vs click: 快速回复与抽屉标签使用 `onClick`，横向/纵向滚动不在按下时误提交。
- Reading anchor: 开场和行动结果优先锚定首段文字，图片等待/完成不触发滚动；快速回复按文字长度自适应并限制在 82vw 内。两个独立游戏均通过 390×844 与 320×568 复验。
- Color independence: 当前、警告、危险、检定和加载均同时使用文字/结构，不只依赖颜色。
- State coverage: entry、loading、core、pending、check、inline image idle/generating/ready/failed、drawer、Aigram error/retry、remote error、summary、zh/en switch。
- Player profile coverage: HTTPS 调试头像、超长用户名、默认头像、行动身份章、人物页主角、生图 `ref_url` 与无横向溢出断言。
- Text size coverage: 顶部 `Aa` 三档菜单、44 px 触控目标、默认 17 px/大档 19 px、刷新恢复、标题与控件不重叠，以及 390×844/320×568 证据。
- Asset provenance: 世界母图与海报均来自 Aigram transit；无 CSS/Canvas/SVG 栅格海报。
- Poster language: 1024 与 160 只见英文 `SEVENTH DOCK`，无中文或伪中文字符。

## Iteration evidence

- First pass: `_qa/ui/*v04-pass1*.png`。
- Fixes: 当前世界资料语言映射；中文演示 tone 本地化；平台海报从双语候选改为英文-only；全局发布门禁补录；主角头像接入消息、人物页与生图队列；修复 320 px 隐式网格列扩张；头像 QA 改用真实脸部裁切并加入头像可见性与横向溢出断言。
- Matched final: `_qa/ui/*v04-final*.png` 与 `_qa/ui/dock-player-avatar-*-v05-final-platform-layout-{390x844,320x568}.png`。
- Automated checks: protocol localized cartridges=4 + lenient AI dialogue；persistence mock-loop repaired + worlds=2；i18n system=en, en→zh→en, restored=en；avatar action badge / protagonist record / gen-image ref_url / default fallback；text size large=19 px and restored after reload。
- Real Aigram evidence: `_qa/real-ai.mjs` used the live `game-chat` endpoint for both Cartridges; each committed scene 1 and exactly three new choices. Captures: `dock-real-ai-platform-layout-390x844.png`, `rooftop-real-ai-platform-layout-390x844.png`。

## Final recommendation

- Final average: 4.7 / 5
- Categories below 3: 无
- Decision: 通过默认 Aigram AI 连续剧情发布门槛；正式 `head_url` 已由用户真机确认。实验 remote chatId 创建合同与跨设备云恢复仍继续观察。

## 2026-08-06 · 桌面分享布局回归

- 范围：共享母版、《第七码头》《屋顶公寓》《旷野之路》的外部访客入口与进入后的对话 Shell。
- 视口：1440×900、1024×768；移动回归 390×844 与 320×568。
- 修复前 P1：桌面 Shell 限宽 720 px，但时间线与快速回复使用 `100vw` 计算内部留白。1440×900 下正文实际仅 42 px，中文逐字竖排；Conversation/Replies 宽 760 px 并溢出 720 px Shell。
- 修复：内部阅读轴改按容器 `100%` 计算；桌面 Shell 放宽到 960 px，正文保持 610 px、Composer 680 px、页眉轴 760 px；外侧由 Cartridge 的 `--st-outer` 填充。入口场景图在大桌面适度放宽到 620 px，访客栏仍只作为外部覆盖层验证。
- 最终测量：1440×900 与 1024×768 均为 Shell/Conversation 960 px、Narration 610 px、Composer 680 px，`documentScrollWidth === viewport.width`。三个独立游戏测量一致。
- 最终证据：`wild-road-desktop-before-*.png`、`wild-road-desktop-after-*.png`、三个独立项目的 `*-desktop-dedicated-after-*.png`，以及 `*-desktop-fix-mobile-regression-*.png`。
- 结果：P0/P1/P2 = 0/0/0；桌面分享与原移动布局均通过。
