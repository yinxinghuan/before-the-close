import { cp, mkdir, readFile, readdir, rm, stat, writeFile } from 'node:fs/promises'
import path from 'node:path'
import process from 'node:process'

function args() {
  const values = new Map()
  for (let index = 2; index < process.argv.length; index += 2) values.set(process.argv[index], process.argv[index + 1])
  return values
}

const options = args()
const id = options.get('--id')
const file = options.get('--file')
const zhExport = options.get('--zh-export')
const enExport = options.get('--en-export')
const title = options.get('--title')
const saveNamespace = options.get('--save-namespace')
const uuid = options.get('--uuid')
const targetArg = options.get('--target')

if (!id || !file || !zhExport || !enExport || !title || !saveNamespace || !uuid || !targetArg) {
  throw new Error('Usage: node scripts/export-cartridge.mjs --id ID --file FILE --zh-export NAME --en-export NAME --title TITLE --save-namespace NAME --uuid UUID --target PATH')
}

if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(id)) throw new Error(`Invalid cartridge id: ${id}`)
if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(uuid)) throw new Error('UUID must be a random UUID v4')

const root = path.resolve(import.meta.dirname, '..')
const target = path.resolve(root, targetArg)
const sourceCartridge = path.join(root, 'src/story/cartridges', file)
await stat(sourceCartridge)
await mkdir(target, { recursive: true })

const existing = await readdir(target)
const unexpected = existing.filter((name) => name !== 'doc')
if (unexpected.length) throw new Error(`Target is not an empty scaffold: ${unexpected.join(', ')}`)

for (const name of ['index.html', 'package.json', 'package-lock.json', 'tsconfig.json', 'tsconfig.node.json', 'vite.config.ts', '.gitignore']) {
  await cp(path.join(root, name), path.join(target, name))
}
await cp(path.join(root, 'src'), path.join(target, 'src'), { recursive: true })
await cp(path.join(root, 'public'), path.join(target, 'public'), { recursive: true })
await mkdir(path.join(target, '_qa'), { recursive: true })
await cp(path.join(root, '_qa/exported-protocol.ts'), path.join(target, '_qa/protocol.ts'))
await cp(path.join(root, '_qa/exported-danger-director.ts'), path.join(target, '_qa/danger-director.ts'))
await cp(path.join(root, '_qa/danger-directive-grounding.ts'), path.join(target, '_qa/danger-directive-grounding.ts'))
await cp(path.join(root, '_qa/payment-consistency.ts'), path.join(target, '_qa/payment-consistency.ts'))
await cp(path.join(root, '_qa/turn-consistency.ts'), path.join(target, '_qa/turn-consistency.ts'))
await cp(path.join(root, '_qa/turn-pipeline.ts'), path.join(target, '_qa/turn-pipeline.ts'))
await cp(path.join(root, '_qa/dynamic-locations.ts'), path.join(target, '_qa/dynamic-locations.ts'))
await cp(path.join(root, '_qa/domain-thread-continuity.ts'), path.join(target, '_qa/domain-thread-continuity.ts'))
await cp(path.join(root, '_qa/recovery-choice-priority.ts'), path.join(target, '_qa/recovery-choice-priority.ts'))
await cp(path.join(root, '_qa/active-thread-continuity.ts'), path.join(target, '_qa/active-thread-continuity.ts'))
await cp(path.join(root, '_qa/recommended-choice-quality.ts'), path.join(target, '_qa/recommended-choice-quality.ts'))
await cp(path.join(root, '_qa/character-debut.ts'), path.join(target, '_qa/character-debut.ts'))
await cp(path.join(root, '_qa/perspective-director.ts'), path.join(target, '_qa/perspective-director.ts'))
await cp(path.join(root, '_qa/preset-events.ts'), path.join(target, '_qa/preset-events.ts'))
await cp(path.join(root, '_qa/v9-migration.ts'), path.join(target, '_qa/v9-migration.ts'))
await rm(path.join(target, 'public/poster.png'), { force: true })

const cartridgeDir = path.join(target, 'src/story/cartridges')
for (const name of await readdir(cartridgeDir)) {
  if (name !== file && name !== 'index.ts') await rm(path.join(cartridgeDir, name), { force: true })
}

const worldDir = path.join(target, 'src/story/img/worlds')
const cartridgeSource = await readFile(sourceCartridge, 'utf8')
const worldAssets = [...cartridgeSource.matchAll(/worlds\/([^'"`]+\.(?:webp|png|jpe?g))/gi)].map((match) => match[1])
const uniqueWorldAssets = [...new Set(worldAssets)]
if (!uniqueWorldAssets.length) throw new Error('Could not locate cartridge world assets')
for (const name of await readdir(worldDir)) if (!uniqueWorldAssets.includes(name)) await rm(path.join(worldDir, name), { force: true })

await writeFile(path.join(cartridgeDir, 'index.ts'), `import { ${zhExport}, ${enExport} } from './${path.basename(file, '.ts')}'\nimport type { Locale, StoryCartridge } from '../types'\n\nexport const DEFAULT_CARTRIDGE_ID = '${id}'\nexport const CARTRIDGES: Record<string, StoryCartridge> = { '${id}': ${zhExport} }\nexport const CARTRIDGES_EN: Record<string, StoryCartridge> = { '${id}': ${enExport} }\nexport function listCartridges(locale: Locale): StoryCartridge[] { return [locale === 'en' ? ${enExport} : ${zhExport}] }\nexport function resolveCartridge(_id: string | null | undefined, locale: Locale = 'zh'): StoryCartridge { return locale === 'en' ? ${enExport} : ${zhExport} }\n`)

const updateJsonName = async (name) => {
  const filePath = path.join(target, name)
  const json = JSON.parse(await readFile(filePath, 'utf8'))
  json.name = id
  if (json.packages?.['']) json.packages[''].name = id
  if (name === 'package.json') {
    json.scripts = {
      dev: 'vite',
      build: 'tsc && vite build',
      preview: 'vite preview',
      'test:protocol': 'node --import tsx _qa/protocol.ts',
      'test:danger': 'node --import tsx _qa/danger-director.ts',
      'test:danger-grounding': 'node --import tsx _qa/danger-directive-grounding.ts',
      'test:payment': 'node --import tsx _qa/payment-consistency.ts',
      'test:turn': 'node --import tsx _qa/turn-consistency.ts',
      'test:dynamic-locations': 'node --import tsx _qa/dynamic-locations.ts',
      'test:pipeline': 'node --import tsx _qa/turn-pipeline.ts',
      'test:domain-continuity': 'node --import tsx _qa/domain-thread-continuity.ts',
      'test:recovery-choice-priority': 'node --import tsx _qa/recovery-choice-priority.ts',
      'test:active-thread': 'node --import tsx _qa/active-thread-continuity.ts',
      'test:choice-quality': 'node --import tsx _qa/recommended-choice-quality.ts',
      'test:character-debut': 'node --import tsx _qa/character-debut.ts',
      'test:perspective-director': 'node --import tsx _qa/perspective-director.ts',
      'test:preset-events': 'node --import tsx _qa/preset-events.ts',
      'test:v9-migration': 'node --import tsx _qa/v9-migration.ts',
    }
  }
  await writeFile(filePath, `${JSON.stringify(json, null, 2)}\n`)
}
await updateJsonName('package.json')
await updateJsonName('package-lock.json')

const indexPath = path.join(target, 'index.html')
const html = (await readFile(indexPath, 'utf8'))
  .replace(/<title>.*?<\/title>/, `<title>${title}</title>`)
  .replace(/(<meta\s+name=["']game-uuid["']\s+content=["'])[^"']+(["'])/i, `$1${uuid}$2`)
  .replace(/(data-game-storage-id=["'])[^"']+(["'])/i, `$1${uuid}$2`)
if (!html.includes(`name="game-uuid" content="${uuid}"`) || !html.includes(`data-game-storage-id="${uuid}"`)) {
  throw new Error('HTML UUID/storage scope rewrite failed')
}
await writeFile(indexPath, html)

const enginePath = path.join(target, 'src/story/useStoryEngine.ts')
const engine = (await readFile(enginePath, 'utf8')).replace(/useGameSave<PersistedStoryData>\('stateful-story-template'\)/, `useGameSave<PersistedStoryData>('${saveNamespace}')`)
if (!engine.includes(`'${saveNamespace}'`)) throw new Error('Save namespace rewrite failed')
await writeFile(enginePath, engine)
await writeFile(path.join(target, 'src/game-id.ts'), `window.__GAME_UUID__ = '${uuid}'\nexport {}\n`)
await writeFile(path.join(target, 'meta.json'), `${JSON.stringify({ title, cover_url: './poster.png' }, null, 2)}\n`)

console.log(JSON.stringify({ id, title, target, saveNamespace, localStorageKey: `${saveNamespace}-save`, uuid, worldAssets: uniqueWorldAssets }, null, 2))
