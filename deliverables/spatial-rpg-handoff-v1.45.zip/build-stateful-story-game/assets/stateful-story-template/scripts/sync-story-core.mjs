import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const requestedGamesRoot = process.argv.includes('--games-root')
  ? process.argv[process.argv.indexOf('--games-root') + 1]
  : undefined
const gamesRoot = requestedGamesRoot ? resolve(requestedGamesRoot) : resolve(root, '..')

const sharedFiles = [
  'public/alteru-storage-scope.js',
  'src/alteru-storage-scope.d.ts',
  'src/shared/runtime/bridge.ts',
  'src/shared/runtime/media.ts',
  'src/shared/runtime/useGenImage.ts',
  'src/shared/save/useGameSave.ts',
  'src/story/StoryShell.tsx',
  'src/story/Icons.tsx',
  'src/story/i18n.ts',
  'src/story/story.less',
  'src/story/types.ts',
  'src/story/usePlayerProfile.ts',
  'src/story/useStoryEngine.ts',
  'src/story/engine/protocol.ts',
  'src/story/engine/authoredTurns.ts',
  'src/story/engine/characterContinuity.ts',
  'src/story/engine/choiceInput.ts',
  'src/story/engine/continuity.ts',
  'src/story/engine/dangerDirector.ts',
  'src/story/engine/domainRules.ts',
  'src/story/engine/paymentConsistency.ts',
  'src/story/engine/presetEventDirector.ts',
  'src/story/engine/readingAnchor.ts',
  'src/story/engine/turnConsistency.ts',
  'src/story/engine/turnPipeline.ts',
  'src/story/engine/reducer.ts',
  'src/story/engine/worldContext.ts',
  'src/story/engine/imageDirector.ts',
  'src/story/adapters/aigram.ts',
  'src/story/adapters/mock.ts',
  'src/story/adapters/remote.ts',
  'src/story/audio/StorySynth.ts',
  'src/story/audio/useStoryAudio.ts',
]

const requestedTarget = process.argv.includes('--target')
  ? process.argv[process.argv.indexOf('--target') + 1]
  : undefined
const preserveCartridge = process.argv.includes('--preserve-cartridge')

const targets = [
  { id: 'seventh-dock', cartridge: 'seventhDock.ts' },
  { id: 'rooftop-apartment', cartridge: 'rooftopApartment.ts' },
  { id: 'the-wild-road', cartridge: 'theWildRoad.ts' },
].filter((target) => !requestedTarget || target.id === requestedTarget)

if (requestedTarget && targets.length === 0) throw new Error(`Unknown --target: ${requestedTarget}`)

const portableScriptNames = [
  'dev', 'build', 'preview',
  'test:protocol', 'test:payment', 'test:turn', 'test:dynamic-locations', 'test:recovery-policy',
  'test:pipeline', 'test:image-director', 'test:perspective-director', 'test:preset-events',
  'test:v9-migration', 'test:state-integrity', 'test:danger', 'test:character-debut',
  'test:generated-characters', 'test:domain-continuity', 'test:recovery-choice-priority',
  'test:active-thread', 'test:choice-quality', 'test:resume', 'test:domain',
]

for (const target of targets) {
  const targetRoot = resolve(gamesRoot, target.id)
  if (!existsSync(targetRoot)) throw new Error(`Missing target: ${targetRoot}`)
  for (const relative of sharedFiles) {
    const destination = resolve(targetRoot, relative)
    mkdirSync(dirname(destination), { recursive: true })
    copyFileSync(resolve(root, relative), destination)
  }
  if (!preserveCartridge) {
    copyFileSync(
      resolve(root, 'src/story/cartridges', target.cartridge),
      resolve(targetRoot, 'src/story/cartridges', target.cartridge),
    )
  }
  const enginePath = resolve(targetRoot, 'src/story/useStoryEngine.ts')
  const engine = readFileSync(enginePath, 'utf8').replace(
    "useGameSave<PersistedStoryData>('stateful-story-template')",
    `useGameSave<PersistedStoryData>('${target.id}')`,
  )
  writeFileSync(enginePath, engine)
  const qaRoot = resolve(targetRoot, '_qa')
  mkdirSync(qaRoot, { recursive: true })
  for (const name of readdirSync(resolve(root, '_qa')).filter((entry) => entry.endsWith('.ts') || entry.endsWith('.mjs'))) {
    copyFileSync(resolve(root, '_qa', name), resolve(qaRoot, name))
  }
  // The mother template validates several cartridges together. A synced game
  // contains only one cartridge, so its protocol/danger suites must use the
  // standalone fixtures that the exporter also ships.
  copyFileSync(resolve(root, '_qa/exported-protocol.ts'), resolve(qaRoot, 'protocol.ts'))
  copyFileSync(resolve(root, '_qa/exported-danger-director.ts'), resolve(qaRoot, 'danger-director.ts'))
  const sourcePackage = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'))
  const targetPackagePath = resolve(targetRoot, 'package.json')
  const targetPackage = JSON.parse(readFileSync(targetPackagePath, 'utf8'))
  const portableScripts = Object.fromEntries(portableScriptNames.map((name) => [name, sourcePackage.scripts[name]]).filter((entry) => Boolean(entry[1])))
  const targetSpecificScripts = Object.fromEntries(Object.entries(targetPackage.scripts).filter(([name]) => name === 'test:wild-road-world' || name === 'test:world-director' || name === 'test:domain'))
  targetPackage.scripts = { ...portableScripts, ...targetSpecificScripts }
  targetPackage.dependencies = { ...targetPackage.dependencies, ...sourcePackage.dependencies }
  targetPackage.devDependencies = { ...targetPackage.devDependencies, ...sourcePackage.devDependencies }
  writeFileSync(targetPackagePath, `${JSON.stringify(targetPackage, null, 2)}\n`)
  console.log(`synced ${target.id}`)
}
