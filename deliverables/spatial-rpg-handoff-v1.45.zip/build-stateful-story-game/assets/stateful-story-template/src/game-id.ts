// Bundled authoring-engine UUID only. scaffold.mjs generates a new UUID v4
// for every exported standalone game and rewrites this file in the output.
(window as any).__GAME_UUID__ = '6375516d-0361-41ed-b086-176bbad05b46'
