import { seventhDock, seventhDockEn } from './seventhDock'
import { rooftopApartment, rooftopApartmentEn } from './rooftopApartment'
import { theWildRoad, theWildRoadEn } from './theWildRoad'
import { cityOfTides, cityOfTidesEn } from './cityOfTides'
import type { CartridgeId, Locale, StoryCartridge } from '../types'

export const DEFAULT_CARTRIDGE_ID = 'seventh-dock'
export const CARTRIDGES: Record<CartridgeId, StoryCartridge> = { 'seventh-dock': seventhDock, 'rooftop-apartment': rooftopApartment, 'the-wild-road': theWildRoad, 'city-of-tides': cityOfTides }
export const CARTRIDGES_EN: Record<CartridgeId, StoryCartridge> = { 'seventh-dock': seventhDockEn, 'rooftop-apartment': rooftopApartmentEn, 'the-wild-road': theWildRoadEn, 'city-of-tides': cityOfTidesEn }
export function listCartridges(locale: Locale): StoryCartridge[] { return Object.values(locale === 'en' ? CARTRIDGES_EN : CARTRIDGES) }
export function resolveCartridge(id: string | null | undefined, locale: Locale = 'zh') {
  const collection = locale === 'en' ? CARTRIDGES_EN : CARTRIDGES
  return (id && collection[id]) || collection[DEFAULT_CARTRIDGE_ID]
}
