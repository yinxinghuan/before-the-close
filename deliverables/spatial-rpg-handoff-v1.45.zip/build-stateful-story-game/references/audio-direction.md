# RPG audio direction and delivery

Read this reference whenever a new or revised RPG uses generated music, ambience, Foley, or a hybrid recorded/Web Audio mix.

## Product contract

Sound supports place, pressure and consequence without becoming a second narrator. Long-form reading uses an explicit **A/B score hierarchy** and plans five layers separately:

1. **A — reading/region bed**: the ordinary score. It is world- and region-specific but extremely sparse: no foreground melody, beat, pulse, ostinato, dramatic build or dense harmony. Use one to three texture families, long rests and a natural ending so prose remains primary. Mastering normally starts near `-29 LUFS / -6 dBTP`.
2. **B — feature score**: a somewhat fuller musical statement reserved for a major reveal, relationship turn, chapter summary or similarly durable consequence. It temporarily pauses A, plays once, then returns to A. It is never selected randomly and never attached to routine success, button taps, checks or ordinary travel. Mastering normally starts near `-25 LUFS / -4 dBTP`, and runtime cooldown is at least three minutes.
3. **Ambience**: a quiet default world bed, optionally overridden by stable `location_id` for places that sound materially different. Every ambience recording plays once per location visit, then yields to silence; it may play once again only after a genuine location change.
4. **Signature event sounds**: reviewed files only for world events whose texture matters more than exact frame timing, such as a train arrival or a ritual seal. One committed event produces at most one play.
5. **Deterministic feedback**: buttons, checks, stat changes, currency, errors and other immediate UI/gameplay responses remain Web Audio or reviewed short local samples. Every cue is a one-shot transient and never loops.

The reading foreground has a strict cue budget. An ordinary choice gets one quiet acknowledgement and no automatic sound merely because prose arrived, a routine energy/standing value changed, or a generated image finished loading. A second cue in the same turn is reserved for a genuinely distinct durable consequence: a resolved check, currency transaction, rare item, relationship/party turn, danger transition, chapter summary or authoritative location arrival. Each event sound plays once; a reconnect, rerender, save restore, mute toggle or page resume must not replay it. Do not use sound to restate every visible feedback card.

Generated audio must never gate a turn, state commit, save, shared-world transaction or image. Silence and the synthesized layer are valid fallbacks.

## Authoring workflow

When `$alteru-media-service` is installed, read its audio and QA references and use its durable-asset helper. Use the game's permanent UUID as `session_id`; never mint a request namespace per file. Write prompts in English and never call provider/model endpoints directly.

- A prompt: state that this is a reading-first regional bed; demand extremely low density, long silence, no foreground melody, percussion, pulse, ostinato, crescendo or vocals.
- B prompt: state the exact durable story event it accompanies; allow a clearer motif or harmonic movement, but keep speech-free and leave room for prose.
- Ambience/SFX prompt: one environment or event, concrete sources/materials, microphone perspective, tail, and explicit exclusions such as `no music` and `no voice`.
- Generate at least two candidates for title music, signature events, or a first candidate that fails listening. One reviewed candidate is sufficient for ordinary ambience.
- Download accepted assets into `src/story/audio/assets/` (or the project's equivalent). Runtime CDN URLs are not source assets.

Before integration, listen to the complete file. Then verify decoded duration, MP3, 44.1 kHz, stereo, clipping/true peak, integrated loudness, leading/trailing silence, natural ending, repeated-play seam and mobile playback. Suggested conservative mastering starting points are about `-29 LUFS / -6 dBTP` for A, `-25 LUFS / -4 dBTP` for B, `-32 LUFS / -4 dBTP` for ambience and `-20 LUFS / -2 dBTP` for a signature event; the actual in-game mix remains authoritative. A beautiful standalone track that feels “full” beneath continuous reading fails the product contract even if it passes mechanical audio checks.

## Cartridge and engine boundary

The Cartridge may declare:

```ts
audioTheme: {
  material: 'wayfarer',
  bpm: 64,
  rootHz: 146.83,
  scale: [0, 2, 5, 7, 9],
  levels: { music: .08, ambient: .12, sfx: .045, master: .6 },
  tension: [{ statId: 'energy', direction: 'low', weight: 1 }],
  recorded: {
    music: { src: themeUrl, gain: .2 },
    ambience: { src: worldAmbienceUrl, gain: .3 },
    ambienceByLocationId: {
      harbor: { src: harborAmbienceUrl, gain: .32 },
    },
    cues: {
      travel: { src: arrivalUrl, gain: .12, role: 'effect' },
      discovery: { src: featureUrl, gain: .18, role: 'feature', cooldownMs: 180_000 },
      relationship: { src: featureUrl, gain: .18, role: 'feature', cooldownMs: 180_000 },
      summary: { src: featureUrl, gain: .18, role: 'feature', cooldownMs: 180_000 },
    },
  },
}
```

`ambienceByLocationId` overrides `ambience`; an unknown or dynamically created place falls back to the default environment bed. Do not key audio by translated display labels. Keep gains between `0` and `1` and conservative because the engine multiplies track gain by the master level.

The engine owns playback, voice caps, gesture unlock, pause/resume, mute persistence, page visibility and fallback. It never sets `loop=true` on generated files or claims they are seamless. A may return only after its natural ending and at least thirty seconds of silence. Ambience plays once per location visit and remains silent after ending; mute/page hide pauses it in place, resume continues an unfinished play, and neither action restarts a completed track. A genuine location change resets the one-play allowance even when two locations share the same asset. A successful recorded bed stops its equivalent synthesized bed; a rejected or failed play restores the synthesized fallback. When B starts, the engine pauses A but leaves an unfinished ambience play running; when B ends, A resumes. One B may play at a time, shared B assets are deduplicated by source cooldown, and mute/page hide cancels B instead of replaying it later. Exact cues remain synthesized unless the Cartridge explicitly supplies a reviewed replacement.

The frozen engine sets the Cartridge SFX bus no higher than `0.045`, then attenuates it by an additional `0.52` reading-mode scale. Recorded ordinary/effect tracks stay at or below `0.12`. It accepts at most two simultaneous recorded effect voices, caps synthesized transient voices at six, and suppresses cue bursts closer than `180 ms`. These are engine safety limits, not targets to work around by raising Cartridge gains. Routine cues should use one material gesture; only rare/critical cues may use a restrained two-layer gesture.

## Asynchronous shared worlds

Audio is presentation state, never shared authority. Shared events may expose a stable semantic cue such as `project-complete`, but each client decides whether and when to play it after the authoritative commit. Reconnect/replay must not replay old celebration sounds in bulk. Deduplicate by committed event id, respect local mute/background state, and never put generated audio URLs, prompts or listening history into public world events or private relationship saves.

## QA and handoff

At minimum verify:

- no `AudioContext` or audible HTML media starts before a user gesture;
- unmute causes one start, not duplicate `play()` calls;
- mute, page hide, page show, location change and unmount cleanly pause/resume or dispose tracks and timers;
- every ambience recording plays exactly once during one location visit; completion followed by unmute/page resume does not restart it, while a genuine later visit permits exactly one fresh play;
- every short recorded or synthesized event cue is one-shot and cannot be replayed by rerender, restore, reconnect or acknowledgement retry;
- missing/404/autoplay-rejected files leave play usable and activate synth/silence fallback;
- a stable location override wins and an unknown/dynamic location uses default ambience;
- transient recorded cues respect the voice cap and fall back when playback rejects;
- A never overlaps B; B returns to A after ending, is suppressed while active, and cannot retrigger for at least `180_000 ms`;
- routine turns never select B merely to add variety; trigger semantics correspond to a durable reveal, relationship turn or chapter boundary;
- a routine prose-only turn produces no result cue; routine energy/standing changes and image completion are silent;
- one ordinary action produces one quiet acknowledgement, while only a separately meaningful consequence may add one later semantic cue;
- the engine retains the `0.52` SFX attenuation, `180 ms` burst guard, six synthesized transient cap and two recorded-effect voice cap;
- every bundled Cartridge keeps synthesized SFX at or below `0.045` and recorded ordinary/effect gains at or below `0.12`;
- build output contains relative hashed audio assets; no provider host, credential or private deployment code ships;
- complete listening status is recorded separately from mechanical QA. Do not call an asset perceptually approved when no human listened to it.

The colleague handoff package contains the engine contract, tests and authoring instructions. It deliberately contains no internal deployment workflow, private media Worker code, credentials, provider URLs, game catalog mutation or internal testing entry.
