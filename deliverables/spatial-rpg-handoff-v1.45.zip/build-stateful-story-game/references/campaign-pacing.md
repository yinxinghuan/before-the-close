# Campaign progression and premature endings

Use when designing a finite multi-session RPG or investigating a game that ends too quickly. This is an authoring and acceptance contract, not a verified runtime for arbitrary generated chapters. Deliberately short stories and open-ended worlds keep their requested shape.

## Diagnose before adding length

Trace the actual shortest legal route from initial state to each terminal result. Compare the advertised experience with substantive decisions and consequences on that route, not UI pages, movement clicks, API calls or generated word count. Record elapsed play time separately from generation/download waits. One fast trace can reveal a shortcut; it cannot establish average player duration.

Check ending prerequisites, default/empty requirements, alternate ending paths, chapter/checkpoint semantics, resource failure endings and whether almost all content is optional. A rules engine may make a thin authored route more apparent; do not assert that Prolog caused compression without comparing the affected game's old/new definitions and committed traces. Keep interface adoption, rules-service migration and story redesign separate.

## Design substantive progression

In requirements, describe the intended session/campaign scope and a dependency graph of meaningful milestones. For each milestone record:

- what the player discovers, chooses or resolves;
- the authoritative evidence of completion and feasible alternative solutions;
- what new decisions it makes available;
- whether it is mainline, optional or an intentional early exit.

Do not assign a universal chapter/turn quota. A short errand, ordinary dialogue or acquiring the first clue must not accidentally satisfy the whole campaign. Preserve clever alternative solutions; avoid compulsory sidequest completion, repeated travel, filler dialogue or forced media waits merely to meet a duration target.

Distinguish a resumable checkpoint, completed local objective/chapter, voluntary departure/failure and true campaign resolution. Early departure may have its own honest outcome; it must not claim the unresolved main conflict was settled. Open-ended games need not acquire a final ending at all.

Ending eligibility reads committed milestone facts and actual resolving conditions, not prose saying “the end” or a scene counter alone. Facts used as gates need validated writers: the model cannot set all milestones simply by asserting them. Check every terminal path, including deterministic fallback and resource-failure paths. A final player commitment is appropriate when departure or an irreversible choice is part of the fiction; do not require a generic confirmation for every genre.

## Fixed framework with generated episodes

When variety serves the product, fix the core promise, causal milestones and outcome constraints while leaving selected intermediate encounters, investigations or rooms to generation. Each slot needs entry conditions, relevant existing facts, available entities/resources, permitted consequences, completion criteria, and a viable next step. Variation should change a problem, choice, clue relationship or solution, rather than only names and decoration.

Treat a generated episode as a proposed content instance. Validate and admit it before its state-changing actions become playable. Reuse the chosen engine's supported schemas; do not invent runtime rule-registration APIs or execute arbitrary model-authored Prolog. If the backend cannot admit new entities/actions per journey, identify that gap. Choosing among pre-authored variants is a useful fallback, but is not evidence of real-time generated gameplay.

Persist the accepted instance, stable entity IDs, dependency links, generation status and media references with its journey/version. A random seed alone is not enough to reproduce a model response. Reload resumes that instance; a new journey may receive a different one. Do not silently regenerate a solved puzzle or retroactively add new prerequisites to an old/completed save.

Prepare the next likely episode during current play when possible. In text/cinematic modes, valid narrative can continue while nonessential illustration loads. In spatial mode, require admitted layout, exits, collision, interactable states and necessary clues before entry; atmosphere may arrive later without moving obstacles or changing the solution. A puzzle that requires an image must wait for that image or offer an authored equivalent route. Generation failure must not grant a milestone or imply completion.

## Focused acceptance

- Replay the shortest plausible completion route and one representative exploratory/alternative route. Explain major deviations from the intended scope rather than repeating every route.
- Before a required causal milestone, attempt the final action: it cannot produce a successful full resolution. After a legitimate alternate solution, it can; optional content is not covertly compulsory.
- Verify a checkpoint resumes play and generated narration cannot independently complete the campaign.
- For a runtime-generation claim, play at least two genuinely generated journeys with materially different intermediate decisions. A test fixture or renamed room is insufficient. Test reload of one accepted instance and one slow/failed generation boundary.
- Record rules correctness, actual generated content, pacing observations and player comprehension separately. A green rules suite proves neither sufficient content nor an enjoyable duration.

Do not report these proposed dynamic-episode contracts as an implemented generic engine until a real product has demonstrated them. When exporting a skill kit, include this reference; changing authoring instructions does not repair existing deployed games or previously distributed archives.
