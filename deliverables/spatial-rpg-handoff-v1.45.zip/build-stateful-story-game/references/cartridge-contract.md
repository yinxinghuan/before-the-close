# StoryCartridge contract

The canonical TypeScript source of truth is `stateful-story-template/src/story/types.ts`. Inspect it before authoring because this reference describes intent, not a substitute schema.

## Stable engine boundary

Keep these in the shared engine:

- adapter selection, authentication, prompt assembly, and history window;
- protocol parsing and unknown-command rejection;
- stat clamping, state reduction, save migration, restart, and deterministic danger resolution;
- Aigram/local save mirroring and per-game UUID resolution;
- timeline scroll anchors, image queue, retry, and inventory pre-generation;
- player profile lookup, avatar fallback, language detection, and Web Audio runtime.

Put these in the Cartridge:

- title, promise, opening, objective, characters, places, items, and demo turns;
- three stat definitions and their risk semantics;
- fixed world rules, AI generation rules, three choice intents, and thread cap;
- one localised, world-native `transitionAnchor` used by the reducer before location changes;
- danger cadence, escalation stats, threat palette, response methods, combat boundary, DCs, and fallback costs;
- deterministic domain rules for scarce resources, gates, route commitments, charged items and other exact transactions;
- theme tokens, entry/cover art, scene and item art direction;
- image trigger cadence and audio theme.

If a topic requires a fourth permanent stat, first determine whether it is an inventory quantity, relationship event, item metric, or temporary scene fact. Do not widen the Shell casually.

## Paired-language invariants

Create one `zh` and one `en` export in the same file. Both must share:

- `schemaVersion`, Cartridge `id`, asset URLs, material, and director mode;
- stat ids and order;
- character, map, and inventory ids;
- choice intent meaning and world-rule meaning.

Display names and prose are translated. Never compare gameplay state by translated display text when an id exists.

## Opening

Provide:

- a specific location, clock, and immediate objective;
- 2–4 concise visible blocks that make the first decision understandable;
- one to five grounded choices representing the intents that genuinely exist; three may be an authored default but is never a quota;
- a scene prompt showing the location/conflict, with no UI or readable text.

Treat opening information as progressive disclosure, not a synopsis. The first visible screen should normally establish one ordinary activity, one disruption and one immediately legible human response. Do not front-load route names, historical explanations, world systems, several clues and multiple future objectives before the player acts. Each authored opening action should normally reveal one new fact chain and end in choices that operate on visible people or objects; introduce additional routes and lore only when they become usable.

The first screen scrolls to readable background, not to an empty image placeholder.

## Stats

Define exactly three `StatDefinition` entries. Each needs unique id, label, min, max, initial, display, warning/danger thresholds, `maxDelta`, and a concise bilingual `description` that tells the player what the stat represents, how it changes or recovers, and what its important thresholds actually do.

If reaching a stat floor must restrict play, define `floorRule` on that stat. Its entered/blocked text and recovery choices must be world-native and bilingual; `allowedDomainRuleIds` must point only to deterministic recovery transactions. The engine then blocks free input and stale saved choices at the floor, replaces the tray in the same turn, and repeats the gate after reload. Every displayed recovery choice must map to an executable local rule; never rely on the model to decide whether a floor has consequences.

- Use `bar` for continuous pressure or reputation.
- Use `number` for countable supplies, money, days, or charges.
- `inverse` controls which direction is dangerous; it never reverses bar fill.
- The reducer clamps absolute ranges and per-turn changes. AI text cannot bypass it.

## Domain rules

Read [domain-rules.md](domain-rules.md) when the game has exact persistent mechanics. Put rule declarations in the Cartridge and adjudication in the shared engine. A matched rule owns the whole turn's persistent transaction; the model only narrates and returns choices. Invalid actions apply no partial effects and must return the actual unmet requirement plus however many currently feasible actions exist. Charged rooms, tickets, meals and other known purchases should be domain rules so consent, affordability, deduction and acquired state commit atomically; their match phrases must include natural explicit payment wording but exclude mere inquiry or consideration.

Keep free-form actions open by returning no domain resolution when no rule matches. Do not convert the whole game into a rigid command parser.

## Director

`fixedWorldRules` preserve identity, geography, ownership, scarcity, knowledge, and confirmed consequences. `generationRules` state what AI may invent and what each turn must advance.

For open worlds, require at least one trackable fact change per turn and allow the player to reject suggested routes. For guided worlds, keep multiple methods and consequences even when the objective is fixed.

`choiceIntents` are semantic diversity requirements, not button labels. The model should return concrete choices based on the scene. `maxActiveThreads` should normally be 3.

## Danger director

Every paired Cartridge defines the same `dangerDirector` meaning in both languages:

- `minSafeTurns <= maxSafeTurns`, normally 2–5 ordinary turns;
- at least four world-specific threats, not generic “an enemy appears” placeholders;
- put location-bound threats in `threatLocations` as `threat text -> allowed map node ids`; leave only genuinely global threats unscoped, and ensure each map node has at least one compatible candidate;
- exactly three response methods, each already phrased as one short, concrete,
  immediately executable player action because the engine may render it
  verbatim; do not use abstract taxonomies or comma/slash/`or` lists;
- when a released game renames these buttons, retain the former bilingual
  triples in `legacyMethods` so only still-actionable saved choices migrate;
- `physicalCombat: none`, `rare`, or `allowed` according to the fantasy;
- five increasing severity DCs, a bounded modifier, and at least one fallback stat cost;
- a cooldown long enough to prevent back-to-back compulsory crises.

The engine advances warning → confrontation → resolution and hashes game id, scene, encounter cycle, and action into one stable d20. Do not ask AI to invent or reroll this check. Failed or costly outcomes must change a persisted stat, owned item, route, or character condition.

## Entities and lore

- Characters: role, vitality/stress or equivalent, skills, current detail, and lore. Set `hiddenUntilIntroduced: true` for authored characters first met after the opening; this is not the same as `initialStatus: known`.
- Map nodes: connection/current/visited plus detail, lore, and known facts.
- Inventory: count, rarity, detail, effect and limitation, lore/provenance, visible metrics, and object-only image prompt.

When AI adds a rare item, visible prose must first explain its capability, limitation/cost, and source. Item images must say object only, no people, no text, square, and inherit `itemImageDirection`.

Characters introduced later merge into the stable registry. Their first visible beat must establish recognisable form/action, the ordinary source of their name, and current intent before any choice uses that name. The same response emits `character_update`; `party_change add` is allowed only when visible prose also establishes joining. Party membership changes only through explicit join/leave facts. Never reconstruct companions from a narrow prose window or replace the entire party with the newest group.

## Images and sound

- `entryImage`: native landscape scene for the first screen.
- `coverImage`: square style/world reference and placeholder source.
- `sceneImageDirection`: consistent scene composition and material.
- `imageDirector`: AI proposals first; local guaranteed/soft/quiet-turn triggers as fallback.
- `imageDirector.perspective`: optional camera policy. Missing/`observer` preserves legacy third-person behavior; `balanced` keeps suitable ordinary decisions within a mechanically tested 40–60% first-person share; `first-person-preferred` uses roughly 75%. Override important dialogue and new-location establishing shots independently.
- `presetEventDirector`: optional authored local-event pool. Each event binds to one stable map node, supplies concrete prose/objective/1–5 follow-ups and an event image, and may appear only when no objective, reply context, open job or danger thread would be interrupted.
- `audioTheme`: material, BPM, root, scale, bus levels, stat-driven tension, and optional durable recorded music/ambience/event tracks. Read [audio-direction.md](audio-direction.md) before adding recorded assets. A default `recorded.ambience` covers dynamic/unknown places; stable `ambienceByLocationId` entries override it by id. The engine plays every ambience recording once per location visit and every short cue once per committed event; Cartridge authors must not add loop flags or recovery-time replay logic.

Do not put Chinese or any required readable text into runtime image prompts. Formal posters are English-only and are not reused as the landscape entry image.

Scene prompts begin from the current event, location, visible participants, and action. The opening/cover prompt is a style reference only; never copy its landmark or composition into unrelated later scenes. `image_subject` controls who owns the avatar reference: use `player` only when the protagonist is the dominant visible actor performing the main action. A player-owned renderer prompt must call that actor `SUBJECT A` and omit gender, age, species, anatomy, face/hair, role-shaped wardrobe, and period clothing; the reference image alone owns appearance. Use `others` for companion/NPC-led shots even if the player is incidental or in the background, and `environment` for empty/object-only shots.

First-person and avatar ownership are mutually exclusive. In a first-person player-eye shot, keep the protagonist entirely out of frame and do not send `ref_url`; show their hands only when the current visible prose explicitly establishes them. In observer/third-person shots, send the avatar only when the protagonist is the dominant visible actor. For `balanced`, measure both engine decisions and authored preset-event prompts; proving that a third-person code branch exists is not sufficient.

## Endings and restart

`session_end` is a chapter checkpoint by default. It does not lock the composer or delete history. A true ending requires an explicit product decision and migratable state. The World/System view must offer a confirmed restart that affects only the current game.
