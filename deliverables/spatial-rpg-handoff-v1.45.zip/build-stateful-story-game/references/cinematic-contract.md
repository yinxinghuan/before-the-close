# Cinematic Civic contract

Read this after selecting `cinematic` and inspect the bundled `src/story/types.ts`, `doc/visual.md`, and `doc/technical.md` before authoring.

## Player-lived opening

The opening is the player's first scene, not a recap card. Author 4–7 short chronological `opening.blocks` that the player directly sees, hears or does:

1. establish the player's ordinary arrival or immediate intention;
2. let the disruption happen on screen;
3. reveal one concrete clue, voice or physical consequence at a time;
4. introduce a named character only after a visible form/action, then give the everyday source of the name and current intent;
5. end on one immediate conflict that the opening choices genuinely answer.

During scene 0, paginate these authored blocks in one direction. Hide quick replies, free input and numeric choice shortcuts until the last beat. On the last beat the page control disappears and choices enter; never loop back to page one. Keep the same opening image as a visual situation plate unless the authored design explicitly budgets multiple opening images.

Do not compress arrival, disaster, cast, rules, inventory and objective into one “previously / background” paragraph. Do not use “please choose”, “what will you do next”, an objective label or protocol metadata as a beat. Each page must add a perceivable fact and preserve causality.

## Turn sequence

The visible state machine is:

```text
decision -> resolving -> result -> decision
```

- `decision`: show the current decision premise and actionable choices.
- `resolving`: show immediate submission feedback and image development; hide stale choices.
- `result`: show what the chosen action caused; hide the next premise and choices.
- Advancing from the result reveals the new premise and choices together.

Never show the previous action result, the next decision premise, and all choices as one undifferentiated stack.

## Image-per-step promise

- Every successful step produces exactly one new scene-image decision.
- Define `imageDirector.maxQuietTurns: 1`, `softCooldownTurns: 0`, and an empty soft-trigger list.
- Use a 4:5 `mediaDirector.imageTarget`, normally `512x640`, with `imageProfile: fast-small`.
- Build prompts from the current action, result, location, and visible cast before adding art direction.
- Opening/cover composition is a style reference, never a reusable scene composition.

## Identity ownership

`image_subject` assigns the avatar reference to a shot; it does not list everyone who may appear.

- `player`: the protagonist is the dominant visible actor and performs the main depicted action.
- `others`: a companion or NPC owns the action, including shots where the player is incidental or in the background.
- `environment`: no identity reference, including object-only shots.

Every player-referenced prompt needs a short, front-loaded full-identity map. The reference owns the player's entire visible form—face when present, silhouette, species/form, body proportions, material, covering, mask, costume, colors, patterns, and accessories. It is not a face-only token. Never reveal or invent body parts absent from the reference, and never transfer any reference trait to companions, background figures, reflections, masks, or animals. Avoid dense group shots when identity must be legible.

Use the original public HTTPS avatar URL directly as an edit reference. Do not crop, rasterize, or re-upload it merely to match the 4:5 scene target: requested output dimensions belong to the generated scene, not to the identity input. In renderer prompts, call the player `SUBJECT A`; describe action and props but never assign gender, age, species, face, hair, anatomy, a profession-shaped outfit, or period clothing. External pages use the 10.5-second live-profile window; confirmed platform sessions keep retrying until the 30.5-second hard fallback. Item and environment media may continue while identity is unresolved. Legacy ready images in the first two scene slots may be regenerated once when identity-reference version 2 is stale.

## Text and choices

- One visual caption should fit about 30 Chinese characters or 65 English characters.
- Runtime pagination must preserve the rest; never end meaningful text with an unrecoverable ellipsis.
- A speaker caption includes a stable speaker identity plate and full name.
- The stage caption is conditional, not a permanent choice banner. Render it only for new situation context, consequence or character speech. Hide protocol residue and generic meta-copy such as “please choose” or “what will you do next”; the visible choices already carry that instruction.
- Use the neutral current-moment label for narration. Do not repeat a choice invitation above the choice controls.
- The three choices describe the same immediate situation as the decision premise.
- Choice buttons are horizontally scrollable on mobile, visibly enabled, and submit with one click.
- Scene-0 choices and free input remain absent until the final player-lived opening beat; keyboard shortcuts follow the same gate.

## Danger authority

- Location-bound threats use `dangerDirector.threatLocations`; the selector cannot schedule a threat outside its allowed map nodes.
- A scheduled danger becomes authoritative only when the visible result names the same threat and the response emits the exact phase/kind `encounter` tag. A hidden or mismatched directive is discarded by the reducer and cannot change danger state, fabricate a danger check, mark a danger milestone, or replace the current choices.
- Warning and confrontation choices name the concrete threat or repeat an identifying phrase from it. This keeps the next decision attached to the result instead of switching to an unrelated crisis.
- Run `npm run test:danger-grounding` alongside the ordinary danger cadence test before handoff.

## Endings

Apply [campaign pacing](campaign-pacing.md): subtitle pages and image steps are presentation, not completed story milestones. Check the shortest legal ending route against the intended campaign, and keep checkpoint completion separate from full resolution.

Author a campaign with a recognisable opening, escalation, reversal/low point, climax, and aftermath. Fixed ending anchors define compatibility constraints; the language model may generate varied epilogues inside those constraints. A chapter boundary is resumable. A true ending freezes the relevant state and still offers an explicit restart.

## Civic and Living branches

Use `?ui=civic` for Modern Civic System and the default URL for Living Storyboard while evaluating. Pick one default before release unless the product intentionally exposes the choice. Both branches must share engine state and pass the same action/result ordering, text pagination, choice availability, responsive, and identity tests.
