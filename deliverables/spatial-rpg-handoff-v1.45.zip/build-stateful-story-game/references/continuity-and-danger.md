# Continuity, inventory, choices, and danger

Use these checks when authoring or diagnosing a Cartridge. The engine is deterministic; prose alone cannot repair missing state.

## Character continuity

- Give every recurring character a stable id independent of translated names.
- Merge newly observed facts into the registry. Never replace the whole character array with the latest cast.
- Keep party membership as stable ids. Join/leave requires an explicit command or confirmed engine event.
- Send the full current party, bounded known-character registry, relationship facts, objective, location, and recent events to AI each turn.
- Store relationship changes with a source event so the detail view can explain why a value changed.

## Character debut integrity

- Treat the authored cast as possibility, not player knowledge. A fixed character whose first meeting happens later uses `hiddenUntilIntroduced: true` and is absent from the initial `StorySave`.
- A visible debut follows: recognisable form or action → ordinary source of the name → current intent/relationship → interaction. Protocol tags, metadata, image prompts, drawer lore, and hidden summaries do not count as visible prose.
- Do not put an unmet name in dialogue speaker labels, objectives, relationship events, party state, or choices. The response that visibly introduces the character may then emit `character_update`; emit `party_change add` only when the same visible response establishes that they join.
- Reuse the authored stable `character_id` when creating the revealed character. Do not create a second generated NPC because translated names differ.
- A generated recurring character needs a new stable `character_id` and explicit visual appearance/immutable traits in the same valid debut. Once persisted, the id↔name binding is immutable: later turns may add role, lore or state, but cannot rename that id or attach the same established name to another id.
- `party_change` and relationship commands may bind known characters only. A join command is accepted only when visible prose in that response establishes that the character agrees or begins to travel with the player. Protocol-only people never enter the roster.
- Save migration may discard a hidden character incorrectly preloaded by an old engine only when it has no visible mention, party/departed status, relationship event, or post-opening update. Preserve every genuinely introduced character.
- Mechanically test initial absence, visible introduction before the first named choice, stable-id creation after introduction, and safe repair of a legacy preloaded save.
- For generated characters also test protocol-only rejection, missing visual identity rejection, id rename/name collision rejection, party/relationship binding, JSON reload and later-turn reuse.

## Inventory transactions

- “Found” or “saw” is not ownership.
- Add an item only after explicit take/receive/buy/craft/claim language or a validated structured command.
- Deduplicate by command/event id. Retry must not double quantity.
- Remove, transfer, consume, or break items through validated commands and receipts.
- Render the bag from persisted inventory only. Each object includes effect, limit/cost, provenance, rarity, metrics, quantity, and image state.

## Choice integrity

- Return one to five concrete, materially different actions according to what the current state actually permits. Three is a common authored default, not a quota; never invent filler to reach it or discard a valid fourth/fifth action to preserve it.
- Reject generated placeholder labels that do not commit to a concrete entity or next step, including generic observation, waiting, “discuss what to do,” “continue the current task,” “try another way,” and equivalent translations. Also reject the just-completed action and retry-prefixed paraphrases. Free input may still deliberately retry after a visible failure.
- Visible prose and `[choices]` must refer to the same immediate situation.
- Treat noun visibility as an engine invariant: every person, place, object, institution, and immediate goal named by a choice must appear in visible response text or authoritative known state. Remove failing choices individually before render and preserve the grounded subset. When a calm cinematic turn has no grounded choice, leave quick replies empty and keep free input instead of fabricating a generic fixed-point menu; active danger may recover only threat-bound deterministic actions.
- Accumulated-reading mode normally shows no `decisionContext`: the visible narration already explains the choices. Only when every choice shares a premise that its label cannot express may generation emit one explicit `[situation]` paraphrase (maximum 28 Chinese or 96 English characters). Reject copied prose, broad objectives, protocol residue, “please choose,” and “what will you do?”; migrate old auto-truncated contexts to empty.
- The model never prints a visible status-update report. Numeric changes arrive only through validated `[widget]` commands. Render the authoritative delta near its narrative cause, then animate only the changed HUD value once; absolute values remain in the HUD. Reduced-motion mode keeps static emphasis and removes displacement/scale.
- Recover trustworthy numbered or bulleted choices when the structured tag is lost.
- If no trustworthy alternatives exist, show free input rather than inventing “continue this journey.”
- Never let image generation, streaming completion, or a parse failure clear the last usable choices.
- Pass payment, exact-scene, objective, image and choice checks through one pre-reducer turn pipeline. Give every authored map node localized `routeHints` that cover the concrete sublocation nouns players and prose actually use. Give every generated place a stable `location_id`; validate and persist only visible aliases/sublocations, bind resolvable displayed choices to that id, and reject alias collisions or id/label conflicts instead of guessing. An explicit player action such as “I decide to call this place …” may add one alias without model metadata because the action itself is visible authority. Semantic arrival requires a movement/commitment cue plus one uniquely matched non-current node; dialogue that merely mentions a remote place must not teleport. A displayed cross-location choice is an execution contract: after one failed repair, complete only its locally certain destination transition and derive grounded exits there. When an ordinary displayed recommendation cannot reliably commit, preserve location/objective/stats/items/time, remove that action, and keep only still-trustworthy siblings. If none remain, leave quick replies empty and retain free input; never create “see what is possible / abandon the plan” buttons or reuse the objective as an executable action. A reply-only failure is different: commit the already-valid consequence and derive from authoritative state. In active danger discard older siblings and generate only threat-bound confirm/respond/withdraw buttons whose labels name the exact current threat. Never inject generic companion discussion, repeat the action that just completed, recommend a semantic same-object retry without authoritative progress, or introduce a new entity merely to fill the tray. Deterministic authored labels must declare and obey location/character/job scope.
- Migrate old nested recovery saves by walking back through recovery scenes to the earliest non-synthetic player action for audit. Keep that failed action quarantined from the executable tray unless a later deterministic contract proves it valid; recover trustworthy siblings from the preceding immutable choice record, remove old synthetic menus, and support factless legacy saves. Rewrite live and stored choices idempotently and without padding.
- Apply deterministic scope and semantic-retry filtering to generated recommendations. A trusted authored turn's own follow-ups are exempt from pre-turn scope and semantic-repeat filtering because the same visible turn may establish the character, job or fact they require.
- Persist the visible choice set beside each scene as an immutable choice record. Save migration must repair both the live tray and historical record for legacy generic recoveries, and a second migration pass must make no changes.

## Payment integrity

- Treat localized exact coin nouns (including 钱币、铜板、铜币、硬币、coins and coppers) as the same authoritative resource.
- When visible prose proves an exact completed transfer and the model omits machine metadata, deterministically add the matching settlement or coin delta. Do not guess vague amounts.
- A future promise may create an exact persisted job offer but cannot credit coin. A completed job settles once, and its settlement cannot stack with a positive coin widget.
- A completed spend requires explicit authorization in the current player action. “Ask the room rate”, “look for lodging”, “consider another route” and equivalent exploratory actions may reveal a price but may not book, buy, pay, tip or donate. Reject both invented spend prose and hidden negative coin commands.
- A budget-only action such as “把钱全部花完 / spend all my money” has no purchase object and is not authorization. Ask what to buy, do not invoke a transaction, and keep the balance unchanged. Use an exact local domain rule when the product needs a deterministic clarification.
- Detect direction from the visible transfer, not from the model command: phrases such as “你用这枚硬币支付” are purchases, and a purchase can never become a positive coin delta. Singular demonstratives such as 这枚 / that one coin count as an exact amount of one.

## Location and chapter transitions

- Store the route/map node in `location` and the exact current sublocation in `sceneLocation`. A workshop may belong to the current city without being renamed back to the city. `routeHints` may establish that “east-row trellis” belongs to a vineyard map node while preserving that exact scene string. Bind event images to the exact scene, not merely the parent map node; old saves missing `sceneLocation` fall back to `location`, and old map nodes inherit missing route hints from the active Cartridge definition.
- A generated `map_update` uses `location_id="stable-kebab-id"` and optional pipe-delimited `route_hints`. The reducer preserves one node per stable id/canonical label, drops hidden or generic aliases, and merges a later visibly established alias. Old dynamic saves recover their canonical label and a current sublocation only when recent visible history proves that association. Never infer arbitrary historical synonyms.
- Define one world-native `transitionAnchor` per Cartridge. It may be fixed in space or portable, but it must be recognisable and believable in that story.
- Before applying a location-changing domain effect or `map_update`, append a visible bridge that closes the source leg, passes through the anchor, and only then arrives. Put this block before destination narration.
- A hub world may require an explicit player return action. A linear journey may use a portable route record. An open world may use camp, map, log, vehicle, stair landing, or another recurring checkpoint. Do not add a universal void or force a physical return that contradicts the route.
- Prompt the model with the same contract, but enforce and test it in the reducer because generation can ignore prompts.

## Danger integrity

- Schedule ordinary danger from persisted `safeTurns` and encounter cycle, not random render-time probability.
- Persist phase, threat, severity, cycle, cooldown, and last outcome.
- Scope world-specific threats with `dangerDirector.threatLocations`; a threat whose allowlist excludes the current map node is not a candidate. Omitted entries remain global fallbacks.
- A scheduled directive becomes authority only when the same turn visibly establishes the threat, emits an exact phase/kind `encounter`, and grounds every non-resolution choice in that threat. If any part is missing or mismatched, both the pipeline and reducer reject the directive; it cannot mutate danger state or inject fallback threat choices behind unrelated prose.
- Allow at most one generated repair for a rejected danger turn. If that repair still fails while a `DangerDirective` exists, commit a deterministic local scene for the exact threat and phase before considering generic consistency recovery. A warning fallback must advance to confrontation, a confrontation fallback must remain immediately actionable, and a resolution fallback must settle the fixed local outcome and return to playable calm choices. Never route this case through generic location/objective recovery while the threat remains active.
- On load, migrate only saves visibly caught in the former pattern: an active threat plus the current scene's generic consistency-recovery block/menu or the exact obsolete danger-label form. Rewrite the live tray and current immutable choice record idempotently; do not replace normal authored danger choices.
- A deterministic authored turn owns its calm story beat. Do not stack a newly scheduled random danger on top of an authored opening/choice consequence; schedule it on a later eligible turn.
- Treat a visible attack, rescue, pursuit, intrusion or confrontation as an immediate encounter even during the normal opening grace period. The establishing turn must emit a grounded `encounter`; subsequent discussion, observation, questioning, waiting and planning must retain the same participants and threat in visible prose and encounter metadata. Only a visible same-thread outcome plus `resolution` may return the save to calm.
- Let threshold stats increase severity or skip warning only when the Cartridge registers them.
- Generate one stable d20 from game, scene, cycle, and action. Refresh and retry cannot reroll.
- Override AI-provided check values with the local check.
- Require a real consequence for costly success/failure; use a bounded fallback cost only when the model omitted one.
- Return to a playable calm state with choices after resolution.
- Mechanically test every map node against every scoped threat across multiple cycles, plus a hidden/mismatched directive negative case, an exact visible positive control, consecutive invalid generated/repair drafts, deterministic local advancement, calm resolution, legacy-loop migration and authored-choice preservation. Run `npm run test:danger-grounding` and `npm run test:danger-loop` for stateful products.

## Image identity

- Build each prompt from current event facts before art direction.
- Strip opening-scene residue from later prompts; never send a negative list that repeats unwanted landmarks.
- Mark subjects as `player`, `environment`, or `others`; the tag owns avatar-reference identity, not literal presence.
- Pass avatar `ref_url` only when the player is the dominant visible actor performing the main action. A companion/NPC-led shot uses `others` even if the player is incidental or in the background. Omit the reference for empty, object-only and other-character-led shots.
- For every referenced shot, bind the reference's complete visual identity to `SUBJECT A`: face if visible, silhouette, form/species, body proportions, material, covering, costume, colors, patterns, and accessories. Never invent hidden/absent faces or limbs, and never transfer any reference trait to companions, background people, reflections, masks or animals.
- A generated recurring NPC first receives one text-mode 4:5 canonical identity anchor. Persist only the AlterU Media Service task id; resolve it to a temporary URL when generating an edit-mode story frame. Reuse that anchor for every later NPC-led frame, including after JSON save reload. Never save CDN URLs, `reference_urls`, raw prompts or avatar URLs inside character identity state.
