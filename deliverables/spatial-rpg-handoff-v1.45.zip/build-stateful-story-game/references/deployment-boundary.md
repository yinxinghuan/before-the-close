# Deployment boundary for colleague handoff

This package intentionally has no deployment workflow. The receiving environment owns all publishing and hosting decisions.

## Outputs this Skill may create

- independent source project;
- UUID v4 and isolated save namespace;
- `dist/` from `npm run build`;
- `public/poster.png`, `meta.json`, and `THIRD_PARTY_NOTICES.txt`;
- `doc/requirements.md`, `doc/visual.md`, `doc/technical.md`, and `doc/artifact-handoff.json`;
- Git commit when the user explicitly requests source control work.

## Actions this Skill must not perform

- edit any central `games.json` or catalog database input;
- run a migration/import tool;
- call any private or workspace-specific deployment script;
- create or update GitHub Pages workflows;
- upload source ZIPs, posters, or builds to an internal CDN;
- assume the production URL uses a game id, UUID, session id, or repository name;
- describe the project as published, deployed, online, or production-verified.

## Artifact manifest

Write `doc/artifact-handoff.json` with:

```json
{
  "schemaVersion": 1,
  "projectId": "example-game",
  "uuid": "00000000-0000-4000-8000-000000000000",
  "sourceCommit": null,
  "buildCommand": "npm run build",
  "distPath": "dist",
  "posterPath": "public/poster.png",
  "noticesPath": "public/THIRD_PARTY_NOTICES.txt",
  "tests": [],
  "deploymentIncluded": false
}
```

The receiving environment owns URL conventions, environment variables, catalog fields, source archive location, CDN, backend deployment, and production verification. If those requirements are unknown, hand off the verified artifact and stop; do not guess.
