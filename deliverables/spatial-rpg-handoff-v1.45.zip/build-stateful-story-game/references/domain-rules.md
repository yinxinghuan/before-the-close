# Deterministic domain rules

Use this layer when a story contains scarce resources, one-time rewards, crafting or exchanges, route commitments, charged items, party gates, recoveries, chapter prerequisites, or ending capabilities. Do not register ordinary conversation, descriptive exploration, or improvisation without persistent consequences.

## Responsibility split

`StorySave` remains the database. The reducer remains the only executor. `domainRules` adds the adjudication layer: it decides whether a recognized intent is legal now and supplies one exact atomic effect set, authored visible result text, and however many choices are actually valid after that transaction. For governed turns, prefer this local text and skip the model entirely; narration is part of the tested transaction, not a reason to pay latency or reopen state authority.

```text
free text → intent match → requirements → accepted/rejected resolution
          → local authored result (zero model call)
          → apply one local transaction → derive views → save
```

If no rule matches, retain the normal open AI story flow. If a rule matches, the entire turn is governed and the adapter is not called. If a legacy engine still calls a narrator, discard every model protocol command, including `choices`, and install the rule resolution's local choices. Do not preserve “unrelated” model state commands. A model can otherwise combine two player actions in one response, silently mint resources, or offer choices for a state that did not actually commit.

## Cartridge authoring contract

Each rule needs:

- a stable `id` and intent;
- bilingual `match` phrases including natural modifiers and repeat wording;
- explicit requirements with player-readable rejection reasons;
- one exact effect list using stable stat, fact, item, character and map ids; include objective, clock and session checkpoint effects when the governed event changes them;
- visible success text;
- a player-readable rejection sentence or requirement reasons that can stand on screen without model rewriting;
- one to five `successChoices` and, when requirements can fail, however many currently feasible `rejectionChoices` actually exist; never pad to three.

Intent phrases are an authorization boundary, not a loose keyword bag. Include natural action paraphrases that mean the same committed transaction, but separately replay mentions, questions, future plans and negations so they cannot spend or grant resources. A resource label appearing in prose is never sufficient authorization.

Each rule also declares what happens to the current narrative thread. Use `successContinuation` / `rejectionContinuation` deliberately: `resume` preserves `decisionContext` and revalidates the unperformed sibling choices, `derive` builds new choices from the resulting authoritative state, `replace` installs the rule's authored choices, and `checkpoint` ends the session with no stale ordinary choices. A rest, meal, short errand or rejected action inserted into an unfinished scene normally uses `resume`; travel usually uses `derive`; day-end and lodging stop points use `checkpoint`. Do not let a local utility action replace an ongoing investigation or conflict with a global menu.

Use a `capability` requirement for actions that depend on the current place, and `repeatPolicy: { scope: 'location-day' }` for work/rewards that may occur once per place per day. Reload migration must rebuild both repeat markers and continuation choices idempotently.

Open narrative recommendation grounding must not demand that every future-action verb already appeared verbatim in the preceding prose. Preserve a choice when it points to an established person, place, object or other concrete current evidence; reject it only when a stable reference is provably unseen, stale or impossible. Treat the long-term objective as context rather than an executable label. Immediately after a committed arrival, prefer local actions over returning to the place just left whenever local alternatives exist, while preserving the return if it is the only feasible exit.

Requirements may read the current map node, facts, item counts, character status and danger phase. Effects may change stats, facts, item ownership, party membership, current map node, danger outcome, objective, clock and session checkpoint. A party-add effect may introduce a fixed `hiddenUntilIntroduced` character only when the same visible success text performs that character's valid debut. Clamp stat effects through registered `StatDefinition` limits.

### Stat floors and forced recovery

A visible stat that can reach its minimum must not become a decorative dead number. When the design says the floor restricts play, configure `StatDefinition.floorRule` instead of relying on prompt prose:

- `enteredText` explains the consequence in the same turn that reaches the floor;
- `blockedText` explains why a later stale or free-form action cannot execute;
- `recoveryChoices` replaces model and legacy choices while the floor remains active;
- `allowedDomainRuleIds` is the allowlist of deterministic recoveries that may execute at the floor.

Every recovery choice must match a local rule with exact effects. At least one recovery must remain feasible without a scarce resource, or the player can be soft-locked. Reload normalization must reinstall the floor notice and choices idempotently. Test crossing the floor, free-input rejection, allowed recovery, exact restoration, and a legacy save already at the floor.

Do not make the floor the only place where recovery works. If the world permits ordinary rest, explicit player commitments such as “rest in the hut,” “take a nap,” or localized equivalents resolve locally at any stat value; `intentGuard: rest-commitment` must keep questions about rooms, prices and availability in the information flow instead of treating them as recovery consent. Use `dangerPolicy: suppress` for recovery that must not receive a same-turn scheduled danger loss. When active danger makes resting nonsensical, add a calm-state requirement with a visible rejection reason and keep one `dangerPolicy: withdraw` rule feasible even at the floor; it may append the authoritative danger outcome and recovery in one atomic transaction. If a trusted room/night recovery exceeds the model protocol's `maxDelta`, declare a narrow `domainMaxDelta` rather than increasing the model's cap or silently truncating the documented amount.

Use one canonical stored value for charged items and derive the visible remainder. For three uses, store `uses = 0..3` and derive `remaining = 3 - uses`; never persist both counters.

When a fact is only a view of owned stable items—such as `home-clue-count`, “first clue found”, or “all four clues found”—declare it in `derivedFacts`. Reconstruct it from inventory after every load and governed transaction instead of letting item commands and fact commands drift independently. Legacy metrics without ids may be reconciled by normalized label once, then receive the stable metric id.

## Atomicity and ordering

Resolve the domain action before scheduling danger. A rejected domain action does not also advance a danger check. A rule that resolves danger owns that resolution and suppresses the ordinary danger director for the turn.

Apply no effects when any requirement fails. Never consume an item before all requirements pass. A rejection also freezes the danger cadence for that attempt: it cannot silently advance safe turns, consume cooldown or resolve a model-proposed encounter. On accepted turns, aggregate stat effects, apply the remaining effects, then synchronize derived metrics and persist once. Protocol commands from a governed narration must also be hidden from image triggers and milestone detection; otherwise discarded loot or a fake checkpoint can still influence generated art and video scheduling.

The rejection result must name the actual unmet condition and offer actions legal in the resulting unchanged state. Success and rejection choices are different product states. Candidate quick replies that match a domain rule must be pre-resolved against the post-turn candidate state; retain only `accepted` results, even if a rejected label happens to share words with the prose.

## Intent matching

Normalize case, whitespace and punctuation. Chinese free text benefits from ordered-subsequence tolerance so “再搜查一次燃料棚” can match “搜查燃料棚”. Keep matches specific enough to avoid overlapping rules and choose the strongest/longest match deterministically.

Use `matchMode: 'exact'` for clarification commands whose wording must not capture a longer actionable sentence, such as a budget-only “spend everything” rule that must not intercept “spend everything on the room”. Use `objectiveTransitions` when a reducer-owned threshold changes what the player is actually trying to do; keep both locales aligned and require explicit state predicates.

Test both languages. Test natural modifiers such as “again”, “now”, “with Ada”, object-first phrasing and a fourth-use attempt. If ambiguity can change which transaction runs, add a more explicit resolver or ask the player to disambiguate without mutating state.

## Required validation

For each rule prove:

1. every prerequisite failure is atomic and returns feasible choices;
2. the legal action applies exact values once;
3. repeat attempts do not repeat rewards or costs;
4. hostile model commands cannot alter any stat, fact, inventory, party, map, danger, clock, objective, session checkpoint or next choices during the governed turn;
5. stable ids survive both locales and save restoration;
6. derived metrics reconstruct from the canonical fact;
7. ungoverned free actions still reach the AI flow.

Run `npm run test:domain`, `npm run test:domain-continuity`, the existing reducer/danger tests, TypeScript, build, and at least one browser play trace covering reject → feasible recovery → success → repeat reject. The continuity test must prove `resume` preserves the unfinished objective/premise, capability rejection has zero effects, `checkpoint` clears stale choices, and every migration is idempotent.

For a cinematic opening, the entry CTA may itself be the first governed action. Store it as `opening.entryAction`, keep `opening.choices` empty before it commits, and let `enterStory()` produce scene 1 through the same reducer. In the first three scenes, hide choices, free input and numeric shortcuts until the current authored caption pages have been read. This gate is presentation only; it must not mutate or delay the already-committed transaction.

For an accumulated-reading/stateful RPG, do not add a global scene gate or convert the history feed into a fixed short sequence. Govern only the high-risk opening commitments and other scarce or irreversible actions. After the local result, the original conversation, history, free input, danger and open-world director continue normally.

## Verified case: Last Train to Dawn

The 2026-08-12 Last Train to Dawn experiment governed eight opening rules: starter repair, fuel salvage, brake inspection/replacement, three route commitments and the three-use Master Switch Key.

Adversarial replay finished at Fuel 52, Condition 97, Morale 58, route `valley`, key uses 3, remaining 0 and map node `river-valley`, despite injected inflated values and false state commands. Browser play at 390×844 proved route rejection before repair, exact Condition +5 and Ada's consequence after repair, and no reward on repeat.

The first browser attempt exposed a model turn that combined starter repair with fuel-shed loot. Field-by-field command filtering did not prevent it. The verified fix treats every governed turn as one complete local transaction. This atomic-turn rule is mandatory in both bundled templates.

## Verified case: Draw Me Out

The 2026-08-12 Draw Me Out experiment governed twelve opening rules: acquiring the one Undo Key, entering the Boundless, Little Remnant's visible debut, three stable first-world routes, three exact first Home Clues, and paid versus free Undo.

The test injected commands that set stats to extremes, granted 99 fake clues, jumped to an invented map, introduced a hidden future character, rewrote objective and clock, ended the session, and returned unrelated choices. The local result still held one key with three derived uses, one committed route, one clue, the correct hidden cast, and locally supplied recovery choices. Browser play at 390×844 proved one acquisition, Little Remnant's debut and party join, exact first clue, duplicate-clue rejection, free-Undo rejection, explicit permanent memory cost, and a remaining-use value of two.

This experiment added three general rules. First, objective, clock and session checkpoints belong inside the same transaction as the reward that changes them. Second, next choices are output state and must be locally installed on a governed turn. Third, milestone facts derived from owned stable items must be rebuilt from inventory rather than independently written.

## Verified case: Before We Get Home

The 2026-08-12 Before We Get Home retrofit governed the opening voice replay and the station-to-Old-Market commitment. A hostile model tried to add 99 Battery and Time, reset the exit fact, move to an invented safe zone, preload a future nurse and return unrelated choices. The final state remained Battery 43, Before Dawn 77, current map `old-market`, and the sole added companion `ahe-rider`.

Browser play at 390×844 proved that the transaction stays inspectable after presentation splits it into narrative, stat and location layers: voice replay visibly cost 4 once, Ahe received an ordered visible debut before joining, the route visibly cost 7, and a repeat exit was rejected. This case establishes that rules may introduce a `hiddenUntilIntroduced` fixed character only when the same local success text performs the full debut; unrelated future characters remain hidden.

## Verified case: The Erased Kingdom

The 2026-08-12 The Erased Kingdom retrofit governed two nested exclusive commitments: one of three opening rescues and one of three Apple Vale anchors. A hostile model tried to add 12 Supplies, add 40 Recognition, write two mutually exclusive facts, add the future regent and replace all choices. The final tested path remained `first-rescue=registry-page`, one stable registry fragment, `apple-anchor=bridge`, Supplies 6 and Recognition 48, with the regent absent.

Browser play at 390×844 proved fragment ownership, exact bridge cost and second-anchor rejection. The opening roster contained only Mara; Oren, Sera, Eli and Veyr stayed absent until a visible introduction. This case establishes that all branches sharing one commitment must be governed together. Governing only the most attractive branch leaves players able to collect an alternative through the open AI path.

## Verified batch: cinematic and accumulated-reading RPGs

The 2026-08-12 batch covered Before We Get Home, The Erased Kingdom, City of Tides, Rooftop Apartment, Seventh Dock, and The Wild Road.

The two cinematic games moved their entry CTA into a real governed scene, skipped the model for governed results, progressively revealed initially unexplained stats, and gated choices through scene 3 until the current caption sequence was read. The four accumulated-reading games added persistent facts and three mutually exclusive opening transactions each, but retained their history feeds, free actions, chapter continuity, danger cadence and open-world behavior afterward.

Adversarial replays proved all 12 accumulated-reading opening branches commit exact local facts and choices once. Injected stat, map, character and choice commands were ignored. City of Tides introduced Nilo only on the visible rescue branch; Seventh Dock kept Oren and Sai absent from the initial roster. The Wild Road committed a first route without creating a mandatory main quest. This establishes that the domain layer is profile-neutral: the transaction contract is shared, while pagination and interaction pacing stay specific to the selected game profile.
