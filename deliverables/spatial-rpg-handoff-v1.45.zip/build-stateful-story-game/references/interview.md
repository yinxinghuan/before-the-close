# Product interview

The agent leads the user from a familiar fantasy to a buildable world. Ask at most three questions per turn, and offer a recommended default when the user is unsure.

## First pass

1. **Player fantasy and emotion**: “Who are you in this world, what do you get to do freely, and what should it feel like?”
2. **World shape**: “Should it be a guided case/chapter, or an open world where the player chooses their own goals?”
3. **Visible state**: “Which three changing values should the player care about, and what meaningful item/resource makes choices costly?”

Before implementation, also ask in ordinary language whether the player wants to read an accumulating journey or receive one new illustrated shot after each action with shorter text. Use this answer with `template-selection.md`; do not present engine names as technical jargon.

Use everyday language. Do not ask the user to choose a reducer, model, schema, API, save format, or frontend stack.

## Second pass only when needed

- What facts are permanently true and may never be rewritten?
- What may the AI freely create: local places, NPCs, rumors, jobs, treasures, relationship events?
- What is a setback: injury, debt, suspicion, lost time, broken trust, lost supplies, or a route change?
- Does the game have a true ending, or only resumable chapter boundaries?
- What visual material and sound world distinguish it?
- How often should pressure or danger interrupt ordinary exploration, and should physical combat be absent, rare, or a normal possibility?
- Which companions or relationships must remain stable across many sessions?

## Proposal rules

- Prefer a world ordinary players recognize without a glossary.
- Give each stat a decision consequence, not just flavor.
- Keep one short-term objective visible, but do not confuse it with a forced main quest.
- For open worlds, define common-sense geography, time, ownership, scarcity, and NPC knowledge boundaries.
- For relationship games, define who knows which facts and make every relationship delta cite an event.
- For treasure, state ability, limit/cost, provenance, rarity, and whether it can change ownership.
- Failure creates playable consequences; it does not silently erase a save.
- Separate everyday pressure from dangerous encounters. Ask what warning signs players can read and what three response styles the world should support.
- Treat physical combat as a product choice, not a default RPG requirement.

## Deliverable

Write `doc/world-brief.json` and summarize it to the user in six sentences:

1. Player fantasy.
2. World promise.
3. Guided or open-world structure.
4. Three stats.
5. Important resource/treasure and failure consequence.
6. Danger cadence plus visual and audio direction.

Then ask only for corrections that would materially change the game.
