# Asynchronous shared-world RPG baseline

This reference records the reusable multiplayer experience proven by City of Tides and refined by the deployed Neighbor Help validation experiment. It is a product and authority contract, not a deployment guide.

## Contents

1. Current capability status
2. What was actually proven
3. Architecture and authority boundary
4. Shared and private state
5. Action, conflict, and retry contract
6. Public aid and grant receipts
7. Time, seasons, and permanent anchors
8. Identity, moderation, and security limits
9. Runtime API mounting and Remix isolation
10. Required backend surface
11. Client behavior
12. Mechanical acceptance matrix
13. Experience that must not be copied forward
14. Gate for freezing a reusable multiplayer template

## 1. Current capability status

The two bundled engines in this Skill prove persistent **personal** RPGs. They do not contain a generic multiplayer backend, room service, event store, or shared-world shell.

The prior multiplayer work exists as a verified reference implementation with two cooperating parts:

- an asynchronous shared-world frontend and deterministic reducer;
- a game-owned Worker using one Durable Object and SQLite as the authority.

The optional `assets/action-authority-experiment/` now bundles a transport-neutral candidate gateway and a local real-HTTP/SQLite proof as an isolated lab, not as either personal engine's default. Two isolated QA sessions raced for one resource, replayed stable action ids, refreshed a stale choice, transferred one unique item through two private receipts, reconnected by cursor, and could not spoof the server-bound actor. A second fault matrix drops the HTTP response after a successful commit, replays one id three times, fails personal save/ack, reconnects from an old cursor, upgrades the ruleset and expires a session. Its service uses a real random TCP port and SQLite `BEGIN IMMEDIATE`, but remains one local process with QA tokens rather than platform-signed identity. Treat it as runnable adapter evidence between the pure reducer and Neighbor Help's deployed Durable Object evidence, not as a production multiplayer engine.

Use the contracts below when designing a shared-world game. Do not claim that this Skill already exports a production multiplayer game. Neighbor Help is the second materially different mechanism and has passed local checks plus a deployed Durable Object matrix with two isolated browser sessions, real cursor/receipt/handoff transactions, real AlterU media attachment, rejection and replacement. An initial Telegram run exposed phase-overreaching prose and post-commit rollback. After the committed-outcome bridge was deployed, a fresh real-container transaction passed `claim → close/reentry → complete`: the public world advanced from version/cursor `3/2` to `4/3`, preserved that state on reentry, then reached `5/4`; claim prose did not invent completion, completion prose did not report failure, and the stale completion action disappeared. The child game still received only a raw Telegram user identifier and API origin, not a Worker-verifiable signed identity. It has therefore not passed backend-verifiable platform identity, two physical authenticated devices, receiving-runtime multi-instance testing or real personal-cloud-save failure injection, so a reusable multiplayer engine remains unfrozen.

Supported shapes:

1. Personal world with generated companions: supported by the bundled engines.
2. Local multi-actor simulation: useful for rule testing; label it local-only.
3. Asynchronous shared world: use the proven contracts below and a receiving environment that supplies the authority service.
4. Realtime co-op, synchronous combat, authoritative physics, presence, voice, and host migration: not covered.

## 2. What was actually proven

City of Tides proved an asynchronous world where players arriving at different times can:

- read and answer expiring regional traces;
- reinforce another player's warning;
- claim limited public aid;
- contribute once to seasonal public projects;
- carry a small number of completed projects into later seasons as permanent anchors;
- report abusive public content;
- reopen after interruption and reconcile pending personal grants.

The implementation and automated evidence covered:

- one shared `world_key=main` per game instance;
- append-only public events plus a rebuildable snapshot;
- monotonically increasing world `version` and event `cursor`;
- idempotent client actions;
- stale-version rejection and bounded retry;
- four players racing for three aid units, producing exactly three grants;
- six-visible-trace regional caps and per-author caps;
- TTL filtering without deleting audit history;
- unique-contributor project progress;
- single seasonal resolution and one permanent anchor;
- grant persistence followed by acknowledgement;
- three-distinct-reporter hiding;
- production lab controls disabled;
- local and remote gateways behind one frontend interface.

Neighbor Help then exercised a different shared mechanic: atomic ownership and handoff of unique concrete objects tied to everyday requests. Local and deployed evidence covered:

- two clients racing for the last umbrella, with one committed owner and a grounded recovery route for the stale loser;
- stable action replay, stale-version rejection, cursor catch-up and receipt acknowledgement;
- handoff receipts that remove the same item instance from one private mirror and add it to another;
- public item custody separated from private receipt-sync status;
- public events mechanically checked for absence of relationship, private-dialogue and free-input fields;
- one public media attachment per committed event, restricted to the original actor and AlterU CDN;
- one platform save row carrying story and receipt data through named envelope namespaces rather than competing whole-row writes;
- static and runtime images using the same AlterU Media Service contract, with human pixel acceptance for pseudotext, cultural specificity and exact scarce-object count.

The later action-authority adapter experiment independently proved that the common client contract can cross a real HTTP boundary without sending an actor id in its action body. A test authority bound opaque session tokens to actors, serialized three committed actions in SQLite transactions, returned one winner for one scarce unit, and required private receipt-id persistence before acknowledgement. This narrows the remaining backend work to the receiving runtime, identity and failure paths rather than basic client/reducer semantics.

These are validated implementation lessons, not authenticated production multiplayer proof. The deployed UUID test verified real Durable Object behavior and `committed event → media task → CDN attachment → rejection/replacement → second-client cursor read`. Backend-verifiable identity, two physical authenticated devices and personal cloud-save failure injection remain required.

One real Telegram Mini App session later verified `Telegram launch → shared action → Durable Object transaction → close/relaunch → personal story + shared cursor + private receipt mirror recovery`. This is runtime evidence, not identity evidence: the embedded game URL exposed a raw user id and API origin but no signed proof the game Worker could verify. Do not copy any observed Telegram id, init data, signature, token, or query string into fixtures, logs, handoff files, or source control. The same run exposed Chinese UI mixed with English fixed phrases and prose that advanced a `request_claimed` transaction to fictional completion, so platform-locale and committed-outcome narration must be tested separately from local reducer/browser checks.

The same session then committed `request_completed`: authority reached version 3 / cursor 2, returned the umbrella, persisted and acknowledged the remove receipt, and left no shared item held. The story layer nevertheless entered generic consistency recovery, told the player the action had not taken effect, and restored the same now-invalid completion choice. This proves that transaction correctness alone is insufficient. After any successful commit, the committed event is irreversible UI truth: if AI prose fails validation, render a deterministic event-specific fallback and regenerate choices from the refreshed authority view. Never restore the pre-commit story snapshot or its choices.

## 3. Architecture and authority boundary

Use this sequence:

```text
player intent
→ client creates one stable action_id
→ authority validates identity, expected version, ruleset, limits, and target
→ deterministic reducer resolves the whole transaction
→ event, snapshot, entity, grant, version, cursor, and cached result commit atomically
→ client renders the committed result
→ optional AI prose/image attaches to the committed event without changing authority
```

Hard rules:

- The browser never writes shared stats, quantities, clocks, completion, authorship, or grants directly.
- AI never runs inside the database transaction and never determines whether an action succeeded.
- A generated story response may describe only a committed result.
- AI, media, analytics, or notification failure cannot roll back a committed world action.
- One player's personal save is never the shared world.
- A recent-user list, analytics stream, or generated narration is never an event log.

The authority stores at least:

```ts
type WorldHead = {
  worldKey: string
  rulesetId: string
  rulesetVersion: number
  version: number
  cursor: number
  snapshot: unknown
  activeSeasonId?: string
}

type WorldEvent = {
  id: string
  seq: number
  worldVersion: number
  actionId: string
  actorUserId: string
  type: string
  payload: unknown
  visibility: 'public' | 'hidden' | 'deleted'
  createdAt: number
  expiresAt?: number
}
```

Keep an action-result cache keyed by `action_id`. Keep public entities such as traces, aid, projects, and anchors separately when they need target-level status or TTL. A damaged snapshot must be rebuildable from the latest valid snapshot plus later events.

## 4. Shared and private state

Shared authority may contain:

- public traces and replies;
- public aid quantities;
- regional public metrics;
- project progress and distinct contributors;
- seasons, summaries, anchors, visibility, and moderation state;
- minimal public actor profile needed to render authorship.

Keep private:

- personal quest state and unrevealed choices;
- private relationships, secrets, preferences, and contacts;
- personal inventory after a grant is reconciled;
- private AI context and unpublished generated prose;
- authentication proof and sensitive profile data.

Public multiplayer information should remain understandable without a private story. A personal main quest may coexist with shared texture, but neither layer may silently mutate the other.

## 5. Action, conflict, and retry contract

Every public write carries:

```json
{
  "world_key": "main",
  "action_id": "client-generated-uuid",
  "expected_version": 481,
  "ruleset_version": 1,
  "type": "repair_lighthouse",
  "payload": {}
}
```

Authority order:

1. Return the cached first result when `action_id` already exists.
2. Verify authenticated membership or the explicitly documented beta boundary.
3. Reject when `expected_version` is stale.
4. Validate the entire action through the game ruleset.
5. Commit every effect and cache the response in one transaction.

Client retry rules:

- Generate `action_id` once per player intent.
- Reuse the same id across network retry and version-conflict retry.
- On `VERSION_CONFLICT`, read the newest world, revalidate whether the intent is still legal, and retry at most three times.
- Never convert a failed request into story success.
- Disable accidental double-submit locally, but rely on server idempotency for correctness.
- A transport timeout is an **unknown outcome**, not a failed story action. Read events after the last cursor and reconcile by the same actor-scoped `action_id`; if no result is visible, retry that exact id. Never mint a replacement id or narrate failure merely because the response was lost.
- If neither submission nor reconciliation can reach the authority, keep the intent pending/unknown and offer reconnect. Only an authoritative rejection may become a visible failure.

World-level versioning was sufficient for the low-volume experiment. Preserve room for entity-level expected versions when unrelated regional writes become too contentious.

## 6. Public aid and grant receipts

Limited aid crosses a shared/private boundary. Use a receipt protocol:

1. In one authority transaction, decrement public quantity and create a user-specific grant receipt.
2. Client lists pending receipts for the authenticated user.
3. Merge each `receipt_id` exactly once into the private inventory mirror.
4. Persist private inventory through the platform's personal save.
5. Read the personal save back and verify all receipt ids.
6. Only then acknowledge the authority receipt.

If the client closes, save is delayed, or acknowledgement fails, the receipt remains pending and reconciles on the next visit. Never acknowledge before private-save readback. Never use item name or quantity alone as the deduplication key.

When the platform stores one `resource_data` row per user and `session_id`, story state, relationships, and receipt-backed inventory cannot use independent whole-row save hooks. Store one envelope such as `{ __alteruSaveEnvelope: 1, namespaces: { story, sharedInventory } }`; merge one namespace into the latest cached/read envelope and write the whole envelope. Migrate a legacy raw story save into the story namespace. Mechanically prove that updating or clearing either namespace preserves the other.

Keep `receipt_pending` private. Public item custody should describe the authority fact (`community`, `player`, `handoff`, or `returned`), while the client separately reports whether its private mirror has persisted and acknowledged the receipt.

## 7. Time, seasons, and permanent anchors

Server time is the only authority for TTL and season boundaries. Client clocks are display hints.

Use three layers:

- Immediate traces: expiring public messages, warnings, routes, temporary aid.
- Seasonal projects: bounded contributions with distinct-contributor accounting and one resolution.
- Permanent anchors: whitelist-derived results created only by the season resolver.

Do not allow free text from one player to become a permanent world rule. Permanent anchors require deterministic eligibility, source events, contributor evidence, moderation state, and idempotent resolution.

AI summaries are optional attachments. A deterministic fallback must allow the next season to open when AI is unavailable.

## 8. Identity, moderation, and security limits

The proven production experiment used an explicitly labeled `unverified-production-beta` mode because the platform did not yet expose a signature that a custom Worker could verify. The Worker accepted bounded client identity fields and mitigated abuse with:

- strict action and quantity validation;
- public-write frequency and length limits;
- per-region and per-user caps;
- unique action ids;
- distinct-contributor counting;
- duplicate-report protection;
- hiding after three distinct reporters;
- disabled lab reset and forced resolution.

These measures are not authentication. Do not label the system secure or cheat-proof until the authority verifies platform-issued identity and ignores client-supplied user ids. `assets/action-authority-experiment/src/story/experimental/platformIdentity.ts` validates claims only **after** provider-specific cryptographic verification; it deliberately does not turn query data into a proof.

The platform proof/session exchange must bind issuer, audience, generated game id, stable subject, opaque session id, issued/expiry time, unique token id and narrow scopes. Keep bootstrap proofs short-lived (recommended maximum ten minutes), verify the signature/key id or use a server-to-server introspection endpoint, prevent token-id replay where the provider contract requires it, and mint a game-scoped opaque session. The browser never chooses `subject`, `gameId` or membership. Refresh, revocation, blocking and deletion stay server-side.

For the next backend handoff, ask explicitly for:

- signed identity token/header or a server-to-server verification endpoint;
- membership and block enforcement;
- content moderation and administrator restore/delete audit;
- user export and deletion semantics;
- credential rotation and narrow allowed origins.

## 9. Runtime API mounting and Remix isolation

The current platform contract is:

```ts
API_BASE = '/' + GAME_ID
```

The frontend and its game-owned API run under the same generated game/session path. Frontend requests use `/<GAME_ID>/api/*`; the platform strips the game prefix before invoking the Worker, whose internal routes remain `/api/*`.

Requirements:

- derive the base from the Remix-replaceable game id;
- do not embed the source game's host, UUID, or database URL;
- do not use production `VITE_*_API_BASE` values;
- allow `?api_base=` only as an explicit staging/QA override;
- allow a local simulation only through an explicit `?local=1` switch;
- never let production silently fall back to a local world;
- keep platform APIs such as profile, personal save, analytics, and notifications on the platform bridge, separate from the game-owned API base.

The older backend helper documentation used a GitHub Pages frontend plus an absolute `VITE_*` API base. That contract is obsolete for Remix-safe shared worlds and must not be copied into new games or colleague handoff material.

## 10. Required backend surface

Keep route semantics stable even if the receiving backend renames fields:

| Route | Responsibility |
| --- | --- |
| `POST /api/world/ensure` | idempotently obtain the game main world and ruleset |
| `GET /api/world/state` | versioned snapshot, cursor, events, active entities, server time |
| `POST /api/world/action` | idempotent authoritative transaction |
| `GET /api/world/grants` | pending receipts for the authenticated user |
| `POST /api/world/grant/ack` | acknowledge only after private persistence is verified |
| `GET /api/world/history` | seasons, anchors, provenance, and audit pagination |
| `POST /api/world/report` | deduplicated report and visibility update |
| `GET /api/health` | storage, ruleset, lab/public mode, and identity mode |

Useful stable error codes include `AUTH_REQUIRED`, `VERSION_CONFLICT`, `DUPLICATE_ACTION`, `INVALID_ACTION`, `ENTITY_NOT_FOUND`, `TRACE_EXPIRED`, `ITEM_UNAVAILABLE`, `RATE_LIMITED`, `CONTENT_REJECTED`, `SEASON_CLOSED`, and `RULESET_MISMATCH`.

## 11. Client behavior

Expose one gateway interface with remote and local implementations. The remote gateway owns ensure, state reads, action retries, grants, acknowledgement, and reports. The local gateway is a deterministic simulation only.

Refresh remote state:

- after each commit;
- on page visibility restoration;
- on a low-frequency interval such as 15 seconds while visible;
- when a conflict or target-expired result requires a fresh read.

Keep the first interaction responsive. Render a local submitting state immediately, then display only the committed result. Preserve typed text when content or rate validation rejects it.

For generated shared-world media, static concept art and runtime scenes must use the same downstream media service as production. A successful task response is not visual acceptance. Inspect pixels for pseudotext, logos/signatures, culturally over-specific architecture or uniforms, current-location mismatch, identity drift, and exact count of scarce objects. “No text” alone is insufficient for signs, noticeboards, plates, labels, and speech bubbles; remove the text-bearing carrier or replace it with a non-text object when needed.

Enforce one **active** attachment per committed source event, not one irreversible attachment forever. If visual acceptance fails, let only the source-event actor or verified moderator append an immutable `media_rejected` tombstone with a bounded reason code. A replacement may attach only after the previous attachment is rejected. Preserve the rejected URL and tombstone for audit, but active-media resolution must ignore it. A retry of the original attachment action still returns its cached result; it must not reactivate a rejected attachment.

## 12. Mechanical acceptance matrix

Run the following with the real authority service, not only a local reducer:

1. User A leaves a warning; user B reads and responds from another authenticated session.
2. Repeating one `action_id` three times increments version once.
3. A stale action returns `VERSION_CONFLICT`; retry uses the same id and a newly validated version.
4. Four users race for three aid units; exactly three receipts exist.
5. A receipt merges once, survives reload, verifies in personal cloud save, then acknowledges.
6. Expired traces leave the active view but remain in history.
7. Region and per-author caps are enforced by the authority.
8. Repeated contribution does not increase distinct contributor count.
9. Season resolution retried multiple times creates one next season and one qualifying anchor.
10. Three distinct reports hide public content; duplicate reports do not count twice.
11. AI, media, and notifications fully fail while actions 1–10 remain correct.
12. A Remix build connects to its own `/<new GAME_ID>/api/*` and cannot read the source game's world.
13. Production cannot access lab reset or forced season resolution.
14. Unsigned identity mode is visibly labeled and never presented as verified membership.
15. Story and receipt namespaces share one personal cloud-save envelope; alternating writes and clears cannot erase the other namespace.
16. A scarce-object scene is pixel-checked for exact object count, and every text-bearing carrier is checked for pseudotext rather than trusting prompt wording.
17. A committed important-dialogue event creates one active AlterU CDN attachment; retry returns the cached attachment and another actor cannot replace it. When pixel QA rejects it, a tombstone permits exactly one clean replacement while preserving history.
18. Launch through the real platform container and verify that the authority receives a server-verifiable identity proof. A raw query-string user id is a failed row even when the action commits successfully.
19. Close and relaunch the real container; confirm that personal story, receipt-id namespace and shared cursor restore together before acknowledging any pending receipt.
20. Race one scarce action from two real authenticated accounts or physical clients; exactly one wins, the loser refreshes to a grounded alternative, and neither client can select the other actor.
21. Run both supported platform locales through at least one generated turn and reject mixed-language fixed phrases, protocol text or fallback copy.
22. For every authority action type, compare committed events with visible prose. `claim` must not narrate delivery, completion, return, handoff, reward or a later authority phase; each later phase requires its own committed action before prose may describe it.
23. Inject generation timeout, malformed protocol and consistency failure immediately after a successful authority commit. The UI must show a deterministic committed-result fallback, retain the new world version and rebuild choices from it; it must never tell the player the action failed or restore pre-commit choices.
24. After `completed`, `returned`, `transferred` or exhausted-resource states, mechanically assert that the just-consumed action is absent from every recommendation surface and that completed cards use completed—not in-progress—actor labels.
25. Send natural-language equivalents of every governed button through free input. They must resolve to the same request id and authority action; an ambiguous phrase that could target multiple requests must preserve state and ask/allow clarification rather than guessing.
26. Commit an action, drop the response before the client receives it, and reconcile the committed event by the original action id. The UI must not report failure; retrying the same id three times must still leave one transaction and one event.
27. Fail personal-save persistence before receipt merge, then fail the first post-save acknowledgement. The receipt must remain pending through both faults and disappear only after a verified-save retry succeeds.
28. Disconnect at cursor N, commit one or more events, reconnect with `after_cursor=N`, and prove the client receives every missing event once in sequence without duplicating already rendered events.
29. Upgrade the server ruleset while a client holds an old view. The old submission must return `RULESET_MISMATCH` without a world write; the refreshed view must expose the new ruleset version and newly enumerated legal actions.
30. Expire/revoke the session and prove there is no fallback to request-body actor, raw query id, cached profile or anonymous writer.

## 13. Experience that must not be copied forward

Do not copy these historical shortcuts:

- a Pages deployment workflow inside a reusable game template;
- an absolute source-game API URL or production `VITE_*` base;
- client-supplied identity described as authenticated;
- public aid credited directly by the client;
- acknowledgement before private-save verification;
- world actions whose `action_id` changes on retry;
- local multi-actor mode presented as cross-user multiplayer;
- AI prose or analytics treated as shared state;
- personal relationship state written into the public event stream;
- one game's region names, thresholds, or civic-project rules hard-coded into the transport layer.

## 14. Gate for freezing a reusable multiplayer template

Before adding a multiplayer engine to this Skill, validate a second game that changes the shared mechanic, not merely the theme. It must exercise at least:

- concurrent currency or inventory transfer;
- stale choices after another player changes the scene or resource;
- reconnect and event-cursor recovery;
- shared scene/location authority versus private narrative context;
- important dialogue media attached once to a committed event;
- relationship visibility that separates public reputation from private relationship state;
- all current personal-RPG protections: payment consistency, grounded choices, scene/image/location consistency, protocol cleanup, action-preserving recovery, and immutable choice history.

Neighbor Help now satisfies the local and deployed authority portions for mechanism, continuity, receipt, cursor, privacy, save-envelope logic, browser concurrency and end-to-end public media. Its committed-outcome narration, post-commit fallback and stale-action removal have also passed a fresh real Telegram `claim → reentry → complete` transaction. It still does not satisfy backend-verifiable identity, two physical authenticated devices, receiving-runtime multi-instance writes or the real platform personal-save failure path. After those rows pass, freeze a separate reusable shared-world engine or extension Skill. Keep the backend adapter abstract and keep deployment outside the handoff package.

The bundled action-authority lab is the preferred abstract adapter starting point because it omits client actor ids and keeps conflict, unknown-outcome reconciliation and retry behind one bound gateway. It does not change the freeze gate: adapt the contract in the receiving authority runtime, inject platform-verified identity, run multi-instance writes and two physical authenticated clients, and fail the real personal cloud-save path before promoting it from optional experiment to default shared-world engine.
