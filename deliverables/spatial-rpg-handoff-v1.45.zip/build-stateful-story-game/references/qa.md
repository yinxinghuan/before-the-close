# AI RPG QA

Run the shared checks below for both templates, then the mode-specific checks at the end.

For a final source handoff, first run the mechanical four-layer contract in [acceptance.md](acceptance.md). The checklist below explains scenario coverage and guides manual review; it is not a substitute for a `full` acceptance report.

## Content and freedom

- Opening background is visible before the first image finishes.
- The opening contains 4–7 chronological player-lived beats rather than one recap paragraph.
- Before the final opening beat, quick replies, free input and numeric shortcuts cannot submit an action; the final beat removes the page control and reveals the choices.
- Three opening choices are concrete and meaningfully different.
- Submit a free-form action that rejects every suggestion; the world responds without forcing the player back.
- Every response's buttons match the options described in visible prose.
- Inject a mixed response containing valid actions plus choices that name an unseen person, job, institution, stale location, and destination. Assert invalid choices are removed individually, every grounded choice remains, a one-choice tray is not padded, and four or five valid choices are not truncated to three. If none remain in a calm cinematic turn, assert the tray stays empty across a second failure while free input remains usable; in active danger assert every deterministic recovery action names the same visible threat.
- Inject generic placeholders in both languages: observe changes, wait, discuss what to do, continue the current task, try another way, plus an immediate retry-prefixed copy of the selected action. Assert all are removed while concrete entity-bound actions remain.
- Replay the raw candidate set before and after grounding. A future action may use verbs that were not copied from the preceding prose; keep it when it refers to an established person, place, object or other concrete current evidence. Reject only a provably stale or invented reference, never merely a paraphrase.
- Assert the long-term objective cannot become a quick-reply button by exact or near-exact restatement. After a real arrival, if one or more local actions exist, suppress an immediate return to the place just left; retain that return when it is the only feasible exit.
- Force a true payment/location/objective inconsistency through the original response and one repair. Assert the draft is quarantined, location/objective/stats/items/time remain unchanged, the failed recommendation is removed, and trustworthy siblings remain in their original order. Reject a second sibling and assert the tray strictly shrinks rather than recreating the same choice set. When no sibling remains, assert quick replies stay empty across reload while free input remains available; no objective or synthetic recovery button may appear. Separately remove every generated reply from an otherwise valid consequence: assert the consequence commits without a recovery scene and choices derive from authoritative state. During active danger assert no older sibling survives and every fallback button names the exact current threat.
- Load a legacy generic consistency-recovery save, a nested duplicate loop, and a factless old save. Assert the original failed action remains auditable but is absent from the executable tray, prior trustworthy siblings are recovered from the immutable choice record, old synthetic menus disappear, and a second migration pass is byte-for-byte unchanged.
- Register one deterministic authored label with a narrow location/character/job scope. Assert it executes inside that scope and is both non-executable and filtered from generated recommendations outside it. Also author a trusted turn that visibly introduces the required character or job and assert its own follow-up survives even though the pre-turn snapshot lacked that entity. After a no-progress generated turn, reject semantic same-object rewrites such as inspect → touch/recheck while retaining a materially distinct grounded action.
- Trigger both a generated `map_update` and a governed domain map effect. Assert that a visible world-native transition anchor appears before destination prose and choices.
- Confirm the choice-area context is the latest visible consequence, not the long-term objective or generic instruction text.
- When structured choices are absent, trustworthy numbered/bulleted choices recover; otherwise the UI shows no fabricated generic choice.
- No fixed turn limit. `session_end` remains continuable unless a true ending is defined.

## State and persistence

- Every displayed stat update respects min/max and `maxDelta`.
- Refresh restores location, objective, stats, map, items, relationships, timeline, and current choices.
- Every historical scene keeps the exact choice set that was shown at that moment; the article record and live bottom tray derive from the same labels.
- A second save does not overwrite data from the first save through stale `savedData`.
- The exported game has a UUID v4 and save namespace different from the mother and all siblings.
- Restart has confirmation, cancels safely, invalidates old image work, and resets only this world.
- Recover a save made before the current schema and confirm choices, companions, inventory, and danger phase normalize without data loss.
- Recover a save without `sceneLocation`; assert it falls back to `location`. Then enter a named sublocation and assert the header, state, image binding and next choices keep the exact scene while the map node remains unchanged.
- Reopen the standalone after a previous shared-template local key and confirm it migrates into this game's isolated key.
- Reload a progressed stateful save and press Continue. The viewport begins at the latest player action (or nearest readable fallback), shows its consequence without scrolling upward, keeps current choices available, and never lands inside the bottom reading spacer.

## World details

- Character, place, item, and journal rows open detailed views.
- The level-one header exposes the relationship folio as an icon-only 44×44 control using the bound notebook glyph; it opens the relationship tab directly and stays optically aligned with text/audio controls without a visible “关系” label.
- The relationship tab begins with a visible summary, groups active companions separately from other known people, and keeps the player journey in its own section.
- Items show count/rarity, effect and limitation, lore/provenance, and visible metrics.
- Opening inventory starts image generation after the inventory is opened; there is no manual “generate” chore.
- Item art matches the Cartridge's scene material and never uses the player's avatar as the object reference.
- A narrated acquisition without a structured command does not silently appear in the bag; a confirmed acquisition command persists exactly once.
- Meeting a second group never deletes the current party; explicit join and leave actions update stable ids predictably.
- A fixed future character marked `hiddenUntilIntroduced` is absent from the opening roster, relationship UI, objectives and choices.
- The first named choice or speaker label for a character occurs only after visible prose has shown their form/action, explained the everyday source of their name, and established their present intent or relationship.
- After that debut, `character_update` creates or reveals the authored stable id; a visible decision to travel together additionally emits `party_change add`.
- A legacy save that merely preloaded a hidden character is repaired without deleting any character already mentioned, related, departed or in the party.

## Danger and failure

- Ordinary exploration reaches a warning inside the configured safe-turn range.
- For every map node, run multiple encounter cycles and assert every selected threat is allowed by `threatLocations`; include at least one location-exclusive threat per node and one global fallback where the world design needs it.
- Inject a scheduled warning beside unrelated visible prose and unrelated choices. Assert `test:danger-grounding` rejects it before commit and reducer defense leaves danger authority unchanged. Then inject the exact visible threat, exact phase/kind encounter tag and threat-bound choices as a positive control.
- Feed a deterministic authored consequence on a calm turn whose danger cadence is due. Assert the authored beat completes without a second scheduled crisis, then remains eligible for danger on a later ordinary turn.
- Warning, confrontation, and resolution persist across refresh.
- Repeating the same action produces the same d20 and outcome.
- AI-proposed rolls never override the local result.
- Failure or costly success changes a persisted stat, item, route, or character condition; fallback cost applies when AI omits one.
- `physicalCombat: none` worlds produce social, environmental, logistical, or economic crises instead of fights.
- After resolution, choices remain present and the story cannot deadlock.

## Images and scrolling

- AI scene proposal wins when present.
- Local director creates a scene for guaranteed triggers and after the configured quiet-turn limit.
- One response produces at most one scene image decision.
- With no perspective policy, important dialogue and cadence retain the historical observer default. With `balanced`, run at least 20 suitable ordinary decisions and require 40–60% first-person; assert both perspectives occur. With `first-person-preferred`, verify the configured bias without allowing 100% first-person.
- Every first-person decision records `perspective=first-person`, contains the player-eye/no-protagonist-body contract, and omits the player avatar reference. An explicit observer/third-person proposal and a player-visible full-action shot must not be converted to first-person.
- For every Cartridge with `presetEventDirector`, verify local coverage, unique ids, no immediate repeat, exact deterministic resolution, one-to-five grounded follow-ups, and suppression during an objective, reply context, open job or danger. Audit authored first/third-person distribution separately.
- Images render inline at their event id, update in place, and do not steal scroll position.
- Stateful resume targets a semantic readable block rather than `scrollHeight`; the intentional bottom reading spacer is never a resume destination.
- Image generation/retry never blocks another story action.
- Entry image is a native wide scene; cover is square; poster is 1024×1024 and English-only.

For cinematic games, replace the wide-entry expectation with a native 4:5 entry image that depicts the exact opening beat.

## Language, identity, and audio

- System language chooses zh/en; a clearly typed language can switch subsequent UI/replies.
- Stable ids preserve known world state across language changes; old prose is not mistranslated retroactively.
- Platform profile uses `data.name` and `data.head_url`; platform outside fallback name is `AlterU`.
- Real HTTPS avatar can guide protagonist scene generation; fallback U avatar is not sent as img2img.
- Environmental, object-only and other-character-led images omit `ref_url`; only protagonist-owned dominant-action images include the real avatar reference.
- A multi-character test proves that an incidental/background player does not cause a companion or animal to inherit any reference-derived face, silhouette, covering, costume, color, or body trait.
- Generate a new 1:1 faceless full-body fixture outside the game asset library (for example a completely covered sheet-ghost figure). Prove the opening and one later player-owned shot preserve the covering, silhouette, face absence, and lack of exposed limbs; do not use a repository fake-user avatar for this test.
- Audio only unlocks from a gesture, sound preference persists locally, backgrounding suspends it, and failure is non-blocking.
- For a hybrid soundtrack, verify one unmute produces one recorded playback start; A music waits at least thirty seconds after its natural ending before returning; every ambience recording plays once per location visit and stays silent after completion; a stable location override wins while an unknown/dynamic place uses the default ambience; mute/page resume continues an unfinished ambience but never restarts a completed one; a genuine location revisit permits one new play; every event cue is one-shot and restore/reconnect/rerender never replays it; missing or autoplay-rejected media restores synthesized/silent fallback; hide/show and unmount clear media and timers.
- Record full-file human listening separately from mechanical evidence. MP3/44.1 kHz/stereo, decoded duration, clipping/true peak, loudness, leading/trailing silence and built relative asset paths must pass before handoff; a successful API response alone is not audio approval.

## Payment consent and direction

- Replay an exploratory action such as “询问房费 / ask the room rate” against a draft that claims the player paid. The turn must be rejected before save and coin must remain unchanged.
- Replay “把钱全部花完 / spend all my money” with no purchase object. It must be clarified locally or rejected before save, make zero balance change, and not create an item, room, ticket or other invented purchase.
- Replay a hidden negative coin command with no visible purchase and no player authorization. It must also be rejected.
- Replay an explicitly authorized purchase. Visible exact amount, negative coin delta, affordability check and acquired fact/item/route must commit as one transaction.
- For every consumable or paid action, replay at least one natural paraphrase that should enter the same local rule and one mention/negation that must not spend (`不要使用`, `询问用途`, `do not use`, `ask what it does`).
- Replay future-tense payment verbs in both languages (`will pay`, `about to receive`, `plans to hand`, `准备领取`, `稍后递给`, `明早支付`). Assert neither canonicalization nor legacy repair settles or credits them before a visible completed transfer.
- Include the regression phrase “你用这枚硬币支付……” with an erroneous positive widget. The validator must identify both the spend and the reversed direction; canonicalization may correct it only when the player action explicitly authorized payment.

## Layout and release handoff

- Test 320×568 and 390×844 mobile, plus 1024×768 and 1440×900 desktop.
- The four persistent world-drawer tabs use the shared 24×24, 1.7 px round-cap/round-join outline SVG system: connected people for relationships, folded route with nodes for map, buckled travel bag for inventory, and bound folio for journal. They must match the level-one header controls in optical weight and detail; do not substitute Emoji, text glyphs, filled clip-art, or mixed icon families.
- On desktop the Shell remains readable and centered without narrow text caused by `100vw` internals.
- Quick replies size to content, scroll horizontally, and use `onClick` inside the scroll container.
- Platform layout assumes no visitor banner. External guest mode remains usable with the banner visible.
- `npm run build` succeeds, Vite `base` is `./`, and built asset paths are relative.
- `--handoff-ready` verifies source, poster, notices, UUID, isolated save namespace, danger tests, and build output without assuming a deployment system.
- This Skill does not deploy. The handoff report must say which separate publisher is expected to consume the verified project.

## Cinematic Civic mode

- Capture the first, a middle and the final opening beat at 320×568 and 390×844; mechanically assert that `.st-composer` is absent before the final beat.
- Every successful action produces one and only one scene-image decision.
- The opening image matches the opening location, action premise, cast, and time; it is not a generic style plate.
- Visible phase order is `decision -> resolving -> result -> decision`.
- During `result`, stale choices and the next decision premise are hidden.
- After the player advances, the new premise and its choices appear together.
- Captions that exceed the visual budget paginate by readable sentences; no meaningful suffix is lost behind an ellipsis.
- Speaker captions show a stable identity plate and full name.
- Choice buttons are horizontally scrollable on mobile, submit once on click, and remain visibly distinct from disabled controls.
- Civic and Living branches share the same reducer, save, UUID, story state, and phase behavior.
- The fixed 4:5 scene composes behind the dashboard without pushing the subject unnaturally low; verify both 320×568 and 390×844.
- Player-owned generation uses the original public avatar URL in edit mode, requests the Cartridge scene size separately, and performs no avatar upload. Verify immediate, delayed, transient-failure, and one-full-timeout live-profile arrival; no request may be sent without `ref_url` while platform identity is still resolving.
- Player-led dominant actions use the player reference. NPC-led, group-led, animal, environmental, and object-only shots do not.
- In a multi-person scene, the player's complete visual identity cannot move to a companion, family member, background figure, reflection, mask, or animal.
- A milestone video may queue only after its still image is ready and cannot block choices, save, or restart.

## Asynchronous shared-world extension

- Run concurrency against the real authority service as well as the pure reducer; a local two-actor simulation is evidence, not production multiplayer proof.
- Two authenticated sessions race for one unique item; exactly one action commits and the loser receives a visible cause plus currently valid recovery choices.
- Repeating one stable `action_id` does not change the world twice; reconnecting from a prior cursor yields each committed event once and in order.
- Public custody never uses private `receipt_pending`; the private receipt mirror persists, reads back and acknowledges once.
- Story, relationships and shared-item mirror coexist in one namespaced personal-save envelope; alternating updates and namespace clears never erase sibling data.
- Public snapshots/events contain no private relationship values, unpublished prose, private dialogue or free-input text.
- Important dialogue media attaches only after authority commit, with one active attachment per event, only by the event actor, and only from the AlterU CDN. Reject a visually bad attachment through an immutable reason-coded tombstone, then prove one clean replacement becomes active without deleting history.
- Static and runtime RPG images use AlterU Media Service rather than prototype-only image generation. Pixel QA checks pseudotext, signatures/logos, country-specific cues, current location, complete visual identity and exact scarce-object count.
- Record separately which rows passed locally and which passed against a deployed Durable Object; do not collapse them into one “multiplayer passed” claim.
- Verify pointer, keyboard Enter/Space, external-guest and `prefers-reduced-motion` states on the deployed build; a touch-only screenshot is not enough.
