# Template selection

Choose the interaction shell before authoring the Cartridge. Both templates share authoritative state, stable ids, persistence, danger, bilingual content, avatar identity rules, and independent export. The choice is about reading rhythm and media cost, not about whether the story can be complex.

## Stateful conversation

Use `stateful` when the player should read an accumulating journey and revisit prior events.

- Best for free exploration, relationship simulation, long conversations, inventories, world journals, and lower media cost.
- Images are inline with the event that requested them. AI proposes images and the local director fills important gaps.
- The timeline can grow long; returning players get Continue/Restart and a latest-anchor jump.
- Default entry art is landscape, approximately 16:9.
- Bundled engine: `assets/stateful-story-template/`.

## Cinematic Civic

Use `cinematic` when each successful action should feel like a new illustrated shot and reading must stay short.

- Best for guided adventures, emotional journeys, danger, dialogue, and visible action with one image per step.
- The scene image occupies a fixed 4:5 stage. Results appear first; the next decision context and choices appear only after the player advances.
- The Modern Civic System is the default recommended presentation. The same engine also retains the Living Storyboard branch for an A/B comparison.
- Text must be concise and paginated rather than truncated. Choices remain synchronized with the current decision premise.
- The player's original public HTTPS avatar is passed directly as an edit reference only for player-owned dominant-action shots. Scene output size is independent from the avatar's source aspect ratio; do not crop and re-upload the avatar. The reference owns the actor's complete visible identity—including faceless, covered, nonhuman, animal, or object-like forms—not merely a face.
- Milestone video is optional and must never block play.
- Bundled engine: `assets/cinematic-story-template/`.

## Decision rule

Recommend `cinematic` only when the user explicitly values image-per-step pacing or low reading volume and accepts higher generation traffic. Otherwise recommend `stateful` for the more extensible long-form default.

Do not combine both shells inside a newly exported game unless the user is deliberately running an A/B test. If comparing them, keep the same Cartridge, UUID, save namespace, and reducer so the test changes presentation rather than gameplay.
