#!/usr/bin/env node
import { createHash } from 'node:crypto'
import { createReadStream } from 'node:fs'
import { access, cp, lstat, mkdtemp, mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises'
import { spawn } from 'node:child_process'
import os from 'node:os'
import path from 'node:path'
import process from 'node:process'

const startedAt = new Date()

function parseArgs(argv) {
  const result = new Map()
  for (let index = 0; index < argv.length; index += 1) {
    const key = argv[index]
    if (!key.startsWith('--')) throw new Error(`Unexpected argument: ${key}`)
    if (key === '--keep-workdir') {
      result.set(key, true)
      continue
    }
    const value = argv[index + 1]
    if (!value || value.startsWith('--')) throw new Error(`Missing value for ${key}`)
    result.set(key, value)
    index += 1
  }
  return result
}

const options = parseArgs(process.argv.slice(2))
const skillRoot = path.resolve(options.get('--skill') || path.join(import.meta.dirname, '..'))
const scope = options.get('--scope') || 'full'
if (!['core', 'full', 'package'].includes(scope)) throw new Error('--scope must be core, full, or package')
if (scope === 'package' && !options.get('--package')) throw new Error('--scope package requires --package <zip-or-directory>')

const reportPath = options.get('--report') ? path.resolve(options.get('--report')) : null
const keepWorkdir = Boolean(options.get('--keep-workdir'))
const workRoot = await mkdtemp(path.join(os.tmpdir(), 'alteru-rpg-acceptance-'))
const gates = []
const exportsEvidence = []
let packageEvidence = null

function outputTail(value, limit = 12000) {
  const text = String(value || '')
  return text.length <= limit ? text : `…${text.slice(-limit)}`
}

function commandLabel(command, args) {
  return [command, ...args].map((part) => /\s/.test(part) ? JSON.stringify(part) : part).join(' ')
}

function runCommand(command, args, { cwd, env = {}, timeoutMs = 240000 } = {}) {
  return new Promise((resolve, reject) => {
    const label = commandLabel(command, args)
    const child = spawn(command, args, {
      cwd,
      env: { ...process.env, ...env },
      stdio: ['ignore', 'pipe', 'pipe'],
    })
    let stdout = ''
    let stderr = ''
    child.stdout.on('data', (chunk) => { stdout = outputTail(stdout + chunk) })
    child.stderr.on('data', (chunk) => { stderr = outputTail(stderr + chunk) })
    const timeout = setTimeout(() => {
      child.kill('SIGTERM')
      setTimeout(() => child.kill('SIGKILL'), 1500).unref()
      reject(new Error(`${label} timed out after ${timeoutMs}ms\n${outputTail(stderr || stdout)}`))
    }, timeoutMs)
    child.on('error', (error) => {
      clearTimeout(timeout)
      reject(new Error(`${label} failed to start: ${error.message}`))
    })
    child.on('close', (code, signal) => {
      clearTimeout(timeout)
      if (code === 0) resolve({ command: label, stdout, stderr })
      else reject(new Error(`${label} exited ${code ?? signal}\n${outputTail(stderr || stdout)}`))
    })
  })
}

async function runGate(id, label, fn) {
  const gateStarted = Date.now()
  process.stdout.write(`\n[acceptance] START ${id} · ${label}\n`)
  try {
    const evidence = await fn()
    gates.push({ id, label, required: true, status: 'pass', durationMs: Date.now() - gateStarted, evidence: evidence ?? null })
    process.stdout.write(`[acceptance] PASS  ${id}\n`)
    return true
  } catch (error) {
    gates.push({ id, label, required: true, status: 'fail', durationMs: Date.now() - gateStarted, error: outputTail(error?.stack || error) })
    process.stderr.write(`[acceptance] FAIL  ${id} · ${error?.message || error}\n`)
    return false
  }
}

async function exists(filePath) {
  try { await access(filePath); return true } catch { return false }
}

async function copyTemplate(source, target) {
  await cp(source, target, {
    recursive: true,
    filter: (entry) => {
      const name = path.basename(entry)
      if (name === 'node_modules' || name === 'dist') return false
      if (entry.includes(`${path.sep}_qa${path.sep}ui${path.sep}`)) return false
      return true
    },
  })
}

async function loadJson(filePath) {
  return JSON.parse(await readFile(filePath, 'utf8'))
}

async function listTree(root, relative = '') {
  const current = path.join(root, relative)
  const names = await readdir(current)
  const result = []
  for (const name of names) {
    const rel = path.join(relative, name)
    const info = await lstat(path.join(root, rel))
    result.push({ path: rel, info })
    if (info.isDirectory()) result.push(...await listTree(root, rel))
  }
  return result
}

async function sha256(filePath) {
  return new Promise((resolve, reject) => {
    const hash = createHash('sha256')
    const stream = createReadStream(filePath)
    stream.on('data', (chunk) => hash.update(chunk))
    stream.on('error', reject)
    stream.on('end', () => resolve(hash.digest('hex')))
  })
}

async function startServer(root, port) {
  const child = spawn('npm', ['run', 'dev', '--', '--host', '127.0.0.1', '--port', String(port), '--strictPort'], {
    cwd: root,
    env: process.env,
    stdio: ['ignore', 'pipe', 'pipe'],
  })
  let logs = ''
  child.stdout.on('data', (chunk) => { logs = outputTail(logs + chunk, 6000) })
  child.stderr.on('data', (chunk) => { logs = outputTail(logs + chunk, 6000) })
  let closed = false
  child.on('close', () => { closed = true })

  const deadline = Date.now() + 30000
  while (Date.now() < deadline) {
    if (closed) throw new Error(`Vite server on ${port} exited before readiness\n${logs}`)
    try {
      const response = await fetch(`http://127.0.0.1:${port}/`, { signal: AbortSignal.timeout(1200) })
      if (response.ok) return { child, logs: () => logs }
    } catch { /* retry until deadline */ }
    await new Promise((resolve) => setTimeout(resolve, 250))
  }
  child.kill('SIGTERM')
  throw new Error(`Vite server on ${port} did not become ready\n${logs}`)
}

async function stopServer(server) {
  if (!server?.child || server.child.exitCode !== null) return
  await new Promise((resolve) => {
    const hardStop = setTimeout(() => {
      server.child.kill('SIGKILL')
      resolve()
    }, 2000)
    server.child.once('close', () => {
      clearTimeout(hardStop)
      resolve()
    })
    server.child.kill('SIGTERM')
  })
}

function fixtureDocs() {
  return {
    'requirements.md': '# Overview\nAcceptance fixture.\n\n# Visual Design\nTemplate UI.\n\n# Game Mechanics\nTemplate rules.\n\n# Controls\nPointer and keyboard.\n\n# Win / Lose Conditions\nContinuable test world.\n\n# Sound Effects\nTemplate audio.\n',
    'visual.md': '# Visual contract\nAcceptance fixture using the frozen template visual system.\n',
    'technical.md': '# 技术栈\nReact, TypeScript, Vite.\n\n# 目录结构\n`src/story` is the engine.\n\n# 核心模块\nReducer, turn pipeline, media and persistence.\n\n# 扩展点\nEdit the single exported Cartridge.\n',
  }
}

async function writeFixtureDocs(target) {
  const docRoot = path.join(target, 'doc')
  await mkdir(docRoot, { recursive: true })
  for (const [name, content] of Object.entries(fixtureDocs())) await writeFile(path.join(docRoot, name), content)
}

async function readExportIdentity(target) {
  const gameIdSource = await readFile(path.join(target, 'src/game-id.ts'), 'utf8')
  const engineSource = await readFile(path.join(target, 'src/story/useStoryEngine.ts'), 'utf8')
  return {
    uuid: gameIdSource.match(/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/i)?.[0] || null,
    saveNamespace: engineSource.match(/useGameSave<PersistedStoryData>\(['"]([^'"]+)['"]\)/)?.[1] || null,
  }
}

async function scanPackageSecrets(root) {
  const tree = await listTree(root)
  const findings = []
  const patterns = [
    /AKIA[0-9A-Z]{16}/g,
    /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g,
    /(?:AWS_SECRET_ACCESS_KEY|R2_SECRET_ACCESS_KEY|GITHUB_TOKEN|GH_TOKEN)\s*[:=]\s*['"][A-Za-z0-9/+_.=-]{16,}['"]/gi,
    /gh[pousr]_[A-Za-z0-9]{30,}/g,
  ]
  const textExtensions = new Set(['.md', '.json', '.yaml', '.yml', '.js', '.mjs', '.cjs', '.ts', '.tsx', '.css', '.less', '.html', '.txt'])
  for (const entry of tree) {
    if (!entry.info.isFile() || entry.info.size > 2_000_000 || !textExtensions.has(path.extname(entry.path).toLowerCase())) continue
    const source = await readFile(path.join(root, entry.path), 'utf8')
    for (const pattern of patterns) {
      pattern.lastIndex = 0
      if (pattern.test(source)) findings.push(entry.path)
    }
  }
  return [...new Set(findings)]
}

const contract = await loadJson(path.join(skillRoot, 'assets/acceptance-contract.json'))
const nodeMajor = Number(process.versions.node.split('.')[0])

await runGate('contract', 'Skill structure and acceptance contract', async () => {
  if (contract.schemaVersion !== 1) throw new Error(`Unsupported acceptance schema: ${contract.schemaVersion}`)
  if (contract.deploymentIncluded !== false) throw new Error('Acceptance contract must keep deploymentIncluded=false')
  if (nodeMajor < contract.minimumNodeMajor) throw new Error(`Node ${contract.minimumNodeMajor}+ required; found ${process.version}`)
  for (const required of ['SKILL.md', 'agents/openai.yaml', 'scripts/scaffold.mjs', 'scripts/validate-game.mjs', 'scripts/acceptance.mjs', 'references/acceptance.md']) {
    if (!(await exists(path.join(skillRoot, required)))) throw new Error(`Missing required Skill file: ${required}`)
  }
  const frontmatter = await readFile(path.join(skillRoot, 'SKILL.md'), 'utf8')
  if (!frontmatter.startsWith('---\n') || !/\nname:\s*build-stateful-story-game\n/.test(frontmatter) || !/\ndescription:\s*/.test(frontmatter)) {
    throw new Error('SKILL.md frontmatter is invalid')
  }
  return { node: process.version, schemaVersion: contract.schemaVersion, deploymentIncluded: false }
})

const modeWorkspaces = new Map()
if (scope !== 'package') {
  for (const [experiment, config] of Object.entries(contract.experiments || {})) {
    const source = path.join(skillRoot, config.path)
    const target = path.join(workRoot, `experiment-${experiment}`)
    const copied = await runGate(`${experiment}.copy`, `${experiment} clean experiment copy`, async () => {
      await copyTemplate(source, target)
      return { source, target }
    })
    if (!copied) continue
    const installed = await runGate(`${experiment}.install`, `${experiment} locked dependency install`, async () => {
      const result = await runCommand('npm', ['ci'], { cwd: target })
      return { command: result.command, output: outputTail(result.stdout || result.stderr, 3000) }
    })
    if (!installed) continue
    const pkg = await loadJson(path.join(target, 'package.json'))
    const missing = config.requiredScripts.filter((script) => !pkg.scripts?.[script])
    await runGate(`${experiment}.test-discovery`, `${experiment} required test discovery`, async () => {
      if (missing.length) throw new Error(`Missing experiment scripts: ${missing.join(', ')}`)
      return { requiredScripts: config.requiredScripts }
    })
    for (const script of config.requiredScripts) {
      await runGate(`${experiment}.${script}`, `${experiment} ${script}`, async () => {
        const result = await runCommand('npm', ['run', script], { cwd: target })
        return { command: result.command, output: outputTail(result.stdout || result.stderr, 3000) }
      })
    }
  }

  for (const [mode, config] of Object.entries(contract.modes)) {
    const source = path.join(skillRoot, config.template)
    const target = path.join(workRoot, `mother-${mode}`)
    const copied = await runGate(`${mode}.copy`, `${mode} clean mother-template copy`, async () => {
      await copyTemplate(source, target)
      return { source, target }
    })
    if (!copied) continue
    modeWorkspaces.set(mode, target)

    const installed = await runGate(`${mode}.install`, `${mode} locked dependency install`, async () => {
      const result = await runCommand('npm', ['ci'], { cwd: target })
      return { command: result.command, output: outputTail(result.stdout || result.stderr, 3000) }
    })
    if (!installed) continue

    const pkg = await loadJson(path.join(target, 'package.json'))
    const browserScripts = new Set(config.browserScripts)
    const testScripts = Object.keys(pkg.scripts || {}).filter((name) => name.startsWith('test:'))
    const missingBrowser = config.browserScripts.filter((name) => !testScripts.includes(name))
    if (missingBrowser.length) {
      await runGate(`${mode}.test-discovery`, `${mode} test discovery`, async () => { throw new Error(`Missing browser scripts: ${missingBrowser.join(', ')}`) })
    }
    const coreScripts = testScripts.filter((name) => !browserScripts.has(name)).sort()
    await runGate(`${mode}.test-discovery`, `${mode} automatic test discovery`, async () => ({
      coreScripts,
      browserScripts: config.browserScripts,
      discovered: testScripts.length,
    }))
    for (const script of coreScripts) {
      await runGate(`${mode}.${script}`, `${mode} ${script}`, async () => {
        const result = await runCommand('npm', ['run', script], { cwd: target })
        return { command: result.command, output: outputTail(result.stdout || result.stderr, 3000) }
      })
    }
    await runGate(`${mode}.build`, `${mode} production build`, async () => {
      const result = await runCommand('npm', ['run', 'build'], { cwd: target })
      const html = await readFile(path.join(target, 'dist/index.html'), 'utf8')
      if (/(?:src|href)=["']\/(?!\/)/.test(html)) throw new Error('dist/index.html contains a root-absolute asset path')
      return { command: result.command, output: outputTail(result.stdout || result.stderr, 3000), relativeAssets: true }
    })
  }
}

if (scope === 'full') {
  for (const [mode, config] of Object.entries(contract.modes)) {
    const target = modeWorkspaces.get(mode)
    if (!target) continue
    await runGate(`${mode}.browser`, `${mode} real-browser regression matrix`, async () => {
      const server = await startServer(target, config.browserPort)
      const completed = []
      try {
        for (const script of config.browserScripts) {
          const result = await runCommand('npm', ['run', script], {
            cwd: target,
            env: mode === 'cinematic' ? { STORY_QA_URL: `http://127.0.0.1:${config.browserPort}/` } : {},
            timeoutMs: 360000,
          })
          completed.push({ script, command: result.command, output: outputTail(result.stdout || result.stderr, 2500) })
        }
      } finally {
        await stopServer(server)
      }
      return { port: config.browserPort, completed }
    })
  }

  for (const [mode, config] of Object.entries(contract.modes)) {
    const template = modeWorkspaces.get(mode)
    if (!template) continue
    const fixture = config.exportFixture
    const target = path.join(workRoot, `export-${mode}`)
    await runGate(`${mode}.export`, `${mode} fresh isolated export`, async () => {
      await mkdir(target, { recursive: true })
      await writeFixtureDocs(target)
      const result = await runCommand(process.execPath, [
        path.join(skillRoot, 'scripts/scaffold.mjs'),
        '--mode', mode,
        '--game-id', fixture.gameId,
        '--title', fixture.title,
        '--cartridge-file', fixture.cartridgeFile,
        '--zh-export', fixture.zhExport,
        '--en-export', fixture.enExport,
        '--template', template,
        '--target', target,
      ], { cwd: skillRoot })
      const identity = await readExportIdentity(target)
      if (!identity.uuid || !identity.saveNamespace) throw new Error('Fresh export did not produce an isolated UUID and save namespace')
      exportsEvidence.push({ mode, target, ...identity })
      return { command: result.command, ...identity }
    })
    await runGate(`${mode}.export-install`, `${mode} exported locked dependency install`, async () => {
      const result = await runCommand('npm', ['ci'], { cwd: target })
      return { command: result.command, output: outputTail(result.stdout || result.stderr, 2500) }
    })
    await runGate(`${mode}.export-validate`, `${mode} exported tests and production build`, async () => {
      const result = await runCommand(process.execPath, [path.join(skillRoot, 'scripts/validate-game.mjs'), target, '--test', '--build', `--${mode}`], { cwd: skillRoot, timeoutMs: 360000 })
      if (!result.stdout.includes('"deploymentIncluded": false')) throw new Error('Export validator did not preserve deploymentIncluded=false')
      return { command: result.command, output: outputTail(result.stdout || result.stderr, 5000), deploymentIncluded: false }
    })
  }

  await runGate('export.isolation', 'Fresh exports have unique UUIDs and save namespaces', async () => {
    if (exportsEvidence.length !== Object.keys(contract.modes).length) throw new Error('Not every mode produced export identity evidence')
    if (new Set(exportsEvidence.map((item) => item.uuid)).size !== exportsEvidence.length) throw new Error('Fresh exports reused a UUID')
    if (new Set(exportsEvidence.map((item) => item.saveNamespace)).size !== exportsEvidence.length) throw new Error('Fresh exports reused a save namespace')
    return { exports: exportsEvidence.map(({ mode, uuid, saveNamespace }) => ({ mode, uuid, saveNamespace })) }
  })
}

if (options.get('--package')) {
  await runGate('package.integrity', 'Handoff package integrity and boundary', async () => {
    const packagePath = path.resolve(options.get('--package'))
    const info = await lstat(packagePath)
    let packageRoot = packagePath
    let digest = null
    if (info.isFile()) {
      if (path.extname(packagePath).toLowerCase() !== '.zip') throw new Error('--package must be a ZIP or an extracted directory')
      await runCommand('unzip', ['-tq', packagePath], { cwd: workRoot })
      packageRoot = path.join(workRoot, 'package')
      await mkdir(packageRoot)
      await runCommand('unzip', ['-q', packagePath, '-d', packageRoot], { cwd: workRoot })
      digest = await sha256(packagePath)
    }
    const extractedTop = (await readdir(packageRoot)).sort()
    if (extractedTop.length === 1) {
      const wrapped = path.join(packageRoot, extractedTop[0])
      if ((await lstat(wrapped)).isDirectory()) packageRoot = wrapped
    }
    const topLevel = (await readdir(packageRoot)).sort()
    const disallowedTop = topLevel.filter((name) => !contract.handoff.allowedTopLevel.includes(name))
    const missingTop = contract.handoff.allowedTopLevel.filter((name) => !topLevel.includes(name))
    if (disallowedTop.length || missingTop.length) throw new Error(`Invalid package top level; missing=${missingTop.join(',') || 'none'} extra=${disallowedTop.join(',') || 'none'}`)
    const packagedSkill = path.join(packageRoot, 'build-stateful-story-game')
    const tree = await listTree(packageRoot)
    const bad = tree.filter((entry) => {
      const normalized = `/${entry.path.split(path.sep).join('/')}${entry.info.isDirectory() ? '/' : ''}`
      return entry.info.isSymbolicLink()
        || contract.handoff.forbiddenNames.includes(path.basename(entry.path))
        || contract.handoff.forbiddenPathFragments.some((fragment) => normalized.includes(fragment))
    }).map((entry) => entry.path)
    if (bad.length) throw new Error(`Forbidden handoff paths: ${bad.slice(0, 20).join(', ')}`)
    for (const required of ['SKILL.md', 'agents/openai.yaml', 'scripts/acceptance.mjs', 'assets/acceptance-contract.json', 'references/acceptance.md']) {
      if (!(await exists(path.join(packagedSkill, required)))) throw new Error(`Packaged Skill missing ${required}`)
    }
    const packagedContract = await loadJson(path.join(packagedSkill, 'assets/acceptance-contract.json'))
    if (packagedContract.deploymentIncluded !== false) throw new Error('Packaged acceptance contract includes deployment')
    const findings = await scanPackageSecrets(packageRoot)
    if (findings.length) throw new Error(`Potential public credentials in package: ${findings.join(', ')}`)
    packageEvidence = { path: packagePath, sha256: digest, topLevel, fileCount: tree.filter((entry) => entry.info.isFile()).length, deploymentIncluded: false }
    return packageEvidence
  })
}

const failed = gates.filter((gate) => gate.status === 'fail')
const status = failed.length ? 'fail' : scope === 'core' ? 'partial' : 'pass'
const finishedAt = new Date()
const report = {
  schemaVersion: 1,
  status,
  scope,
  startedAt: startedAt.toISOString(),
  finishedAt: finishedAt.toISOString(),
  durationMs: finishedAt.getTime() - startedAt.getTime(),
  environment: { node: process.version, platform: process.platform, arch: process.arch },
  skillRoot,
  workRoot: keepWorkdir ? workRoot : null,
  deploymentIncluded: false,
  summary: { passed: gates.length - failed.length, failed: failed.length, total: gates.length },
  exports: exportsEvidence.map(({ mode, uuid, saveNamespace }) => ({ mode, uuid, saveNamespace })),
  package: packageEvidence,
  gates,
}

if (reportPath) {
  await mkdir(path.dirname(reportPath), { recursive: true })
  await writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`)
}

// Chromium/Vite child processes can release their final cache file a fraction
// after close on macOS. Let fs.rm retry ENOTEMPTY/EBUSY instead of turning an
// otherwise complete acceptance run into a cleanup-only failure.
if (!keepWorkdir) await rm(workRoot, { recursive: true, force: true, maxRetries: 8, retryDelay: 125 })

const summary = `\n${JSON.stringify({ status, scope, report: reportPath, passed: report.summary.passed, failed: report.summary.failed, deploymentIncluded: false }, null, 2)}\n`
// Browser runners may leave an inherited stdio handle alive even after their
// npm parent has closed. Flush the final report, then terminate with the gate
// result so CI and package callers never hang after a completed acceptance.
await new Promise((resolve) => process.stdout.write(summary, resolve))
process.exit(failed.length ? 1 : 0)
