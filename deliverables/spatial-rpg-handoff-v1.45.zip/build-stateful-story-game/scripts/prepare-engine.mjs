#!/usr/bin/env node
import { cp, mkdir, readdir, readFile } from 'node:fs/promises'
import path from 'node:path'
import process from 'node:process'

const argv = process.argv.slice(2)
const targetIndex = argv.indexOf('--target')
const targetArg = targetIndex >= 0 ? argv[targetIndex + 1] : ''
const modeIndex = argv.indexOf('--mode')
const mode = modeIndex >= 0 ? argv[modeIndex + 1] : 'stateful'
if (!targetArg || targetArg.startsWith('--')) throw new Error('Usage: node prepare-engine.mjs --mode <stateful|cinematic> --target <empty-directory>')
if (!['stateful', 'cinematic'].includes(mode)) throw new Error('--mode must be stateful or cinematic')

const source = path.resolve(import.meta.dirname, `../assets/${mode === 'cinematic' ? 'cinematic-story-template' : 'stateful-story-template'}`)
const target = path.resolve(targetArg)
if (target === source) throw new Error('Target must be a working copy outside the installed Skill')

await mkdir(target, { recursive: true })
const existing = await readdir(target)
if (existing.length) throw new Error(`Engine target must be empty: ${target}`)
await cp(source, target, { recursive: true })

let sourceInfo = null
try { sourceInfo = JSON.parse(await readFile(path.join(source, 'ENGINE_SOURCE.json'), 'utf8')) } catch {}
console.log(JSON.stringify({ ok: true, mode, source, target, sourceInfo, deploymentIncluded: false }, null, 2))
