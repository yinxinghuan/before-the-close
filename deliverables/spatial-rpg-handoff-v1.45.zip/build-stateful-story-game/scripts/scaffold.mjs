#!/usr/bin/env node
import { access, readFile } from 'node:fs/promises'
import { randomUUID } from 'node:crypto'
import path from 'node:path'
import process from 'node:process'
import { spawnSync } from 'node:child_process'

function parseArgs(argv) {
  const values = new Map()
  for (let index = 0; index < argv.length; index += 1) {
    const key = argv[index]
    if (!key.startsWith('--')) throw new Error(`Unexpected argument: ${key}`)
    const value = argv[index + 1]
    if (!value || value.startsWith('--')) throw new Error(`Missing value for ${key}`)
    values.set(key, value)
    index += 1
  }
  return values
}

async function discoverTemplate(explicit, mode) {
  if (explicit) return path.resolve(explicit)
  const envName = mode === 'cinematic' ? 'CINEMATIC_STORY_TEMPLATE' : 'STATEFUL_STORY_TEMPLATE'
  if (process.env[envName]) return path.resolve(process.env[envName])
  const directoryName = mode === 'cinematic' ? 'cinematic-story-template' : 'stateful-story-template'
  const bundled = path.resolve(import.meta.dirname, `../assets/${directoryName}`)
  try { await access(path.join(bundled, 'scripts/export-cartridge.mjs')); return bundled } catch {}
  let cursor = path.resolve(import.meta.dirname)
  for (let depth = 0; depth < 8; depth += 1) {
    const candidate = path.join(cursor, directoryName)
    try { await access(path.join(candidate, 'scripts/export-cartridge.mjs')); return candidate } catch {}
    const parent = path.dirname(cursor)
    if (parent === cursor) break
    cursor = parent
  }
  throw new Error(`Bundled ${directoryName} is missing; reinstall this Skill or pass a verified --template path`)
}

const options = parseArgs(process.argv.slice(2))
const required = ['--game-id', '--title', '--cartridge-file', '--zh-export', '--en-export', '--target']
for (const key of required) if (!options.get(key)) throw new Error(`Missing required option ${key}`)

const id = options.get('--game-id')
if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(id)) throw new Error('--game-id must be kebab-case')
const mode = options.get('--mode') || 'stateful'
if (!['stateful', 'cinematic'].includes(mode)) throw new Error('--mode must be stateful or cinematic')
const uuid = options.get('--uuid') || randomUUID()
const saveNamespace = options.get('--save-namespace') || id
const template = await discoverTemplate(options.get('--template'), mode)
const target = path.resolve(options.get('--target'))
if (target === template) throw new Error('Target must be an independent game directory, not the mother template')
const cartridgePath = path.join(template, 'src/story/cartridges', path.basename(options.get('--cartridge-file')))
const cartridgeSource = await readFile(cartridgePath, 'utf8')
for (const [flag, exportName] of [['--zh-export', options.get('--zh-export')], ['--en-export', options.get('--en-export')]]) {
  if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(exportName)) throw new Error(`${flag} must be a valid TypeScript identifier`)
  const escaped = exportName.replace(/[$]/g, '\\$&')
  if (!new RegExp(`export\\s+const\\s+${escaped}\\b`).test(cartridgeSource)) throw new Error(`${flag} ${exportName} is not exported by ${cartridgePath}`)
}

const args = [
  path.join(template, 'scripts/export-cartridge.mjs'),
  '--id', id,
  '--file', path.basename(options.get('--cartridge-file')),
  '--zh-export', options.get('--zh-export'),
  '--en-export', options.get('--en-export'),
  '--title', options.get('--title'),
  '--save-namespace', saveNamespace,
  '--uuid', uuid,
  '--target', target,
]

const result = spawnSync(process.execPath, args, { cwd: template, encoding: 'utf8', stdio: ['inherit', 'pipe', 'pipe'] })
if (result.stdout) process.stdout.write(result.stdout)
if (result.stderr) process.stderr.write(result.stderr)
if (result.status !== 0) process.exit(result.status ?? 1)

console.log(JSON.stringify({ ok: true, mode, template, target, id, saveNamespace, uuid }, null, 2))
