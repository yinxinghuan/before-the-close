#!/usr/bin/env node
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import process from 'node:process'

const file = process.argv[2]
if (!file) throw new Error('Usage: node validate-brief.mjs <doc/world-brief.json>')

const brief = JSON.parse(await readFile(path.resolve(file), 'utf8'))
const errors = []
const assert = (condition, message) => { if (!condition) errors.push(message) }
const text = (value, min = 1) => typeof value === 'string' && value.trim().length >= min

assert(brief && typeof brief === 'object' && !Array.isArray(brief), 'brief must be an object')
assert(/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(brief.game?.id || ''), 'game.id must be kebab-case')
assert(text(brief.game?.titleZh), 'game.titleZh is required')
assert(text(brief.game?.titleEn), 'game.titleEn is required')
assert(['guided', 'open-world'].includes(brief.game?.mode), 'game.mode must be guided or open-world')
assert(Array.isArray(brief.game?.languages) && brief.game.languages.length === 2 && ['zh', 'en'].every((locale) => brief.game.languages.includes(locale)), 'game.languages must contain exactly zh and en')

for (const key of ['playerFantasy', 'emotionalPromise', 'commonKnowledgeBoundary']) assert(text(brief.experience?.[key], 20), `experience.${key} must be specific`)
assert(text(brief.experience?.openingObjective, 10), 'experience.openingObjective must be specific')
assert(Array.isArray(brief.world?.fixedRules) && brief.world.fixedRules.length >= 3, 'world.fixedRules needs at least 3 rules')
assert(Array.isArray(brief.world?.generationRules) && brief.world.generationRules.length >= 3, 'world.generationRules needs at least 3 rules')
assert(Number.isInteger(brief.world?.maxActiveThreads) && brief.world.maxActiveThreads >= 1 && brief.world.maxActiveThreads <= 5, 'world.maxActiveThreads must be 1..5')

assert(Array.isArray(brief.stats) && brief.stats.length === 3, 'stats must contain exactly 3 entries')
const statIds = new Set()
for (const [index, stat] of (brief.stats || []).entries()) {
  const prefix = `stats[${index}]`
  assert(/^[a-z][a-z0-9-]*$/.test(stat?.id || ''), `${prefix}.id must be stable kebab-case`)
  if (stat?.id) statIds.add(stat.id)
  assert(text(stat?.labelZh) && text(stat?.labelEn), `${prefix} needs zh/en labels`)
  assert(Number.isFinite(stat?.min) && Number.isFinite(stat?.max) && stat.min < stat.max, `${prefix} min must be less than max`)
  assert(Number.isFinite(stat?.initial) && stat.initial >= stat.min && stat.initial <= stat.max, `${prefix}.initial must be in range`)
  assert(['bar', 'number'].includes(stat?.display), `${prefix}.display must be bar or number`)
  assert(['low', 'high'].includes(stat?.dangerDirection), `${prefix}.dangerDirection must be low or high`)
  for (const key of ['warningAt', 'dangerAt']) assert(Number.isFinite(stat?.[key]) && stat[key] >= stat.min && stat[key] <= stat.max, `${prefix}.${key} must be in range`)
  assert(Number.isFinite(stat?.maxDelta) && stat.maxDelta > 0 && stat.maxDelta <= stat.max - stat.min, `${prefix}.maxDelta must be positive and no larger than the range`)
}
assert(statIds.size === 3, 'stat ids must be unique')

assert(Array.isArray(brief.choiceIntents) && brief.choiceIntents.length === 3 && brief.choiceIntents.every((value) => text(value, 5)), 'choiceIntents must contain exactly 3 meaningful intents')
for (const key of ['nameZh', 'nameEn', 'ability', 'limitOrCost', 'provenance']) assert(text(brief.signatureItem?.[key], key.startsWith('name') ? 1 : 10), `signatureItem.${key} is required`)
assert(Number.isInteger(brief.danger?.minSafeTurns) && brief.danger.minSafeTurns >= 0 && brief.danger.minSafeTurns <= 8, 'danger.minSafeTurns must be 0..8')
assert(Number.isInteger(brief.danger?.maxSafeTurns) && brief.danger.maxSafeTurns >= 1 && brief.danger.maxSafeTurns <= 10, 'danger.maxSafeTurns must be 1..10')
assert((brief.danger?.minSafeTurns ?? Infinity) <= (brief.danger?.maxSafeTurns ?? -Infinity), 'danger.minSafeTurns must not exceed danger.maxSafeTurns')
assert(Number.isInteger(brief.danger?.cooldownTurns) && brief.danger.cooldownTurns >= 1 && brief.danger.cooldownTurns <= 8, 'danger.cooldownTurns must be 1..8')
assert(['none', 'rare', 'allowed'].includes(brief.danger?.physicalCombat), 'danger.physicalCombat must be none, rare, or allowed')
assert(Array.isArray(brief.danger?.methods) && brief.danger.methods.length === 3 && brief.danger.methods.every((value) => text(value, 5)), 'danger.methods must contain exactly 3 response methods')
assert(Array.isArray(brief.danger?.threatPalette) && brief.danger.threatPalette.length >= 4 && brief.danger.threatPalette.every((value) => text(value, 8)), 'danger.threatPalette needs at least 4 specific threats')
assert(statIds.has(brief.danger?.fallbackStatId), 'danger.fallbackStatId must match one of the three stat ids')
assert(Number.isFinite(brief.danger?.fallbackAmount) && brief.danger.fallbackAmount > 0, 'danger.fallbackAmount must be positive')
for (const key of ['artDirection', 'entryScene', 'sceneImageDirection', 'itemImageDirection']) assert(text(brief.visuals?.[key], 20), `visuals.${key} must be specific`)
assert(['harbor', 'apartment', 'wayfarer'].includes(brief.visuals?.material), 'visuals.material must be an implemented engine material')
assert(text(brief.audio?.mood, 10), 'audio.mood is required')
assert(Number.isFinite(brief.audio?.bpm) && brief.audio.bpm >= 36 && brief.audio.bpm <= 120, 'audio.bpm must be 36..120')
assert(['chapter-boundary', 'true-ending'].includes(brief.ending?.type), 'ending.type must be chapter-boundary or true-ending')
assert(Array.isArray(brief.ending?.failureConsequences) && brief.ending.failureConsequences.length >= 3, 'ending.failureConsequences needs at least 3 playable consequences')

if (errors.length) {
  console.error(errors.map((error) => `- ${error}`).join('\n'))
  process.exit(1)
}

console.log(JSON.stringify({ ok: true, id: brief.game.id, mode: brief.game.mode, stats: [...statIds], danger: { cadence: [brief.danger.minSafeTurns, brief.danger.maxSafeTurns], physicalCombat: brief.danger.physicalCombat }, languages: brief.game.languages }, null, 2))
