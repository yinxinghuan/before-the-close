#!/usr/bin/env node
import { readFile, stat, writeFile } from 'node:fs/promises'
import path from 'node:path'
import process from 'node:process'
import { spawnSync } from 'node:child_process'

const argv = process.argv.slice(2)
const projectArg = argv.find((value) => !value.startsWith('--'))
if (!projectArg) throw new Error('Usage: node validate-game.mjs <game-dir> [--test] [--build] [--handoff-ready]')
const root = path.resolve(projectArg)
const build = argv.includes('--build')
const test = argv.includes('--test')
const handoffReady = argv.includes('--handoff-ready')
const requestedMode = argv.includes('--cinematic') ? 'cinematic' : argv.includes('--stateful') ? 'stateful' : null
const errors = []
const check = (condition, message) => { if (!condition) errors.push(message) }
const read = async (name) => readFile(path.join(root, name), 'utf8')
const exists = async (name) => { try { return (await stat(path.join(root, name))).size > 0 } catch { return false } }

const requiredFiles = ['package.json', 'vite.config.ts', 'index.html', 'meta.json', 'src/game-id.ts', 'src/story/cartridges/index.ts', 'src/story/engine/dangerDirector.ts', '_qa/danger-director.ts', '_qa/danger-directive-grounding.ts', 'doc/requirements.md', 'doc/visual.md', 'doc/technical.md']
for (const name of requiredFiles) check(await exists(name), `${name} must exist and be non-empty`)

let pkg = {}
try { pkg = JSON.parse(await read('package.json')) } catch { errors.push('package.json must be valid JSON') }
check(typeof pkg.scripts?.build === 'string', 'package.json must define npm run build')
check(typeof pkg.scripts?.['test:protocol'] === 'string', 'package.json must define test:protocol')
check(typeof pkg.scripts?.['test:danger'] === 'string', 'package.json must define test:danger')
check(typeof pkg.scripts?.['test:danger-grounding'] === 'string', 'package.json must define test:danger-grounding')
check(typeof pkg.scripts?.['test:character-debut'] === 'string', 'package.json must define test:character-debut')

const cinematic = await exists('src/story/engine/stageNarrative.ts') && await exists('src/story/engine/endingDirector.ts')
const mode = cinematic ? 'cinematic' : 'stateful'
check(!requestedMode || requestedMode === mode, `expected ${requestedMode} template but detected ${mode}`)
if (cinematic) {
  check(typeof pkg.scripts?.['test:ending'] === 'string', 'cinematic package.json must define test:ending')
  check(typeof pkg.scripts?.['test:opening'] === 'string', 'cinematic package.json must define test:opening')
  check(await exists('src/story/engine/imageDirector.ts'), 'cinematic project must include imageDirector.ts')
  check(await exists('src/story/useAvatarImageReference.ts'), 'cinematic project must include one-time avatar reference preparation')
}

let vite = ''
try { vite = await read('vite.config.ts') } catch {}
check(/base\s*:\s*['"]\.\/['"]/.test(vite), "vite.config.ts must use base: './'")

let gameId = ''
try { gameId = await read('src/game-id.ts') } catch {}
const uuid = gameId.match(/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/i)?.[0]
check(Boolean(uuid), 'src/game-id.ts must contain a UUID v4')

let cartridgeIndex = ''
try { cartridgeIndex = await read('src/story/cartridges/index.ts') } catch {}
const imports = [...cartridgeIndex.matchAll(/^import\s+\{[^}]+\}\s+from\s+['"]\.\/([^'"]+)['"]/gm)].map((match) => match[1])
check(imports.length === 1, `standalone cartridge index must import exactly one cartridge file; found ${imports.length}`)
let cartridge = ''
if (imports.length === 1) {
  try { cartridge = await read(`src/story/cartridges/${imports[0]}.ts`) } catch {}
}
check(/\bdirector\s*:/.test(cartridge), 'standalone Cartridge must define director')
check(/\bdangerDirector\s*:/.test(cartridge), 'standalone Cartridge must define dangerDirector')
check(/physicalCombat/.test(cartridge) && /fallbackCosts/.test(cartridge), 'dangerDirector must define combat boundary and fallback costs')
if (cinematic) {
  check(/\bmediaDirector\s*:/.test(cartridge), 'cinematic Cartridge must define mediaDirector')
  check(/imageTarget/.test(cartridge), 'cinematic Cartridge must define a portrait imageTarget')
  check(/maxQuietTurns\s*:\s*1/.test(cartridge), 'cinematic Cartridge must guarantee an image on every successful step')
} else {
  check(await exists('src/story/engine/turnPipeline.ts'), 'stateful project must include the unified turn pipeline')
  check(await exists('_qa/payment-consistency.ts'), 'stateful project must include payment consistency QA')
  check(await exists('_qa/turn-consistency.ts'), 'stateful project must include turn consistency QA')
  check(await exists('_qa/turn-pipeline.ts'), 'stateful project must include unified turn pipeline QA')
  check(await exists('_qa/domain-thread-continuity.ts'), 'stateful project must include domain thread continuity QA')
  check(await exists('_qa/recovery-choice-priority.ts'), 'stateful project must include recovery choice priority QA')
  check(await exists('_qa/active-thread-continuity.ts'), 'stateful project must include active thread continuity QA')
  check(await exists('_qa/recommended-choice-quality.ts'), 'stateful project must include recommended choice quality QA')
  check(await exists('_qa/perspective-director.ts'), 'stateful project must include configurable perspective director QA')
  check(await exists('_qa/preset-events.ts'), 'stateful project must include preset event director QA')
  check(await exists('_qa/v9-migration.ts'), 'stateful project must include v9-to-v10 migration QA')
  check(typeof pkg.scripts?.['test:payment'] === 'string', 'stateful package.json must define test:payment')
  check(typeof pkg.scripts?.['test:turn'] === 'string', 'stateful package.json must define test:turn')
  check(typeof pkg.scripts?.['test:dynamic-locations'] === 'string', 'stateful package.json must define test:dynamic-locations')
  check(typeof pkg.scripts?.['test:pipeline'] === 'string', 'stateful package.json must define test:pipeline')
  check(typeof pkg.scripts?.['test:domain-continuity'] === 'string', 'stateful package.json must define test:domain-continuity')
  check(typeof pkg.scripts?.['test:recovery-choice-priority'] === 'string', 'stateful package.json must define test:recovery-choice-priority')
  check(typeof pkg.scripts?.['test:active-thread'] === 'string', 'stateful package.json must define test:active-thread')
  check(typeof pkg.scripts?.['test:choice-quality'] === 'string', 'stateful package.json must define test:choice-quality')
  check(typeof pkg.scripts?.['test:perspective-director'] === 'string', 'stateful package.json must define test:perspective-director')
  check(typeof pkg.scripts?.['test:preset-events'] === 'string', 'stateful package.json must define test:preset-events')
  check(typeof pkg.scripts?.['test:v9-migration'] === 'string', 'stateful package.json must define test:v9-migration')
}

let storyEngine = ''
try { storyEngine = await read('src/story/useStoryEngine.ts') } catch {}
const saveNamespace = storyEngine.match(/useGameSave<PersistedStoryData>\(['"]([^'"]+)['"]\)/)?.[1]
check(Boolean(saveNamespace), 'useStoryEngine must declare a save namespace')
check(saveNamespace !== 'stateful-story-template', 'standalone save namespace must not reuse the mother template key')
check(saveNamespace !== 'cinematic-story-template', 'standalone save namespace must not reuse the cinematic mother template key')

let meta = {}
try { meta = JSON.parse(await read('meta.json')) } catch { errors.push('meta.json must be valid JSON') }
check(typeof meta.title === 'string' && meta.title.trim(), 'meta.json needs title')
check(meta.cover_url === './poster.png', 'meta.json cover_url must be ./poster.png')

if (handoffReady) {
  check(await exists('public/poster.png'), 'handoff-ready stage requires public/poster.png')
  check(await exists('public/THIRD_PARTY_NOTICES.txt'), 'handoff-ready stage requires public/THIRD_PARTY_NOTICES.txt')
  if (await exists('public/poster.png')) {
    const poster = await readFile(path.join(root, 'public/poster.png'))
    const png = poster.length >= 24 && poster.subarray(1, 4).toString('ascii') === 'PNG'
    const width = png ? poster.readUInt32BE(16) : 0
    const height = png ? poster.readUInt32BE(20) : 0
    check(png && width === 1024 && height === 1024, `public/poster.png must be a 1024x1024 PNG; found ${width}x${height}`)
  }
}

if ((test || build) && !errors.length) {
  if (!(await exists('node_modules/.package-lock.json'))) errors.push('dependencies are not installed; run npm install in the exported game')
}

const completedTests = []
if (test && !errors.length) {
  for (const script of cinematic
    ? ['test:protocol', 'test:danger', 'test:danger-grounding', 'test:ending', 'test:opening', 'test:character-debut']
    : ['test:protocol', 'test:payment', 'test:turn', 'test:dynamic-locations', 'test:pipeline', 'test:danger', 'test:danger-grounding', 'test:domain-continuity', 'test:recovery-choice-priority', 'test:active-thread', 'test:choice-quality', 'test:character-debut', 'test:perspective-director', 'test:preset-events', 'test:v9-migration']) {
    const result = spawnSync('npm', ['run', script], { cwd: root, encoding: 'utf8', stdio: ['inherit', 'pipe', 'pipe'] })
    if (result.stdout) process.stdout.write(result.stdout)
    if (result.stderr) process.stderr.write(result.stderr)
    if (result.status !== 0) errors.push(`${script} failed with status ${result.status}`)
    else completedTests.push(script)
  }
}

if (build && !errors.length) {
  const result = spawnSync('npm', ['run', 'build'], { cwd: root, encoding: 'utf8', stdio: ['inherit', 'pipe', 'pipe'] })
  if (result.stdout) process.stdout.write(result.stdout)
  if (result.stderr) process.stderr.write(result.stderr)
  if (result.status !== 0) errors.push(`npm run build failed with status ${result.status}`)
  if (result.status === 0) {
    const builtHtml = await readFile(path.join(root, 'dist/index.html'), 'utf8')
    check(!/(?:src|href)=["']\/(?!\/)/.test(builtHtml), 'dist/index.html contains a root-absolute asset path')
  }
}

if (errors.length) {
  console.error(errors.map((error) => `- ${error}`).join('\n'))
  process.exit(1)
}

if (handoffReady) {
  const git = spawnSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] })
  const handoff = {
    schemaVersion: 1,
    projectId: pkg.name || path.basename(root),
    uuid,
    sourceCommit: git.status === 0 ? git.stdout.trim() : null,
    buildCommand: 'npm run build',
    distPath: 'dist',
    posterPath: 'public/poster.png',
    noticesPath: 'public/THIRD_PARTY_NOTICES.txt',
    tests: completedTests,
    deploymentIncluded: false,
  }
  await writeFile(path.join(root, 'doc/artifact-handoff.json'), `${JSON.stringify(handoff, null, 2)}\n`)
}

console.log(JSON.stringify({ ok: true, root, mode, uuid, saveNamespace, cartridge: imports[0], stage: handoffReady ? 'handoff-ready' : 'authoring', tests: completedTests, build, deploymentIncluded: false }, null, 2))
