---
name: game-art-direction
description: Define and maintain a distinctive, coherent visual world for new games, reskins, major redesigns, generated assets, characters, environments, and game UI in /Users/yin/code/games. Use before full implementation when the art direction is not already locked, and whenever a game looks generic, inconsistent, cheap, visually weak, pasted together, or overly AI-generated.
---

# Game Art Direction

Establish the world before scaling screens or assets. Apply `ui-foundation` to interface elements. Write the chosen system to `doc/visual.md`.

## Frame the direction

Identify:

- Core mechanic and emotional promise.
- Audience, session length, platform, orientation, and input.
- The visual moment players should remember.
- Required screens, characters, environments, effects, and shareable outputs.
- Technical constraints: rendering method, performance, formats, and generation tools.

## Explore materially different options

When the brief is open, propose 2–3 direction cards. For each define:

- Concept statement tied to the mechanic.
- Shape language and composition.
- Camera or perspective.
- Material, surface, and lighting.
- Named palette with hex values.
- Typography roles and CJK fallback.
- Asset and illustration method.
- UI integration.
- Motion/VFX language.
- One signature visual moment.
- Main production risk.

Do not present accent-color swaps as different directions. Avoid default AI looks unless the subject specifically calls for them.

## Lock the visual bible

After selection, use [references/visual-bible-template.md](references/visual-bible-template.md). Define enough that another contributor can create a matching asset without guessing.

Include explicit anti-patterns. Prevent drift by naming forbidden effects, icon styles, perspectives, materials, and color behavior.

## Enforce asset coherence

- Keep camera angle, perspective, horizon, scale, and light direction consistent.
- Match outline/edge treatment and detail density at intended display size.
- Use a controlled palette and color hierarchy.
- Test generated assets inside the real composition; isolated quality is insufficient.
- Do not mix emoji with authored UI or game art.
- Do not place generic stock UI on top of a strongly authored world.

## Integrate UI with the world

Keep functional UI legible first. Derive geometry, materials, type, icons, and motion from the same thesis. Avoid generic glass cards, gradients, glows, or large rounded panels unless the visual bible gives them a subject-specific reason.

Keep routine HUD quieter than gameplay. Increase emphasis only for warnings, rewards, onboarding, or completion.

## Prove the direction with a vertical slice

Produce:

- Entry/start state when applicable.
- Representative gameplay.
- One high-feedback moment.
- Completion/game-over state when applicable.
- Narrow-mobile behavior.

Review the running slice with `game-visual-qa`. Revise the visual bible when implementation exposes a weak rule.

## Completion standard

Pass only when:

- The game can be recognized without reading its title.
- UI and game assets feel authored by one team.
- The primary action and playfield read immediately.
- New assets can be produced consistently.
- Anti-patterns are specific enough to prevent visual drift.
