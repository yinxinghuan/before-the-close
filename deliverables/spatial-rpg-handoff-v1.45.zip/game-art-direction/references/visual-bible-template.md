# Visual Bible — `doc/visual.md`

## 1. Visual thesis

- Game and audience:
- Emotional promise:
- One-sentence visual thesis:
- Signature visual moment:
- Three required qualities:
- Three directions to avoid:

## 2. Composition and camera

- Orientation and aspect ratios:
- Camera and perspective:
- Playfield focal area:
- Foreground, midground, background:
- HUD safe areas:
- Attention path:

## 3. Color

- Background, surfaces, text, and muted text:
- Player/subject, action, reward, danger, success:
- Usage ratios:
- Forbidden combinations:

## 4. Typography

- Display, UI/body, numeric/HUD, CJK fallback:
- Size, weight, case, tracking, and outline rules:

## 5. Shape, material, and lighting

- Dominant shapes and corner language:
- Outline, border, and shadow rules:
- Materials and textures:
- Light direction and atmosphere:

## 6. Characters, environments, and assets

- Proportions and silhouettes:
- Expression and pose range:
- Perspective, scale, detail density, edge treatment:
- Export size, format, alpha, and cropping rules:

## 7. UI and icons

- Icon family and sizing:
- Button hierarchy and targets:
- HUD and panel treatment:
- Default, pressed, focus, disabled, loading, warning, success states:
- Emoji policy: never use emoji as functional UI icons.

## 8. Motion and VFX

- Motion personality and duration tokens:
- Hit/reward timing:
- Particle shape, palette, density, and lifetime:
- Screen shake/freeze limits:
- Reduced-motion behavior:

## 9. References translated into principles

- Reference:
- Useful principle:
- Adaptation:
- Element not to copy:

## 10. Anti-patterns

- Forbidden icon/asset styles:
- Forbidden effects and color behavior:
- Generic patterns to avoid:
- Examples of visual drift:

## 11. Vertical-slice acceptance

- Entry/start:
- Gameplay:
- High-feedback moment:
- Completion/end:
- Narrow mobile:
- Visual QA findings and decision:
