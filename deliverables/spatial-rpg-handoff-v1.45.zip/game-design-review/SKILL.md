---
name: game-design-review
description: Review and strengthen gameplay designs for games in /Users/yin/code/games. Use when defining or changing a core loop, game mechanic, level challenge, difficulty curve, progression, economy, reward, puzzle, character build, win/lose rule, or recovery system; diagnosing playtest feedback such as boring, confusing, unfair, too easy, too hard, dominant strategies, or weak replayability; or planning focused balance experiments before implementation. Do not trigger for visual-only, copy-only, or isolated UI layout changes whose gameplay rules are unchanged.
---

# Game Design Review

Turn gameplay opinions into an explicit contract, prioritized risks, and cheap experiments. Preserve the intended player experience while testing whether the rules actually produce it.

## Profile the game before prescribing it

For a new game or a design whose engagement shape is unclear, read [references/game-profile-router.md](references/game-profile-router.md) and establish the game profile before selecting design lenses, promise horizons, metrics, or document depth.

Do not assume AlterU means a seconds-long disposable game. Classify both:

- The shape of one play visit: instant interaction, short round/level, medium or long continuous session, open-ended creation/exploration, or hybrid.
- Continuity across visits: self-contained, light persistence, long-term progression, ongoing narrative/social world, or hybrid.

If the user has not supplied enough information, first ask what the player does in one visit, how long that visit should feel, what persists afterward, and why they return. Combine these into one compact question when possible. Do not ask again when the answer is already implied by the brief or existing game.

## Route the work

- For a new game or material mechanic change, run the complete workflow and write accepted decisions into `doc/requirements.md`.
- For a focused balance, puzzle, progression, or playtest problem, run only the relevant lenses and report the unchanged context.
- For an implementation request, review the affected contract first, then implement only changes authorized by the user.
- For visual-only work, leave this skill inactive. Route screens and HUD to `game-ui-design`, moment-to-moment response to `game-feel`, and visual direction to `game-art-direction`.

Read [references/review-lenses.md](references/review-lenses.md) completely for a full review. For a narrow task, read the matching section before judging or editing the design.

## Establish evidence

Separate inputs before drawing conclusions:

- **Constraint**: product, platform, audience, accessibility, session, content, or technical limit.
- **Observation**: behavior seen in a build, recording, telemetry, or playtest.
- **Player report**: what a player says they felt or believed.
- **Design intent**: the experience the rules are supposed to create.
- **Hypothesis**: an explanation that still needs a test.

Do not convert a hypothesis into a fact. Ask for missing evidence only when it would materially change the decision; otherwise state the assumption and design a reversible test.

## Write the gameplay contract

Capture the smallest complete model:

1. **Game profile**: one-visit shape, continuity, expected commitment, and return structure.
2. **Promise ladder**: the relevant promises across discovery, first action, first session, first 10 minutes, session completion, and return/long-term play. Use only horizons that exist for this game.
3. **Core verbs**: the actions the player performs repeatedly.
4. **Loop**: action → state change → readable consequence → next decision.
5. **Resources**: what accumulates, depletes, gates, or converts.
6. **Choices**: what makes one action meaningfully different from another.
7. **Challenge source**: skill, memory, knowledge, planning, social judgment, chance, or a deliberate combination.
8. **Escalation**: what changes as competence or progress increases.
9. **Outcome and recovery**: success, failure, partial success, retry, and retained progress.
10. **Session and return shape**: expected duration, peak, ending, persistence, and reason to continue or return.

If the loop cannot be explained without naming visual polish, rewards, or future content, mark the core mechanic as unproven.

## Gate first-player comprehension

Do not treat tutorial completion, a successful scripted click path, or the existence of feedback as proof that the game is understandable. Before visual expansion or release, define a **three-answer contract** a fresh player should be able to state after the first value moment:

1. **Goal**: what am I trying to achieve or preserve now?
2. **Action**: what repeated action changes the outcome?
3. **Outcome**: what produces progress/score, and what causes failure or loss?

Teach these through `action → visible consequence → next decision`, not an up-front rules dump. The onboarding must let the player cause or witness one real positive outcome under safe conditions before normal pressure starts. If a HUD resource can be mistaken for tutorial progress, score, health, currency, or steps, rename or redesign it; internal design terminology is not an acceptable player label.

Require two distinct forms of evidence:

- **Mechanical evidence**: the intended action can be completed using normal input without `force`, coordinate bypasses, or hidden state injection.
- **Comprehension evidence**: a fresh player can answer the three questions above from the build and choose a sensible next action. Automation may verify mechanics and visibility, but cannot establish comprehension.

When no fresh-player evidence exists, report comprehension as **unverified**. Do not claim that onboarding passed merely because an agent, author, or test script reached the gameplay state.

## Review the design

Apply only relevant lenses from the reference and check at minimum:

- The repeated action is understandable and produces a consequential state change.
- A fresh player can distinguish tutorial progress from gameplay resources and can explain goal, action, progress, and failure after the first value moment.
- Choices have observable trade-offs and no accidental dominant strategy.
- Challenge tests what the game teaches and exposes failure causes clearly.
- Difficulty changes through authored variables rather than vague labels.
- Rewards reinforce the intended behavior without replacing the intrinsic activity.
- Failure preserves enough information and momentum for a useful next attempt.
- Claims about frustration, boredom, attention, or motivation are treated as hypotheses unless observed.

Distinguish severity from confidence:

- **P0**: the loop cannot function, the goal is unknowable, or the rules violate fairness or safety.
- **P1**: likely blocks learning, creates a dominant strategy, or breaks the intended experience.
- **P2**: meaningful refinement after the core design is viable.
- **Hypothesis**: plausible concern without enough evidence to assign as a defect.

## Design the cheapest decisive experiment

For each material uncertainty, record:

| Field | Requirement |
|---|---|
| Question | One falsifiable design question |
| Variable | One primary variable or rule under test |
| Baseline | Current value and build/state |
| Intervention | Deliberate alternative; use 2× or 0.5× only as an internal sensitivity probe when safe |
| Observable | Behavior to record, not inferred emotion alone |
| Pass signal | Result that supports the hypothesis |
| Stop signal | Safety, fairness, fatigue, or invalid-test boundary |
| Next decision | Keep, revert, narrow the range, or redesign |

Use extreme values to discover whether a variable matters, not to claim the final balance. Do not expose intentionally broken extremes to unsuspecting external players.

## Handle adaptive difficulty carefully

Treat dynamic difficulty as an optional product decision, not a universal fix.

- Define the failure pattern and the exact adjustable variables.
- Preserve rule legibility, competitive fairness, accessibility settings, and player trust.
- Prefer teachable assistance, optional aids, or authored difficulty modes when hidden changes would undermine mastery.
- Never use inferred frustration, disability, spending, or identity to manipulate outcomes.
- Record whether adjustments persist, reset, or affect scoring and leaderboards.

## Produce the review

Lead with the decision, then provide:

1. The gameplay contract.
2. Findings ordered by severity and confidence.
3. A compact experiment matrix for unresolved risks.
4. Accepted changes and explicitly rejected alternatives.
5. Required updates to `doc/requirements.md` when mechanics are in project scope.

Do not create a separate design document when `doc/requirements.md` can hold the authoritative rules. Hand implementation-facing feedback events to `game-feel`, screen/state implications to `game-ui-design`, and runtime evidence needs to the relevant QA skill.

## Guardrails

- Do not present fixed session lengths, choice counts, failure thresholds, ratios, or reward schedules as universal truths.
- Do not use the golden ratio as evidence that a layout or level is effective.
- Do not add currencies, streaks, daily locks, random rewards, or loss aversion merely to increase retention.
- Do not hide material rule changes from players when they affect fairness, competition, scoring, or learned mastery.
- Do not blame the player or the interface before checking task framing, instructions, controls, context, and test conditions.
- Do not use visual polish to conceal an unproven core loop.
