# Game Profile Router

Profile the intended experience before choosing mechanics, onboarding, progression, retention, or validation patterns. Treat the categories as routing aids, not genres or fixed duration rules.

## 1. Collect the minimum profile

Resolve these fields from the user's brief, an existing build, or one compact question:

| Field | What to establish |
|---|---|
| Player activity | What the player repeatedly does and decides |
| One-visit shape | Instant interaction, round/level, continuous session, open-ended activity, or hybrid |
| Expected commitment | How much uninterrupted attention the intended experience asks for |
| Continuity | What state, knowledge, relationships, creations, or progression persist |
| Return reason | Mastery, unfinished goal, growth, narrative curiosity, social world, creation, collection, or none |
| Ending structure | Hard ending, run/level ending, chapter ending, soft stopping point, or ongoing world |
| Product context | Platform, audience, input, solo/social structure, and commercial constraints when relevant |

If material information is missing, ask approximately:

> 玩家单次打开时主要做什么、希望玩多久；结束后哪些进度会保留；他下次为什么还会回来？

Ask separate follow-ups only when platform, multiplayer structure, narrative scope, or persistence would materially change the design.

## 2. Classify two independent axes

### One-visit shape

- **Instant interaction**: value arrives through an immediate gesture, reaction, reveal, or visual transformation.
- **Short round or level**: a bounded attempt, score, puzzle, scene, or encounter ends quickly and supports replay.
- **Medium/long continuous session**: learning, planning, traversal, narrative, construction, or strategic state develops within one sustained visit.
- **Open-ended activity**: the player creates, explores, socializes, tends, or experiments without a mandatory round ending.
- **Hybrid**: multiple visit shapes are intentionally connected; name the primary and secondary shapes.

Do not infer the category from platform alone. A mobile or embedded AlterU game may support sustained play; a desktop game may still be an instant interaction.

### Cross-visit continuity

- **Self-contained**: no required persistent progression; replay value comes from mastery, variation, expression, or sharing.
- **Light persistence**: records, unlocks, collections, or small continuity layers survive between visits.
- **Long-term progression**: builds, economy, world state, roster, capabilities, or goals accumulate across many visits.
- **Ongoing narrative/social world**: relationships, authored story, shared world, community, or evolving events create continuity.
- **Hybrid**: more than one continuity system matters; identify their authority and interaction.

## 3. Select the promise ladder

Define only horizons the game actually has:

| Horizon | Promise question |
|---|---|
| Discovery/external | What truthful experience does the title, poster, description, or invitation promise? |
| First meaningful action | What should the player understand or feel after the first consequential input? |
| First session | What complete value should the player receive before the first natural stopping point? |
| First 10 minutes | For experiences that extend beyond this horizon, what competence, possibility, tension, relationship, or question should now be established? |
| Session completion | What resolves, changes, or remains intentionally unfinished at the end of a visit? |
| Return/long-term | What deepens across visits, and how is the next return earned rather than coerced? |

For a game shorter than ten minutes, do not manufacture a ten-minute promise; use first-session and replay promises. For a longer game, do not let instant onboarding replace the first-10-minute or session-level promise.

For each selected horizon record:

- Claim: the intended player-facing value.
- Expected evidence: observable behavior or understanding that would support it.
- Failure signals: evidence that the promise is absent, delayed, misleading, or replaced by external rewards.

## 4. Route the design emphasis

| Profile | Emphasize |
|---|---|
| Instant + self-contained | Time to first meaningful action, legibility, expression, replay variation, graceful completion |
| Short round + self-contained/light persistence | Fair learning, restart cost, mastery curve, score/goal clarity, replay reason |
| Short/medium session + long-term progression | Session closure, persistence, build/economy choices, return value, anti-grind boundaries |
| Medium/long continuous + self-contained | First-10-minute promise, pacing, save/resume, learning sequence, meaningful stopping points |
| Medium/long + persistent progression | Nested loops, content capacity, long-term choice viability, save integrity, return cadence |
| Narrative/social ongoing | Introduction order, relationship/world continuity, authority, moderation/safety, recovery from absence |
| Open-ended/creative | Agency, discoverability, expressive range, artifact persistence, sharing and ownership boundaries |

Use this table to choose questions, not to auto-add features. A profile does not justify currencies, daily locks, streaks, live operations, or social systems by itself.

## 5. Re-profile when the design changes

Revisit the profile when a change introduces or removes persistence, chapters, multiplayer, generated content, long-term economy, open-ended creation, or a materially different expected session. Record the accepted profile in `doc/requirements.md` so later UI, save, content, and QA work share the same assumption.
