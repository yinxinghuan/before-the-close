# Game Design Review Lenses

Use these lenses as questions and experiment prompts, not as universal laws.

## Contents

1. Core loop and agency
2. Choices and dominant strategies
3. Challenge, learning, and puzzles
4. Difficulty and adaptation
5. Balance and sensitivity probes
6. Rewards and player psychology
7. Pacing and progression
8. Environmental storytelling
9. Playtest diagnosis

## 1. Core loop and agency

Check:

- Can the player name the current goal and the action that advances it?
- Does every core action change game state, knowledge, position, risk, or relationships?
- Is the consequence readable soon enough to inform the next action?
- Does repetition create mastery, new decisions, expression, or discovery?
- Is waiting, grinding, or UI navigation accidentally consuming more time than the core verb?
- Would the activity remain interesting without progression rewards or visual spectacle?

If the loop feels weak, remove one layer at a time and test the smallest playable cycle before adding content.

## 2. Choices and dominant strategies

For each meaningful choice, identify:

- What the player knows when choosing.
- What is gained, risked, delayed, or made unavailable.
- Whether the consequence differs in kind, timing, or probability.
- Whether the choice supports multiple viable play styles.

Audit dominant strategies by comparing expected value, execution difficulty, information requirements, and recovery cost. A strategy is not automatically a problem because skilled players optimize it; intervene when it collapses intended variety or invalidates other options.

For character builds and progression:

- Test extreme specialization and balanced builds.
- Check whether one stat improves several unrelated outcomes without a real trade-off.
- Check whether early irreversible choices require knowledge the player has not received.
- Prefer visible trade-offs, soft counters, situational value, or respec paths over arbitrary caps.

## 3. Challenge, learning, and puzzles

Classify what success primarily tests:

- **Execution skill**: timing, precision, coordination, speed.
- **Memory**: recall of patterns, layouts, sequences, or prior attempts.
- **Knowledge**: understanding rules, relationships, or vocabulary.
- **Planning**: forecasting consequences and allocating resources.
- **Social judgment**: interpreting or influencing other players.
- **Chance management**: making decisions under uncertainty.

Then verify that onboarding teaches the tested competence. Use a teach → safe practice → combined test → variation sequence when the mechanic benefits from staged learning.

Treat onboarding as incomplete until the player reaches a causal loop, not just an input:

- **Teach** the next action in the live playfield.
- **Safe practice** lets the player perform it without punishment.
- **Consequence** shows one real unit of progress, score, transformation, or information caused by that action.
- **Meaning** identifies the session goal and the material failure/loss condition at the moment they become relevant.
- **Next decision** leaves the player able to choose what to do without another author-directed click sequence.

Audit UI labels for false mental models. Fractions, dots, numbered cards, bars, checkmarks, and sequential highlights may be read as tutorial steps even when they represent capacity, budget, score, or health. Record what the player believed the indicator meant; do not defend it using internal terminology.

Automated traversal proves only that the path is executable. Comprehension requires fresh-player evidence: after the first value moment, can the player explain the current goal, repeated action, positive outcome, and failure risk without being taught the answer by the evaluator?

For puzzles:

- Make the goal and legal operations discoverable.
- Keep equivalent inputs deterministic unless uncertainty is itself a stated rule.
- Ensure required information is available before commitment.
- Distinguish insight from brute-force search and decide which one the design intends.
- Offer hints that reveal the next relationship, not the full solution.
- Test false assumptions created by wording, framing, camera, or affordances.

## 4. Difficulty and adaptation

Describe difficulty through variables such as speed, density, timing window, information, uncertainty, resource margin, opponent policy, or consequence severity. Do not use only labels such as easy or hard.

Separate:

- Learning difficulty: understanding what to do.
- Execution difficulty: performing the known action.
- Strategic difficulty: choosing among understood options.
- Punishment: the cost of failure.

Before adding dynamic difficulty, test clearer telegraphs, better practice, shorter recovery, optional hints, assist settings, or selectable modes. If adaptation remains justified, specify its signal, adjustment, bounds, reset behavior, visibility, and effect on competitive records.

## 5. Balance and sensitivity probes

Use a 2× or 0.5× intervention during internal testing to answer whether a numeric variable materially affects the experience. Choose values within safe technical and accessibility bounds.

Interpret results:

- Large behavioral change: the variable matters; narrow the range and test interactions.
- Little change: the variable may be irrelevant, masked, or measured with the wrong observable.
- Qualitative mode change: locate the threshold and decide whether it is desirable.
- New dominant strategy: test coupled variables rather than compensating blindly.

Change one primary variable per probe. Record the build, seed, input method, viewport, player familiarity, and repeated trials. Do not confuse a sensitivity probe with production tuning or an external A/B test.

## 6. Rewards and player psychology

Map every reward to the behavior it is intended to reinforce. Check whether the reward provides information, capability, expression, access, status, surprise, or merely accumulation.

Review:

- Does the player understand why the reward occurred?
- Is reward magnitude proportional to effort, risk, and rarity?
- Does randomness create interesting adaptation or only obscure value?
- Will scarcity cause hoarding and make the item functionally unusable?
- Does punishment teach, create tension, or only extend recovery time?
- Does extrinsic progression crowd out the pleasure of the core action?

Treat framing, loss aversion, anchoring, recency, and confirmation bias as possible influences, not deterministic controls. Never infer consent or wellbeing from engagement alone.

## 7. Pacing and progression

Model the session as intensity, novelty, decision load, and recovery over time. Avoid importing a universal attention-span number.

Check:

- How quickly the player reaches the first meaningful action.
- Where rules are introduced, practiced, combined, and revisited.
- Whether novelty arrives before mastery or after repetition becomes empty.
- Whether peaks have enough contrast and recovery to remain legible.
- Whether progression increases possibility, pressure, expression, or only numbers.
- Whether the ending resolves the session promise and gives a clear next choice.

## 8. Environmental storytelling

Use this lens only when the world communicates narrative or system state.

- Define what the player must understand and what may remain optional.
- Encode information through layout, wear, props, lighting, sound, behavior, or change over time.
- Give important clues redundancy across more than one channel when missing them would block progress.
- Verify that details are visible from the actual camera, route, pace, and mobile viewport.
- Do not make decoration contradict gameplay affordances or current world state.

Environmental storytelling can support exposition; it does not automatically replace clear objectives or required instructions.

## 9. Playtest diagnosis

Record behavior before interpretation:

- The task and information presented.
- The action sequence, hesitation, retries, abandonment, and recovery.
- The player's spoken report, kept separate from observation.
- Device, input, viewport, prior familiarity, interruptions, and build state.

Generate competing explanations across design, instruction, controls, context, and player strategy. Test the cheapest explanation first when impact is reversible; test the highest-risk explanation first when fairness, safety, or accessibility is involved.

Do not conclude that a player lacks skill because they failed, or that the design is broken because they reported frustration. Locate the mismatch between intent, information, action, and consequence.
