---
name: game-docs
description: Apply when creating, rebuilding, substantially modifying, reviewing, or preparing to ship any game in /Users/yin/code/games, from instant experiences and short rounds to medium/long sessions, persistent progression, narrative/social games, and open-ended play; and when the user mentions game docs, requirements.md, visual.md, technical.md, 功能文档, 视觉文档, 说明文档, 需求文档, 技术文档, internal search indexing, or "document this game". Ensures the game profile and requirements are written before coding, the selected visual system is captured before full UI implementation, and technical documentation matches the final code.
---

# Game Docs

Use this skill to make game documentation part of the build flow. Every new game, rebuilt game, and substantial feature/gameplay or visual change must produce or update:

```
doc/requirements.md
doc/visual.md
doc/technical.md
```

Write the documents in the current conversation language unless the user explicitly asks for another language.

## Workflow

1. Before coding or redesigning a new game, use `game-design-review` to establish its one-visit shape, cross-visit continuity, applicable promise horizons, persistence model, and return structure; then create or update `doc/requirements.md`.
2. Before full UI implementation or asset production, use `game-art-direction` and create or update `doc/visual.md`.
3. Implement the approved vertical slice, run visual QA, then expand the game.
4. After implementation, inspect the final code and create or update `doc/technical.md`.
5. Before claiming done, verify all required files are non-empty and match the final game.

For an existing game change, update `requirements.md` first if gameplay, controls, win/lose rules, sounds, or user-facing behavior changes. Update `visual.md` when identity, layout system, assets, icons, typography, color, motion, or substantial UI changes. Small non-visual fixes may reuse the existing visual document.

## requirements.md

This is the blueprint. It describes what the game is and how it should play. Do not include implementation details, file names, libraries, or code architecture here.

Include all six sections:

```markdown
# Requirements

## 1. Overview

## 2. Visual Design

## 3. Game Mechanics

## 4. Controls

## 5. Win / Lose Conditions

## 6. Sound Effects
```

Section expectations:

- `Overview`: State the game profile, player/context, one-visit shape, expected commitment, cross-visit continuity, persistent state, return reason, and one sentence explaining the core loop. Record only applicable promise horizons: discovery, first meaningful action, first session, first 10 minutes, session completion, and return/long-term.
- `Visual Design`: Summarize the intended visual experience, layout, playfield, UI layers, and asset needs. Put the selected direction and exact system in `doc/visual.md`.
- `Game Mechanics`: Describe the core verbs, loops, resources, choices, challenge, progression, persistence, recovery, and concrete parameters that actually exist. Include speed, gravity, spawn cadence, timers, score, collisions, combo, particles, or a real-time update loop only when the game uses them. For longer or persistent games, include nested session/long-term loops, save/resume, chapter/world state, economy, relationship, content, or stopping rules as applicable.
- `Controls`: Pointer, keyboard, touch, drag, tilt, or other inputs and the exact trigger logic for each.
- `Win / Lose Conditions`: Describe victory, failure, partial success, completion, continuation, stopping, recovery, and result states that actually exist. If the game has no win, lose, Game Over, or results screen, say so explicitly and document its natural stopping/return contract instead of inventing one.
- `Sound Effects`: Event-to-sound mapping with waveform/type, frequency or pitch range, duration, envelope, and volume when using synthesized sound; describe file assets if using audio files.

Use concrete numbers for parameters that exist or are accepted prototype hypotheses. Do not invent timers, scores, failure thresholds, session lengths, or progression values merely to fill the template. Mark unresolved values as hypotheses with a validation method rather than using vague placeholders like "reasonable", "適当", "合适", or "as needed".

## visual.md

This is the selected visual and interface contract. Create it with `game-art-direction` and keep it aligned with `game-ui-design`.

Include the eleven sections from `.agents/skills/game-art-direction/references/visual-bible-template.md`: thesis, composition/camera, color, typography, shape/material/light, assets, UI/icons, motion/VFX, translated references, anti-patterns, and vertical-slice acceptance.

Never use emoji as functional UI icons. Document the selected SVG icon family or custom icon rules.

## technical.md

This is the developer map. Write it after coding, based on the final implementation. Inspect actual files before writing; do not speculate.

Include all four sections:

```markdown
# Technical

## 1. 技术栈

## 2. 目录结构

## 3. 核心模块

## 4. 扩展点
```

If the conversation language is English, translate the headings while preserving the four meanings: tech stack, directory structure, core modules, extension points.

Section expectations:

- `技术栈`: Framework, language, rendering approach, styling, build tool, major runtime/platform APIs.
- `目录结构`: Key files/directories and each responsibility in one concise line.
- `核心模块`: State management, main loop, responsive layout, collision/update logic, audio, i18n, persistence, backend/platform APIs, storage, generation APIs, leaderboard/wall systems when present.
- `扩展点`: Which files to edit for gameplay tuning, visual assets, copy/i18n, scoring, input behavior, backend/persistence, generated media, or publishing metadata.

## Integration With Game Work

- When using `new-game`, record the game profile and applicable promise horizons in `requirements.md`, then select the direction for `visual.md` before expanding full UI.
- When using `game-interface-workflow`, keep the profile and applicable gate decisions reflected in the three documents.
- When using `game-feel`, reflect gameplay parameters in `requirements.md` and motion/audio language in `visual.md`.
- When using `game-persistence`, `gen-image`, `guestbook`, `social-wall`, or Aigram runtime skills, document the final APIs and data ownership in `technical.md`.
- When doing a small bug fix that does not alter behavior, docs may stay unchanged, but check whether `technical.md` has become inaccurate.

## Pre-ship Check

Run these checks from the game root before commit or before saying the game is done:

```bash
test -s doc/requirements.md
test -s doc/visual.md
test -s doc/technical.md
grep -nE '^## (1\\. Overview|2\\. Visual Design|3\\. Game Mechanics|4\\. Controls|5\\. Win / Lose Conditions|6\\. Sound Effects)' doc/requirements.md
grep -nE '^## (1\\. 技术栈|2\\. 目录结构|3\\. 核心模块|4\\. 扩展点|1\\. Tech Stack|2\\. Directory Structure|3\\. Core Modules|4\\. Extension Points)' doc/technical.md
```

Also read all three files before the final answer. Confirm `requirements.md` describes the intended game, `visual.md` matches the running interface, and `technical.md` matches the final code.
