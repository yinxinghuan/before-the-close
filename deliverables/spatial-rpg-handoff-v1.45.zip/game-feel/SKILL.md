---
name: game-feel
description: Design and implement responsive input, moment-to-moment feedback, motion, audio, scoring response, rewards, failure, and recovery for games in /Users/yin/code/games. Use when implementing or reviewing taps, hits, misses, collisions, drag, combo, score, damage, reward, success, failure, restart, game-over, animation timing, particles, haptics, or synthesized sound; and when interaction feels flat, delayed, weak, noisy, or unsatisfying.
---

# Game Feel

Make the result of player intent immediate, readable, and emotionally appropriate. Follow `doc/visual.md` for appearance and `game-ui-design` for screen hierarchy.

Do not force one feedback pattern onto every genre. Floating scores, speech bubbles, combo text, screen shake, particles, and fanfares are tools, not universal requirements.

## Build the feedback matrix

For each important player action record:

- Intent and input event.
- Immediate acknowledgement.
- Gameplay result.
- Visual, motion, audio, and optional haptic channels.
- Intensity level.
- Recovery or next action.
- Reduced-motion/audio behavior.

Use [references/feedback-matrix-template.md](references/feedback-matrix-template.md).

## Response timing

- Acknowledge direct input in the same frame where feasible.
- Avoid blocking input feedback on network, generation, persistence, or analytics.
- Separate instant acknowledgement from delayed completion.
- Give new players a fair start buffer when immediate hazards would cause accidental failure; tune it to the game instead of applying a universal duration blindly.

## Layer feedback deliberately

Use the fewest channels that make the result unmistakable:

- Visual: state change, flash, deformation, score/progress, particles.
- Motion: anticipation, impact, recoil, settle.
- Audio: click, hit, miss, reward, warning, completion.
- Haptic: only where platform support and event importance justify it.

Coordinate channels around one impact moment. More effects do not automatically create stronger feel.

## Scale intensity

Define a small ladder, for example:

1. Routine input.
2. Successful action.
3. Streak/combo or meaningful progress.
4. Rare reward, transformation, or completion.
5. Critical failure or danger.

Increase amplitude, duration, density, pitch, or contrast with importance. Keep routine feedback quiet enough that major events can escalate.

## Motion rules

- Use anticipation when it improves readability, not when it delays input.
- Keep contact/impact crisp and recovery legible.
- Prefer transform and opacity for UI motion.
- Use screen shake and freeze frames sparingly; cap them and provide reduced-motion alternatives.
- Prevent looping ambient effects from accumulating during Aigram preload.

## Audio rules

- Start/resume AudioContext only after user interaction.
- Treat audio failure as non-fatal.
- Reuse buffers and cap simultaneous voices on iOS/WebView.
- Keep click, hit, miss, warning, and completion sounds perceptually distinct.
- Match sound material and pitch language to the visual world.
- Follow `instant-play` for its stricter preload and audio constraints.

## Scoring, combo, and reward

- Display score only when it helps the player understand progress or mastery.
- Introduce combo only when consecutive performance is meaningful.
- Explain score changes near the cause when the formula is not obvious.
- Make rewards proportional to rarity and effort.
- Persist best score only when the game actually has a score/mastery loop.

## Failure and recovery

- Make the cause of failure clear.
- Avoid punishing input during onboarding or before the player can react.
- Keep restart fast and preserve the player's mental model.
- Results screens must present the outcome, relevant progress, and a clear next action; exact contents depend on the game.

## Verify feel

Capture video or a frame sequence for timing-dependent moments. Review:

- Input-to-response latency.
- Anticipation, contact, peak, and settle.
- Audio-visual synchronization.
- Repeated-action fatigue and clutter.
- Escalation between routine and rare events.
- Reduced-motion and muted-audio behavior.

Hand evidence to `game-visual-qa` before completion.
