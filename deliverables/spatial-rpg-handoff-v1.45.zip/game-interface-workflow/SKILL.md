---
name: game-interface-workflow
description: Orchestrate game profiling, gameplay framing, interface, and visual work for new, rebuilt, reskinned, or substantially modified games in /Users/yin/code/games. Use when starting a game, changing its visual direction, redesigning screens or HUD, improving poor UI, producing a vertical slice, or preparing visual work for delivery. Routes applicable work through game profile, promise horizons, brief, mechanics review, art direction, UI design, game feel, implementation, and visual QA without assuming every AlterU game is short-form.
---

# Game Interface Workflow

Use this skill as the process router. Do not duplicate detailed rules from the phase skills.

Always load `ui-foundation`. Load other skills only for the active stage:

| Stage | Load | Required output |
|---|---|---|
| Profile | `game-design-review`, `game-docs` | game profile and applicable promise horizons in `doc/requirements.md` |
| Frame | `game-docs` | `doc/requirements.md` and interface brief |
| Mechanics | `game-design-review` | gameplay contract and validation experiments in `doc/requirements.md` |
| Explore | `game-art-direction` | 2–3 distinct directions |
| Commit | `game-art-direction` | `doc/visual.md` visual bible |
| Structure | `game-ui-design` | screen/state contract |
| Feel | `game-feel` | feedback matrix |
| Verify | `game-visual-qa` | evidence, findings, fixes, recheck |

Load `ui-style-library` (legacy name `ui-styles`), `instant-play`, `handdrawn-creatures`, `lowpoly-asset-factory`, `skeuomorphic-frames`, or other style/type skills only when the brief or chosen direction requires them.

## Choose the workflow depth

### New game, reskin, or major redesign

Run every applicable gate below. Skip the mechanics checkpoint for a reskin whose gameplay rules are unchanged.

### Material UI change

Reuse the existing `doc/visual.md`, update the screen/state contract, implement, and run visual QA. Reopen art direction if the change alters the game's identity.

### Small visual bug

Apply `ui-foundation`, fix the defect, capture the affected state before and after, and run the relevant UI audit. Do not manufacture unnecessary design documents.

## Gate A — Frame the interface

For a new game, first use the Game Profile Router in `game-design-review`. Identify both the shape of one play visit and continuity across visits. Ask the user what the player does per visit, expected commitment, what persists, and why they return when those answers are not already available. Do not default AlterU projects to short sessions.

Complete [references/interface-brief-template.md](references/interface-brief-template.md) or capture the same fields in `doc/requirements.md`:

- Player, context, game profile, session/visit shape, continuity, and return reason.
- Applicable promise horizons: first action, first session, first 10 minutes, session completion, and long-term/return.
- Core interaction and emotional promise.
- Primary action or gameplay focus.
- Screen and state inventory.
- Platform, orientation, viewports, input, and safe areas.
- Required assets, platform UI, localization, and accessibility constraints.
- Known references and explicit dislikes.

State assumptions instead of blocking on minor uncertainty. Ask for direction only when the choice materially changes the game.

## Mechanics checkpoint — Validate gameplay

Use `game-design-review` for a new game or material gameplay change. Confirm the core loop, challenge source, choices, outcomes, recovery, and unresolved balance experiments in `doc/requirements.md`. Skip this checkpoint for a reskin or interface-only change whose rules are unchanged.

## Gate B — Approve the visual direction

Use `game-art-direction` to propose 2–3 materially different directions when the brief is open. Present compact direction cards rather than a long aesthetic essay.

Do not begin full implementation until one direction is selected or the user has already supplied a sufficiently specific direction. Quick low-cost prototypes are allowed to resolve uncertainty.

Write the chosen direction to `doc/visual.md` using the visual-bible template.

## Gate C — Approve a vertical slice

Use `game-ui-design` and `game-feel` to build only:

- Entry/start state when the game has one.
- Representative core gameplay.
- One high-feedback moment.
- Completion/game-over state when the game has one.
- Narrow-mobile behavior.

Run the slice and capture evidence. Use `game-visual-qa`. Do not scale full content production while P0/P1 findings remain.

## Gate D — Complete and verify

Expand the approved system to all required states. Then:

1. Run static UI audit.
2. Capture the full evidence matrix.
3. Fix P0 and P1 findings.
4. Recapture matched states.
5. Fix material P2 findings.
6. Update `doc/technical.md` from the final implementation.
7. Continue to build, `pre-ship-verify`, and `game-publish`.

## Communication contract

At each gate, lead with the decision the user needs to make:

- Gate A: confirm the game profile, applicable promise horizons, and constraints.
- Mechanics checkpoint: confirm the gameplay contract or accept a named experiment.
- Gate B: choose a visual direction.
- Gate C: approve or correct the vertical slice.
- Gate D: review remaining exceptions.

Keep implementation detail out of visual decisions unless it changes cost, feasibility, performance, or interaction.

## Done definition

Do not call interface work complete unless:

- The chosen visual direction is documented.
- When mechanics are in scope, the gameplay contract and unresolved experiments are recorded.
- UI and game assets feel like one authored world.
- Required states and target viewports are covered.
- No functional emoji icons remain without an explicit exception.
- Static audit and visual QA pass.
- Matched before/after or first-pass/recheck evidence exists for material changes.
