# Game Interface Brief

## Product frame

- Player and context:
- Player activity in one visit:
- One-visit shape:
- Expected session/commitment:
- Cross-visit continuity:
- Persistent state:
- Return reason:
- Ending/stopping structure:
- Core interaction:
- Emotional promise:
- Primary action or gameplay focus:

## Promise horizons

- Discovery/external promise:
- First meaningful action promise:
- First-session promise:
- First-10-minute promise, when applicable:
- Session-completion promise, when applicable:
- Return/long-term promise, when applicable:

## Screen and state inventory

- Entry/start:
- Core gameplay:
- Pause/overlay:
- Loading/empty/error/permission:
- Completion/game-over/results:
- Social, share, leaderboard, or generated-content surfaces:

## Environment

- Platform and embedding context:
- Orientation and target viewports:
- Input methods:
- Safe-area or platform overlays:
- Performance constraints:

## Content and assets

- Characters and environments:
- UI assets and icon requirements:
- Generated or uploaded media:
- Languages and text expansion:
- Accessibility requirements:

## Direction inputs

- References and useful principles:
- Explicit dislikes:
- Existing house style, if any:
- Decisions that require approval:
