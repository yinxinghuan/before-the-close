# Interface Skill Migration Map

Use this map during the staged migration. Do not delete legacy entries until projects and project rules route to the replacement.

| Existing source | Target | Action |
|---|---|---|
| `CORE_RULES.md` UI fragments | `ui-foundation` | Keep only project invariants and routing in core rules |
| `game-ux` | `game-feel` + `game-ui-design` | Convert legacy skill to compatibility router |
| `ui-styles` | future style-library references | Remove broad auto-trigger; keep named styles opt-in |
| `game-docs` visual section | `doc/visual.md` + `game-art-direction` | Keep requirements focused on product/gameplay and reference visual bible |
| `new-game` generic UI scaffold | `game-interface-workflow` | Require gates before full UI implementation |
| `instant-play` UI/audio/onboarding details | specialist references | Keep type-specific constraints; stop treating them as universal UI rules |
| `pre-ship-verify` | `game-visual-qa` | Keep mechanical Git/deploy checks separate from visual evidence |
| `handdrawn-creatures`, `lowpoly-asset-factory`, `skeuomorphic-frames` | style/type recipes | Invoke only from brief or selected art direction |
