---
name: game-ui-design
description: Design the information architecture, screen composition, HUD, menus, onboarding, controls, overlays, results, and responsive state behavior of games in /Users/yin/code/games. Use when creating or changing game screens, deciding what information appears where, simplifying confusing interfaces, fixing weak hierarchy, or translating a visual direction into usable game UI.
---

# Game UI Design

Design how the interface communicates and behaves. Apply `ui-foundation` and follow `doc/visual.md`. Do not redefine the art direction or game mechanics unless a UI constraint exposes a real conflict.

## Build the screen contract

List every relevant state before styling:

- Entry/start or instant-play idle.
- Onboarding and permission prompts.
- Core gameplay and HUD variants.
- Pause, settings, inventory, or secondary overlays.
- Loading, empty, offline, error, disabled, and success.
- Completion, game-over, results, reward, and restart.
- Social, leaderboard, share, gallery, or generated-content surfaces.

Use [references/screen-contract-template.md](references/screen-contract-template.md).

## Define hierarchy per screen

For each state specify:

1. Player question: what do they need to understand now?
2. Primary focus: playfield, object, message, or action.
3. Primary action.
4. Secondary actions.
5. Persistent information.
6. Temporary feedback.
7. Exit and recovery path.

If everything is emphasized, nothing is emphasized.

## Compose the playfield and HUD

- Protect the active play area and likely finger path.
- Place persistent HUD in stable, safe regions.
- Keep routine status quiet; reserve strong emphasis for change, danger, and reward.
- Prefer direct labels for unfamiliar actions and icon-only controls for familiar actions with accessible names.
- Do not place critical controls under platform chrome, notches, home indicators, or Aigram overlays.
- Define behavior when scores, names, and localized copy grow.

## Design controls and navigation

- Use `onPointerDown` for immediate game actions.
- Use `onClick` for rows/cards inside scrollable containers; follow `scroll-vs-click`.
- Provide visible pressed and focus behavior.
- Make touch targets at least 44 × 44 CSS px.
- Separate destructive, exit, and restart actions from frequent play actions.
- Do not hide required controls behind gestures without onboarding and a discoverable fallback.

## Design onboarding

- Teach the smallest action that gets the player to value.
- Prefer demonstration and immediate practice over paragraphs.
- Sequence competing instructions instead of displaying them together.
- Dismiss hints when the player demonstrates understanding.
- Ensure preload or delayed visibility cannot cause a one-shot demonstration to be missed.
- Follow specialist skills for sensor and instant-play behavior.

## Specify states, not just the default

For each control or component define applicable states:

- Default, pressed, focus, disabled, loading.
- Selected/unselected.
- Success, warning, error.
- Empty and no-permission.
- Long-content and localization expansion.

State changes must preserve layout stability where possible.

## Responsive strategy

- Classify the surface as fixed-aspect playfield, responsive DOM UI, or hybrid.
- Fixed-aspect playfields may scale as a unit; keep text and controls legible and protect safe areas.
- Responsive DOM and overlays must reflow, wrap, or scroll instead of relying only on transform scaling.
- Check narrow width, short height, tall devices, and intermediate widths.

## Handoff to implementation

Do not hand off a decorative mockup alone. Provide:

- Screen/state contract.
- Layout behavior and safe areas.
- Component hierarchy and reusable patterns.
- Copy and localization behavior.
- Interaction and recovery rules.
- Connection to visual tokens in `doc/visual.md`.
- Acceptance evidence required by `game-visual-qa`.
