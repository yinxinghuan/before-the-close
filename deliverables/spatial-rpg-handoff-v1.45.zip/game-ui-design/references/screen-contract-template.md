# Game Screen Contract

## Global environment

- Playfield type: fixed-aspect / responsive DOM / hybrid
- Target viewports and orientation:
- Input methods:
- Platform overlays and safe areas:
- Persistent navigation or watermark:

## Screen/state

- Name:
- Entry condition:
- Player question:
- Primary focus:
- Primary action:
- Secondary actions:
- Persistent information:
- Temporary feedback:
- Exit/recovery path:
- Loading/empty/error behavior:
- Long-copy/localization behavior:
- Narrow/short viewport behavior:
- Required screenshot or motion evidence:

## Component state matrix

| Component | Default | Pressed | Focus | Disabled | Loading | Success/error |
|---|---|---|---|---|---|---|
| | | | | | | |

## HUD contract

- Protected gameplay/finger area:
- Stable HUD regions:
- Quiet persistent information:
- High-emphasis warnings/rewards:
- Maximum score/name/copy lengths:

## Onboarding contract

- First action to teach:
- Demonstration:
- Practice response:
- Dismissal condition:
- Fallback instruction:
