---
name: game-visual-qa
description: Inspect running game screens and interactions for visual quality, coherence, usability, polish, art-direction compliance, and responsive behavior in /Users/yin/code/games. Use before declaring any material game UI or visual change complete; after changing screens, HUD, assets, animations, generated art, or responsive layout; and whenever a game looks weak, generic, inconsistent, cluttered, amateur, or visually broken.
---

# Game Visual QA

Review evidence from the running game. Source code and a successful build are insufficient. Apply `ui-foundation`, compare against `doc/visual.md`, and keep Git/deployment checks in `pre-ship-verify`.

## Collect evidence

Capture all relevant states:

- Entry/start or instant-play idle.
- Representative core gameplay.
- High-feedback event.
- Pause/secondary overlay.
- Completion/game-over/results.
- Loading, empty, error, disabled, permission, and success states that exist.
- Narrow mobile and primary target viewport.
- Motion/video when timing is material.

Store evidence under `_qa/ui/` or the project's existing QA directory with clear state and viewport names.

### Separate platform composition from the external visitor banner

The `guest-shell.js` visitor banner exists only for external visitors. It is not
rendered inside AlterU and does not reserve layout space. Therefore:

- Treat `platform-layout` screenshots with no `#alteru-guest-banner` as the
  authoritative evidence for title, HUD, camera, subject scale, and safe areas.
- Also capture one `external-guest` state with the banner visible to verify the
  managed extension and CTA, but do not redesign the game to clear that overlay.
- Keep the production guest-shell script enabled in both cases. For a
  composition-only Playwright capture, wait for the page and inject:

```js
await page.addStyleTag({
  content: '#alteru-guest-banner{display:none!important}',
})
```

This style must live only in the QA harness. Reload without the injection for
the external screenshot. Never add top padding, move the camera, or commit CSS
to the game merely to avoid the external banner.

## Prioritize findings

### P0 — Broken or unusable

- Hidden, clipped, unreachable, or covered critical controls.
- Unreadable critical text or severe layout collapse.
- Incorrect safe-area behavior.
- Platform layout displaced to accommodate the external-only visitor banner.
- Missing feedback that prevents understanding or progress.

### P1 — Major visual or UX failure

- Primary action or playfield is not obvious.
- Emoji is used as a functional icon.
- Icon families, assets, perspectives, lighting, or detail levels conflict.
- HUD competes with gameplay.
- Contrast fails or state relies only on color.
- Major states feel like different products.
- Generated assets look pasted on rather than integrated.
- Required mobile/state evidence is missing.

### P2 — Polish and consistency

- Spacing, alignment, sizing, type, radius, borders, or shadows drift.
- Pressed, focus, loading, reward, or error feedback is weak.
- Motion feels sluggish, noisy, or unrelated to impact.
- Decorative effects create template-like clutter.

### P3 — Optional enhancement

- Additional atmosphere or delight that does not affect clarity.

Fix P0/P1 before P3.

## Inspect each dimension

- First-glance read: playfield, subject, immediate goal, action, progress, state.
- Composition: focal point, balance, negative space, depth, cropping, safe areas.
- Visual system: palette, type, icons, shapes, edges, materials, texture, motion.
- Asset integration: perspective, scale, light, alpha, temperature, detail density.
- Interface: hierarchy, targets, states, copy, focus, contrast, color independence.
- Game feel: acknowledgement, hit/reward/failure clarity, escalation, synchronization.
- Responsive/localization: narrow/short viewports, long strings, number growth, reach.

## Score the result

Score 1–5:

| Category | 1 | 3 | 5 |
|---|---|---|---|
| Hierarchy | Confusing | Understandable | Immediate and intentional |
| Coherence | Mixed styles | Mostly consistent | One authored world |
| Readability | Frequent failure | Usable | Clear across states/sizes |
| Game feel | Little response | Functional | Responsive and satisfying |
| Asset quality | Broken/pasted | Acceptable | Integrated and distinctive |
| Responsive UX | Breaks | Minor issues | Robust across targets |
| Polish | Prototype-like | Presentable | Release-quality |

Do not pass with any category below 3. Target an average of at least 4 for a visually strong release.

## Report actionable findings

For every issue include:

- Severity.
- Screen/location and evidence.
- Visible observation.
- User or quality impact.
- Concrete fix.
- Verification evidence.

Use [references/review-report-template.md](references/review-report-template.md). Tie findings to the brief, visual bible, user goal, or foundation rule rather than taste alone.

## Require iteration

1. Review first-pass evidence.
2. Fix P0 and P1.
3. Capture the same states again.
4. Compare matched evidence.
5. Fix material P2 findings.
6. Re-score and document intentional exceptions.

For games loading `guest-shell.js`, matched evidence must include
`platform-layout` at both primary and narrow mobile sizes plus one
`external-guest` release check.

Never complete visual QA after only one screenshot pass.
