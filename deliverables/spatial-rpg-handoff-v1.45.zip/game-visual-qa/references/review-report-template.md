# Game Visual QA Report

## Context

- Game/build:
- Review target:
- Requirements and visual bible:
- Viewports/devices:
- Evidence paths:

## Executive assessment

- Decision: Pass / Pass with fixes / Do not pass
- Strongest quality:
- Largest risk:
- P0/P1/P2 counts:

## Scorecard

| Category | Score 1–5 | Evidence | Required action |
|---|---:|---|---|
| Hierarchy | | | |
| Coherence | | | |
| Readability | | | |
| Game feel | | | |
| Asset quality | | | |
| Responsive UX | | | |
| Polish | | | |

## Finding

- Severity:
- Screen/location:
- Observation:
- Impact:
- Concrete fix:
- Verification evidence:

## Foundation audit

- Functional emoji icons:
- Icon-family consistency:
- Touch targets:
- Contrast and color independence:
- Focus and input behavior:
- State coverage:
- Localization and overflow:

## Art-direction audit

- Palette and typography:
- Composition:
- Asset perspective/lighting/detail:
- UI/world integration:
- Motion and VFX:

## Iteration evidence

- First-pass captures:
- Fixes completed:
- Matched recheck captures:
- Remaining exceptions and reasons:

## Final recommendation

- Final average:
- Categories below 3:
- Decision:
