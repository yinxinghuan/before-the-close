---
name: ui-foundation
description: Enforce the non-negotiable UI quality floor for every game screen, HUD, menu, overlay, onboarding prompt, result screen, social surface, website, and interactive component in /Users/yin/code/games. Use whenever creating, modifying, reviewing, polishing, or shipping user-facing UI; choosing icons, typography, colors, spacing, controls, states, or responsive behavior; or when the user says the interface looks bad, generic, inconsistent, amateur, or hard to use.
---

# UI Foundation

Apply these rules before any decorative style. Treat them as release gates. Follow an explicit product requirement when it intentionally conflicts, and record the exception.

## Establish the interface contract

Before implementation, identify:

1. Primary user and immediate goal.
2. Single primary action or focal interaction.
3. Primary, secondary, and supporting information.
4. Required states: default, pressed, focus, disabled, loading, empty, success, and error as applicable.
5. Target viewports, input methods, safe areas, and localization requirements.

Do not begin by decorating components.

## Non-negotiable rules

### Icons and assets

- Never use emoji as functional UI icons in buttons, navigation, HUD, status, controls, or instructional overlays.
- Allow emoji only as user-authored content, literal product content, or an explicitly approved art-direction element.
- Use one coherent SVG icon family per interface. Keep viewBox, stroke or fill, corner treatment, optical size, and alignment consistent.
- Rotation/restart icons must use an optically centered, small-size-tested circular arrow. Do not use the known broken hand-drawn `M4/5 8 ... M4/5 4 ... A7` family or the off-center `M20 11a8 8 ... M20 5v6h-6` family; both read as a misplaced flag at 22px.
- Give icon-only controls an accessible name. Use official brand marks.
- Do not mix photography, 3D, flat illustration, line icons, pixel art, and emoji without an explicit art-direction rule.

### Hierarchy and composition

- Make one action or gameplay focus visually primary.
- Express hierarchy through size, weight, contrast, position, and whitespace.
- Group related elements by proximity and alignment.
- Use a deliberate grid. Fix visible near-misses instead of accepting arbitrary offsets.
- Do not turn every group into an interchangeable floating rounded card.
- Spend visual boldness on one subject-specific signature; keep supporting UI disciplined.

### Typography and content

- Define and follow a compact type scale.
- Keep mobile body copy at least 16 px; short utility labels and non-interactive HUD may be smaller when still legible.
- Use 1.4–1.7 line height for prose and keep line measure near 45–75 characters.
- Limit type families and weights. Provide CJK-compatible fallbacks.
- Use clear action labels and keep the same verb across loading, success, and error states.
- Test labels with longer English and Chinese strings.

### Color and contrast

- Define semantic color roles rather than scattering unrelated values.
- Meet 4.5:1 contrast for normal text and 3:1 for large text and essential graphical controls.
- Never communicate state through color alone.
- Do not add gradients, glow, glass, blur, or shadows unless they belong to the selected visual system.
- Test transparency independently on light and dark surfaces.

### Spacing and targets

- Use a spacing scale, normally based on 4 px unless the product defines another system.
- Keep repeated components dimensionally consistent.
- Make interactive targets at least 44 × 44 CSS px even when the visible icon is smaller.
- Separate destructive actions from frequent actions.
- Respect safe-area insets and fixed navigation or platform overlays.

### Interaction and states

- Produce immediate visible feedback for every action.
- Define pressed, focus, disabled, loading, success, and failure behavior where relevant.
- Keep keyboard focus visible and tab order logical.
- Do not make essential behavior hover-only.
- Keep ordinary micro-interactions around 150–300 ms and prefer transform/opacity.
- Respect `prefers-reduced-motion` and never make animation the sole carrier of meaning.
- Prevent duplicate async submissions.
- On tap-heavy game surfaces where two quick taps are valid input, set `touch-action: manipulation` (or a narrower deliberate gesture contract) and prevent the root `dblclick` default so the browser does not turn gameplay into double-tap zoom. Restore `pan-y pinch-zoom` on real scroll containers; do not suppress the second game input.

### Responsive behavior

- Design for real viewport ranges, not one screenshot size.
- Prevent horizontal overflow, clipped text, unreachable controls, and UI hidden behind overlays.
- Use `100dvh` for full-height mobile DOM layouts where browser chrome matters.
- Test narrow mobile, primary mobile, intermediate width, and desktop when applicable.
- A fixed-aspect game canvas may scale as a unit. Menus, HUD, and ordinary DOM UI must still adapt internally and remain legible; do not use whole-page scaling as the only responsive strategy.

### Accessibility and resilience

- Label inputs programmatically and place recovery guidance near errors.
- Give informative images meaningful alt text and decorative images empty alt text.
- Do not place essential information only inside an image.
- Design loading, empty, offline, permission-denied, success, and error states that exist in the product.

## Require a minimal visual system

Before building material UI, define:

- Semantic colors.
- Type roles and scale.
- Spacing scale.
- Radius, border, and shadow rules.
- Icon family and sizing.
- Motion durations and easing.
- One subject-specific visual signature.

If the same choices could be reused unchanged for an unrelated game, the direction is too generic.

## Verify before delivery

1. Run the real interface.
2. Capture important states at target viewports.
3. Inspect hierarchy, alignment, typography, color, assets, interaction states, overflow, and safe areas.
4. Run `python3 .agents/skills/ui-foundation/scripts/audit_ui.py <game-root> --strict`.
5. Review every finding; annotate an intentional emoji exception with `ui-audit: allow-emoji` on that source line.
6. Fix high-impact issues and capture the same states again.

Read [references/pre-delivery-checklist.md](references/pre-delivery-checklist.md) for the complete gate. Functional completion is not visual completion.
