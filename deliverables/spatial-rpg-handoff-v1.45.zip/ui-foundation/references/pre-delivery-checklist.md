# UI Pre-delivery Checklist

Use this checklist on the running product.

## Visual language

- [ ] No emoji is used as a functional icon.
- [ ] Icons use one coherent SVG family or one documented custom family.
- [ ] Icon size, weight, alignment, and accessible naming are consistent.
- [ ] Photography, illustration, 3D, texture, and game assets share one art direction.
- [ ] Color, type, spacing, radius, border, shadow, and motion tokens are defined.

## Hierarchy and layout

- [ ] The primary gameplay focus or action is obvious at a glance.
- [ ] Primary, secondary, and supporting content are distinguishable.
- [ ] Related elements are grouped by proximity and alignment.
- [ ] Repeated components use consistent dimensions.
- [ ] Fixed UI does not hide content or gameplay.

## Typography and content

- [ ] Body text is readable at the smallest target viewport.
- [ ] Type roles and line heights follow a compact scale.
- [ ] Action labels use clear, consistent verbs.
- [ ] Long English and Chinese strings do not clip or break controls.

## Interaction and accessibility

- [ ] Interactive targets are at least 44 × 44 CSS px.
- [ ] Pressed, focus, disabled, loading, success, and error behavior is present where applicable.
- [ ] Status is not communicated through color alone.
- [ ] Text and essential controls meet contrast requirements.
- [ ] Essential behavior does not depend on hover.
- [ ] Reduced-motion behavior is available where motion is substantial.

## Responsive and state coverage

- [ ] Narrow mobile and primary target sizes were checked.
- [ ] No horizontal overflow, clipping, or safe-area collision exists.
- [ ] Loading, empty, error, permission, success, and completion states were checked where applicable.
- [ ] Important states were captured from the running product.
- [ ] High-impact issues were fixed and the same states were captured again.
