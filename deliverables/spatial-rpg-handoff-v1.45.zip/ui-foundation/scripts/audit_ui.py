#!/usr/bin/env python3
"""Report likely functional emoji/text glyphs and mixed icon-library usage."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


SOURCE_EXTENSIONS = {
    ".astro",
    ".html",
    ".js",
    ".jsx",
    ".svelte",
    ".ts",
    ".tsx",
    ".vue",
}
SKIP_DIRS = {
    ".git",
    ".next",
    ".nuxt",
    ".output",
    ".turbo",
    "build",
    "coverage",
    "dist",
    "node_modules",
}
ICON_LIBRARIES = {
    "lucide": re.compile(r"(?:from\s+['\"]lucide(?:-react)?['\"]|lucide-react)"),
    "heroicons": re.compile(r"@heroicons/"),
    "material": re.compile(r"@mui/icons-material|material-icons"),
    "phosphor": re.compile(r"(?:@phosphor-icons|phosphor-react)"),
    "react-icons": re.compile(r"from\s+['\"]react-icons/"),
}

# Broad pictograph ranges; findings are reviewed because user content may be valid.
EMOJI_RE = re.compile(
    "["
    "\U0001F000-\U0001FAFF"
    "\U00002600-\U000027BF"
    "]"
)
UI_CONTEXT_RE = re.compile(
    r"<(?:button|a|span|div|label|option)\b|"
    r"(?:icon|Icon|button|Button|nav|Nav|hud|HUD|status|Status|label|Label)\s*[:=]"
)
ALLOW_MARKER = "ui-audit: allow-emoji"
BROKEN_RESTART_PATH_RE = re.compile(
    r"(?:M[45]\s+8(?:V4|v-4).*M[45]\s+4.*A7(?:\.4)?\s+7(?:\.4)?|M20\s+11a8\s+8.*M20\s+5v6h-6)",
    re.IGNORECASE,
)


def iter_source_files(root: Path):
    if root.is_file():
        if root.suffix in SOURCE_EXTENSIONS:
            yield root
        return

    for path in root.rglob("*"):
        if not path.is_file() or path.suffix not in SOURCE_EXTENSIONS:
            continue
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        yield path


def relative(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def audit(root: Path):
    emoji_findings: list[tuple[Path, int, str]] = []
    broken_restart_findings: list[tuple[Path, int, str]] = []
    libraries: dict[str, set[Path]] = {name: set() for name in ICON_LIBRARIES}

    for path in iter_source_files(root):
        try:
            text = path.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            continue

        for name, pattern in ICON_LIBRARIES.items():
            if pattern.search(text):
                libraries[name].add(path)

        for line_no, line in enumerate(text.splitlines(), start=1):
            if ALLOW_MARKER in line:
                continue
            if EMOJI_RE.search(line) and UI_CONTEXT_RE.search(line):
                emoji_findings.append((path, line_no, line.strip()))
            if BROKEN_RESTART_PATH_RE.search(line):
                broken_restart_findings.append((path, line_no, line.strip()))

    used_libraries = {name: paths for name, paths in libraries.items() if paths}
    return emoji_findings, broken_restart_findings, used_libraries


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Audit UI source for likely functional emoji/text glyphs and mixed icon libraries."
    )
    parser.add_argument("root", nargs="?", default=".", help="Game root or source file")
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Exit 1 when emoji findings or multiple icon libraries are found",
    )
    args = parser.parse_args()

    root = Path(args.root).expanduser().resolve()
    if not root.exists():
        print(f"ERROR: path does not exist: {root}", file=sys.stderr)
        return 2

    emoji_findings, broken_restart_findings, libraries = audit(root)

    if emoji_findings:
        print("FUNCTIONAL EMOJI/TEXT GLYPHS — review and replace functional uses with coherent SVG icons:")
        for path, line_no, line in emoji_findings:
            print(f"  {relative(path, root)}:{line_no}: {line}")
    else:
        print("FUNCTIONAL EMOJI/TEXT GLYPHS: no likely findings")

    if broken_restart_findings:
        print("BROKEN RESTART SVG PATHS — replace detached square-corner arrows with a connected circular arrow:")
        for path, line_no, line in broken_restart_findings:
            print(f"  {relative(path, root)}:{line_no}: {line}")
    else:
        print("BROKEN RESTART SVG PATHS: no known findings")

    if len(libraries) > 1:
        print("MIXED ICON LIBRARIES — confirm a documented reason or standardize:")
        for name, paths in sorted(libraries.items()):
            sample = ", ".join(relative(path, root) for path in sorted(paths)[:3])
            print(f"  {name}: {sample}")
    elif len(libraries) == 1:
        name = next(iter(libraries))
        print(f"ICON LIBRARY: {name}")
    else:
        print("ICON LIBRARY: no recognized package imports (inline/custom SVG may be valid)")

    has_findings = bool(emoji_findings) or bool(broken_restart_findings) or len(libraries) > 1
    return 1 if args.strict and has_findings else 0


if __name__ == "__main__":
    raise SystemExit(main())
