---
name: ui-style-library
description: "Apply one of the documented AlterU game house styles after a direction has been explicitly selected: BSOD Pixel, Retro Mac, or Comic Book BAM pop-art. Use only when the user names the style, asks to match its source game, or game-art-direction chooses it. Do not use this library to decide the direction for a new game and do not auto-apply it to generic UI work."
---

# UI Style Library

Use this skill after `game-art-direction`, not instead of it. Always apply `ui-foundation`.

Read only the selected reference:

- BSOD / dark pixel / Kairosoft / CRT → [references/bsod-pixel.md](references/bsod-pixel.md)
- My Meme / classic Macintosh / retro computer → [references/retro-mac.md](references/retro-mac.md)
- Tag / comic / pop-art / BAM / Lichtenstein → [references/comic-pop-art.md](references/comic-pop-art.md)

Do not blend styles by default. If a direction intentionally combines them, write the exact borrowed principles and the rule resolving conflicts in `doc/visual.md`.

## Application contract

1. Confirm the selected style and the subject-specific adaptation.
2. Copy its relevant tokens into `doc/visual.md`; do not reference the recipe vaguely.
3. Define which recognizable traits remain and which change for the new subject.
4. Build the vertical slice.
5. Review at intended display size with `game-visual-qa`.

Reject a result that mechanically copies the source game without translating the style to the new mechanic.
