# BSOD Pixel

Use for intentionally dark retro-game interfaces with Kairosoft-like pixel controls, CRT typography, warm low-saturation color, dither, and controlled glitch.

## Core language

- Background: near-black navy `#06090F`.
- Warm structural ink: deep brown `#281408`.
- Status accents: orange `#E06820`, pink `#D04070`, purple `#9838B8`, cyan `#20A0D0`, danger red `#C02818`.
- Display: `VT323`; labels/buttons: `Press Start 2P`; technical text: `Share Tech Mono`; translated prose: `Noto Sans SC` or compatible CJK sans.
- Corners: 2–3 px; borders: 2–3 px hard dark lines; shadows: hard 0 5px offsets.
- Surfaces: checker/dither bands, lowered saturation, no soft glass blur.

## Controls

- Build pixel buttons from border, flat fill, highlight band, dithered lower band, and hard offset shadow.
- Press by translating down about 4 px and removing/reducing the shadow.
- Keep touch target at least 44 px even when pixel text is small.
- Use coherent pixel SVG icons; never use emoji.

## Motion

- Short list/entry motion: 150–500 ms.
- Use glitch only for state, danger, transmission, or identity moments; do not run it on all text.
- Keep color-channel separation and slice effects brief enough to preserve readability.

## Drift to reject

- Bright generic cyberpunk neon.
- Large soft rounded cards.
- Smooth modern SaaS icons.
- Full-screen constant glitch.
- Pixel display fonts used for long CJK prose.
