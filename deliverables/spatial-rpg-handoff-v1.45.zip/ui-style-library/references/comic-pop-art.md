# Comic Book BAM Pop-art

Use for intentionally loud comic, slapstick, tag, versus, or reaction-heavy interfaces with cream paper, black frames, halftone, high-saturation chips, bursts, and hand-lettered English shouts.

## Core language

- Paper: `#F4ECD8`; light paper `#FBF4DD`; ink `#111111`; white `#FFFFFF`.
- Accent set: yellow `#FFD60A`, red `#E63946`, blue `#2C6DF4`, green `#7CFC00`, pink `#FF6B9D`, orange `#F97316`, purple `#9B59B6`.
- Frames: 4–6 px black borders, 4–8 px hard shadows, usually zero radius.
- Texture: controlled halftone dots at 15–30% opacity.
- English shouts: `Bangers` or `Knewave`; notes: `Permanent Marker`; translated prose and controls: `Inter` with CJK fallback.

## Components

- Use comic panels for important media or action, not every information block.
- Use bursts behind rare impact words and rewards.
- Press chunky controls by translating into the hard shadow.
- Use one authored SVG icon/burst system; never use emoji as a shortcut.

## Motion

- Pop, slam, shake, wobble, and confetti should reflect impact intensity.
- Keep routine navigation quieter so major reactions can escalate.
- Provide reduced-motion alternatives for shake and rapid jitter.

## Drift to reject

- White background instead of cream paper.
- Soft blurred shadows.
- Rounded SaaS cards.
- Latin display fonts on Chinese prose.
- Halftone over every surface until readability collapses.
- Every element shouting at equal volume.
