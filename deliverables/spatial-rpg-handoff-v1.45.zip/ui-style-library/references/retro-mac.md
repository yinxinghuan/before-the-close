# Retro Mac

Use for intentionally light classic-computer, document, editor, or generator interfaces with monochrome structure, grid paper, windows, hard shadows, hatching, and Swiss/technical typography.

## Core language

- Background: warm gray `#E8E8E4`; light surface `#F5F5F0`; ink `#000000`; muted `#555555`; disabled `#999999`.
- Type: `Inter` for display/body; `Share Tech Mono` for labels, paths, codes, and fields.
- Structure: 2 px black borders and 3–4 px hard black shadows.
- Background grid: subtle 18 px square grid around 5% black.
- Decoration: hatch, dither, barcode, file tab, torn edge, or blinking cursor only when they encode the computer/document metaphor.

## Controls and windows

- Minimum control height 44 px.
- Press by translating into the hard shadow.
- Use a title bar, content region, and status bar only when the hierarchy benefits; do not wrap every small group in a window.
- Use coherent black SVG controls; never substitute emoji.

## Motion

- Keep feedback crisp: 150–300 ms fade/translate.
- Use step-end blinking only for cursor or live terminal-like states.
- Avoid bouncy consumer-app motion that conflicts with the utilitarian system.

## Drift to reject

- Soft drop shadows or glass blur.
- Excessive window nesting.
- Rounded modern cards.
- Random nostalgic ornaments with no information role.
- Scaling a fixed desktop mockup instead of responsive mobile layout.
