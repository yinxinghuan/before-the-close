"""Independent package regression using synthetic diagnostic fixtures, not game art."""
import argparse,hashlib,json,os,subprocess,sys,tempfile,zipfile
from pathlib import Path
from PIL import Image,ImageDraw
p=argparse.ArgumentParser();p.add_argument('archive',type=Path);p.add_argument('--report',type=Path,required=True);a=p.parse_args()
results=[]
with tempfile.TemporaryDirectory(prefix='spatial-package-') as folder:
 root=Path(folder)
 with zipfile.ZipFile(a.archive) as z:z.extractall(root)
 skill=root/'build-spatial-story-game';cut=skill/'scripts/prepare-actor-cutout.py'
 source=root/'source.png';im=Image.new('RGB',(288,384),(235,235,235));draw=ImageDraw.Draw(im)
 for row in range(4):
  for col in range(3):
   x=col*96+35;y=row*96+25
   draw.rectangle((x,y,x+25,y+50),fill=(30,40,45));draw.rectangle((x+7,y+8,x+18,y+22),fill=(250,245,232))
 im.save(source);original=source.read_bytes()
 def invoke(src,out,options=None):return subprocess.run([sys.executable,str(cut),str(src),str(out),'--neutral-min','185','--chroma-max','20','--foot-x','48','--foot-y','85',*(options or [])],capture_output=True,text=True,cwd=root,env={**os.environ,'PYTHONOPTIMIZE':'1'})
 output=root/'output.png';r=invoke(source,output);assert r.returncode==0,r.stderr
 rendered=Image.open(output).convert('RGBA');data=json.loads(output.with_suffix('.json').read_text())
 for frame in data['frames']:
  sx,sy,_,_=frame['sourceBox'];dx,dy=frame['destination'];col,row=frame['column'],frame['row']
  for y in range(row*96+33,row*96+48):
   for x in range(col*96+42,col*96+54):assert rendered.getpixel((dx+x-sx,dy+y-sy))==(*im.getpixel((x,y)),255)
 assert rendered.getpixel((0,0))[3]==0;assert source.read_bytes()==original
 results.append({'id':'independent-12-frame-cream-interior','passed':True})
 hero_sheet=rendered.resize((768,1024),Image.Resampling.NEAREST);hero_sheet.save(root/'hero-output.png')
 hero_frames=[]
 for row in range(4):
  for column in range(3):
   box=hero_sheet.crop((column*256,row*256,(column+1)*256,(row+1)*256)).getbbox()
   hero_frames.append({'row':row,'column':column,'direction':['down','left','right','up'][row],'requestId':f'request-{row}-{column}','taskId':f'task-{row}-{column}','sourceSha256':hashlib.sha256(f'{row}-{column}'.encode()).hexdigest(),'operations':['chroma-key','uniform-scale','foot-align']+(['mirror-full-frame'] if row==2 else []),'bbox':list(box),'headX':128,'footY':box[3],'visibleHeight':box[3]-box[1]})
 hero_manifest={'version':2,'status':'accepted','directions':['down','left','right','up'],'sourceService':'AlterU Media Service','partialLimbReflectionAllowed':False,'sheet':{'path':'hero-output.png'},'frames':hero_frames}
 hero_manifest_path=root/'hero-assembly.json';hero_manifest_path.write_text(json.dumps(hero_manifest))
 hero_audit=lambda:subprocess.run([sys.executable,str(skill/'scripts/audit-hero-sheet.py'),str(hero_manifest_path),'--root',str(root),'--require-accepted'],capture_output=True,text=True,cwd=root)
 hero_ok=hero_audit();results.append({'id':'independent-hero-gate-pass','passed':hero_ok.returncode==0,'exit':hero_ok.returncode,'error':hero_ok.stderr[-300:]})
 hero_manifest['frames'][2]['operations'].append('reflect-lower-body');hero_manifest_path.write_text(json.dumps(hero_manifest))
 hero_bad=hero_audit();results.append({'id':'hero-partial-limb-reflection-reject','passed':hero_bad.returncode==1 and 'partial limb synthesis' in hero_bad.stderr,'exit':hero_bad.returncode,'error':hero_bad.stderr[-300:]})
 def invalid(name,src,options=None,out=None):
  dest=out or root/(name+'-output.png');prior=src.read_bytes();prior_out=dest.read_bytes() if dest.exists() else None
  result=invoke(src,dest,options)
  good=result.returncode!=0 and src.read_bytes()==prior and (dest.read_bytes()==prior_out if prior_out is not None else not dest.exists())
  results.append({'id':name,'passed':good,'exit':result.returncode,'error':result.stderr[-300:]});return good
 invalid('source-overwrite',source,out=source)
 bad=root/'bad-size.png';Image.new('RGB',(287,384),'white').save(bad);invalid('uneven-grid',bad)
 empty=root/'empty.png';Image.new('RGB',(288,384),'white').save(empty);invalid('empty-frames',empty)
 invalid('anchor-outside-cell',source,['--foot-y','100'])
 invalid('subject-does-not-fit',source,['--foot-y','20'])
 keep=root/'keep.png';keep.write_bytes(b'previous-candidate');invalid('failed-check-preserves-previous-output',empty,out=keep)
 # A PNG payload may have a non-PNG input suffix; generated JSON must not overwrite it.
 alias=root/'collision.json';alias.write_bytes(original);invalid('report-overwrites-source',alias,out=root/'collision.png')
 # Test the packaged world validator without any train/game imports.
 (root/'floor.png').write_bytes(original)
 world={'version':1,'coordinateAnchor':'top-left','world':{'width':40,'height':40,'step':8},'actor':{'width':2,'height':2},'assets':[{'id':'floor','path':'floor.png'}],'scenes':[{'id':'room','background':'floor','walkRegion':{'x':0,'y':0,'w':40,'h':40},'spawn':{'x':8,'y':8},'obstacles':[],'targets':[{'id':'button','approach':{'x':24,'y':8},'states':['off','on'],'renderedStates':['off','on']}]}],'portals':[]}
 def check_world(name,obj,expected):
  path=root/(name+'.json');path.write_text(json.dumps(obj));run=subprocess.run(['node',str(skill/'scripts/validate-world.mjs'),str(path),str(root)],capture_output=True,text=True,cwd=root)
  results.append({'id':name,'passed':(run.returncode==0)==expected,'exit':run.returncode,'error':run.stderr.strip()})
 check_world('independent-room',world,True)
 foot_world=json.loads(json.dumps(world));foot_world['coordinateAnchor']='foot';foot_world['scenes'][0]['spawn']={'x':9,'y':10};foot_world['scenes'][0]['targets'][0]['approach']={'x':25,'y':10}
 check_world('explicit-foot-anchor',foot_world,True)
 invalid_anchor=json.loads(json.dumps(world));invalid_anchor['coordinateAnchor']='center'
 check_world('invalid-coordinate-anchor',invalid_anchor,False)
 world['scenes'][0]['obstacles']=[{'x':15,'y':0,'w':1,'h':40}];check_world('thin-wall-cannot-be-jumped',world,False)
 world['scenes'][0]['obstacles']=[];world['scenes'][0]['targets'][0]['approach']={'x':15,'y':8};world['scenes'][0]['obstacles']=[{'x':13,'y':0,'w':1,'h':40}];check_world('rounded-target-cannot-cross-wall',world,False)
 world['scenes'][0]['obstacles']=[];world['scenes'][0]['targets'][0]['approach']={'x':24,'y':8};world['scenes'][0]['targets'][0]['renderedStates']=['off'];check_world('missing-state',world,False)
 door_world={'version':1,'coordinateAnchor':'top-left','world':{'width':40,'height':40,'step':4},'actor':{'width':2,'height':2},'assets':[{'id':'floor','path':'floor.png'}],'scenes':[{'id':'room','background':'floor','walkRegion':{'x':0,'y':0,'w':40,'h':40},'spawn':{'x':8,'y':8},'obstacles':[],'targets':[{'id':'door-n','kind':'door','side':'N','approach':{'x':24,'y':8},'threshold':{'x':24,'y':8},'activation':{'x':20,'y':8,'w':12,'h':8},'states':['open'],'renderedStates':['open']}]}],'portals':[{'id':'return','from':'room','to':'room','arrival':{'x':24,'y':8},'target':'door-n'}]}
 check_world('door-threshold-arrival-contract',door_world,True)
 bad_door=json.loads(json.dumps(door_world));bad_door['scenes'][0]['targets'][0]['activation']={'x':4,'y':4,'w':4,'h':4};check_world('door-threshold-outside-activation',bad_door,False)
 bad_arrival=json.loads(json.dumps(door_world));bad_arrival['portals'][0]['arrival']={'x':8,'y':24};check_world('door-arrival-outside-activation',bad_arrival,False)
 # Execute the copied motion kernel using Node only; no game package/dependencies.
 motion=subprocess.run(['node',str(skill/'scripts/verify-motion.mjs')],capture_output=True,text=True,cwd=root)
 results.append({'id':'independent-distance-motion','passed':motion.returncode==0,'exit':motion.returncode,'output':motion.stdout[-600:],'error':motion.stderr[-300:]})
 space=subprocess.run(['node',str(skill/'scripts/verify-space.mjs')],capture_output=True,text=True,cwd=root)
 results.append({'id':'independent-runtime-geometry-and-scope','passed':space.returncode==0,'exit':space.returncode,'output':space.stdout[-800:],'error':space.stderr[-300:]})
 wall_check="""import {assembleRoom} from './build-spatial-story-game/assets/wall-assembly.mjs';
const room=assembleRoom({floor:{x:10,y:20,w:100,h:120},walls:{back:24,thickness:8,foreground:20},doors:[{id:'north',side:'N',at:60,width:20},{id:'west',side:'W',at:80,width:24},{id:'south',side:'S',at:55,width:18}]});
const rects=room.segments.map(s=>[s.side,s.start,s.end]);
const expected=[['N',10,50],['N',70,110],['W',20,68],['W',92,140],['E',20,140],['S',10,46],['S',64,110]];
if(JSON.stringify(rects)!==JSON.stringify(expected)||room.openings.length!==3)throw Error('wall or doorway mismatch');
if(room.openings.find(d=>d.id==='south').rect.y!==120)throw Error('south wall depth mismatch');
if(JSON.stringify(room.segments.map(s=>s.renderLayer))!==JSON.stringify([0,0,1,1,1,3,3]))throw Error('wall render layering mismatch');
const south=room.segments.filter(s=>s.side==='S');
if(south[0].rect.x!==10||south[0].renderRect.x!==2||south[0].renderRect.w!==44||south[1].renderRect.x!==64||south[1].renderRect.w!==54)throw Error('south wall overhang mismatch');
if(room.segments.filter(s=>s.side==='N').some(s=>s.renderRect.x!==s.rect.x||s.renderRect.w!==s.rect.w))throw Error('north wall must stay behind side walls');
const west=room.segments.filter(s=>s.side==='W');
if(west[0].renderRect.y!==-4||west[0].renderRect.h!==72||west[1].renderRect.y!==92||west[1].renderRect.h!==56)throw Error('side walls must cover the north corners and reach the south cap');
"""
 (root/'wall-check.mjs').write_text(wall_check)
 wall=subprocess.run(['node',str(root/'wall-check.mjs')],capture_output=True,text=True,cwd=root)
 results.append({'id':'independent-wall-door-assembly','passed':wall.returncode==0,'exit':wall.returncode,'error':wall.stderr[-300:]})
 interaction_check="""import {stableNearby,primaryInteractionIntent} from './build-spatial-story-game/assets/nearby-interaction.mjs';
const targets=[{id:'left',approach:{x:10,y:10}},{id:'right',approach:{x:18,y:10}}];
const near=(entity,position)=>{if(!position||typeof position.x!=='number')throw Error('position was not forwarded');return true};
if(stableNearby(targets,{x:14,y:10},near,undefined,'right')?.id!=='right')throw Error('preferred nearby target lost');
if(stableNearby(targets,{x:13,y:10},near,'right')?.id!=='right')throw Error('focus flickered inside hysteresis');
if(stableNearby(targets,{x:9,y:10},near,'right')?.id!=='left')throw Error('focus never yielded to clearly nearer target');
if(primaryInteractionIntent(undefined,false)!=='inactive'||primaryInteractionIntent('record',false)!=='open-panel'||primaryInteractionIntent('door',false)!=='enter-door'||primaryInteractionIntent('record',true)!=='close-panel')throw Error('primary interaction state mismatch');
"""
 (root/'interaction-check.mjs').write_text(interaction_check)
 interaction=subprocess.run(['node',str(root/'interaction-check.mjs')],capture_output=True,text=True,cwd=root)
 results.append({'id':'independent-two-stage-interaction','passed':interaction.returncode==0,'exit':interaction.returncode,'error':interaction.stderr[-300:]})
 pathfinder_check="""import {actorTopLeftFromFoot,createWalkability,findGridPath} from './build-spatial-story-game/assets/grid-pathfinder.mjs';
const actor={w:4,h:4},region={x:0,y:0,w:40,h:40},obstacles=[{x:16,y:0,w:8,h:28}];
const isWalkable=createWalkability({region,obstacles,actor});
const from={x:4,y:4},to={x:32,y:4},route=findGridPath({from,to,step:4,isWalkable});
if(route.length<4||!route.some(point=>point.y>=28))throw Error('route did not avoid the obstacle');
const converted=actorTopLeftFromFoot({x:6,y:8},actor);if(converted.x!==4||converted.y!==4)throw Error('foot anchor conversion mismatch');
"""
 (root/'pathfinder-check.mjs').write_text(pathfinder_check)
 pathfinder=subprocess.run(['node',str(root/'pathfinder-check.mjs')],capture_output=True,text=True,cwd=root)
 results.append({'id':'independent-grid-pathfinder','passed':pathfinder.returncode==0,'exit':pathfinder.returncode,'error':pathfinder.stderr[-300:]})
 media_client=(skill/'assets/alteru-media-service.ts').read_text()
 media_tokens=['submitImageMedia','generateImageMedia','getMediaTask','waitForMediaTask','createMediaRequestId','MediaServiceError','reference_urls','request_id','session_id','retryable']
 results.append({'id':'independent-self-contained-media-client','passed':all(token in media_client for token in media_tokens),'tokens':media_tokens})
 # The six reviewed UI themes must ship as stable ids, not as prose-only names.
 theme_css=(skill/'assets/ui-theme-tokens.css').read_text()
 theme_doc=(skill/'references/ui-theme-catalog.md').read_text()
 theme_ids=['01-cinema','02-notebook','03-pixel','04-index','05-terminal','06-blueprint']
 terminal_tokens=['#030f0c','#071811','#10291e','#d4f0d5','#50936f','#91efac','#69b686']
 theme_ok=all(f'data-spatial-ui-theme="{theme}"' in theme_css and f'`{theme}`' in theme_doc for theme in theme_ids) and all(token in theme_css for token in terminal_tokens) and 'data-ui-role="reading"' in theme_css and '声音、档案、地图等全局工具放在顶部工具区' in theme_doc and '主操作保持透明空心' in theme_doc and '非透明实底' in theme_doc and '至少保留 14px 净空' in (skill/'references/exploration-interaction.md').read_text() and '手指遮住目标与动词' in (skill/'references/exploration-interaction.md').read_text()
 results.append({'id':'independent-six-theme-catalog','passed':theme_ok,'themeIds':theme_ids})
 # A reference-experience handoff must include the product shell and persistent conversation contract.
 parity_path=skill/'references/reference-experience-parity.md'
 parity_doc=parity_path.read_text() if parity_path.exists() else ''
 parity_tokens=['地图 / 背包 / 菜单','YOU ARE HERE','新旅程开场','安全半径内巡游','朝向玩家','画面、碰撞体、接近点、热点和权威行动距离','玩家发言 → 等待回应 → NPC 回应 → 阅读停顿 → 下一组选项','中文约 `64` 字','参考层级声明','一次性剧情行动耗尽后']
 results.append({'id':'independent-reference-experience-parity','passed':all(token in parity_doc for token in parity_tokens),'tokens':parity_tokens})
 # Experience capabilities must be chosen explicitly and conditional omissions must fail.
 profile=skill/'assets/experience-capability-profile.json'
 profile_validator=skill/'scripts/validate-experience-profile.mjs'
 profile_pass=subprocess.run(['node',str(profile_validator),str(profile)],capture_output=True,text=True,cwd=root)
 results.append({'id':'independent-experience-capability-profile','passed':profile_pass.returncode==0,'exit':profile_pass.returncode,'output':profile_pass.stdout[-300:],'error':profile_pass.stderr[-300:]})
 invalid_profile=json.loads(profile.read_text())
 invalid_profile['gameProfile']['crossDevice']=True
 invalid_profile['modes']['persistence']='local-session'
 invalid_path=root/'invalid-experience-profile.json';invalid_path.write_text(json.dumps(invalid_profile))
 profile_reject=subprocess.run(['node',str(profile_validator),str(invalid_path)],capture_output=True,text=True,cwd=root)
 results.append({'id':'experience-profile-cross-device-reject','passed':profile_reject.returncode==1 and 'crossDevice requires account-cloud persistence' in profile_reject.stderr,'exit':profile_reject.returncode,'error':profile_reject.stderr[-300:]})
 incomplete_profile=json.loads(profile.read_text());incomplete_profile['releaseTarget']='high-fidelity'
 for capability in ['conversationHistory','inventoryVisuals','distanceFootsteps']:incomplete_profile['capabilities'][capability]={'state':'planned','evidence':[]}
 incomplete_path=root/'incomplete-high-fidelity-profile.json';incomplete_path.write_text(json.dumps(incomplete_profile))
 incomplete_reject=subprocess.run(['node',str(profile_validator),str(incomplete_path)],capture_output=True,text=True,cwd=root)
 incomplete_error=incomplete_reject.stderr
 results.append({'id':'experience-profile-high-fidelity-omission-reject','passed':incomplete_reject.returncode==1 and all(capability in incomplete_error for capability in ['conversationHistory','inventoryVisuals','distanceFootsteps']),'exit':incomplete_reject.returncode,'error':incomplete_error[-500:]})
 capability_modules_check="""
import {appendConversationTurn,emptyConversationHistory,characterConversation} from './build-spatial-story-game/assets/conversation-history.ts';
import {addJourney,emptyJourneyDirectory,removeJourney} from './build-spatial-story-game/assets/journey-directory.ts';
import {advanceFootsteps,emptyFootstepState} from './build-spatial-story-game/assets/distance-footsteps.ts';
let history=emptyConversationHistory();history=appendConversationTurn(history,{id:'a',characterId:'npc',speaker:'player',text:'hello',createdAt:1});history=appendConversationTurn(history,{id:'a',characterId:'npc',speaker:'player',text:'hello',createdAt:1});if(history.turns.length!==1||characterConversation(history,'npc').length!==1)throw Error('history identity failed');
let directory=addJourney(emptyJourneyDirectory(),{id:'j',title:'Journey',createdAt:1,updatedAt:1,progress:'start'});directory=removeJourney(directory,'j');if(directory.activeId!==null||directory.journeys.length)throw Error('journey removal failed');
let steps=[];const state=advanceFootsteps(emptyFootstepState(),25,10,foot=>steps.push(foot));if(steps.join(',')!=='left,right'||state.distance!==5||state.foot!=='left')throw Error('distance footsteps failed');
"""
 modules_path=root/'capability-modules-check.ts';modules_path.write_text(capability_modules_check)
 modules_run=subprocess.run(['node','--experimental-strip-types',str(modules_path)],capture_output=True,text=True,cwd=root)
 results.append({'id':'independent-experience-capability-modules','passed':modules_run.returncode==0,'exit':modules_run.returncode,'error':modules_run.stderr[-300:]})
 # The projected-art gate must catch mismatched adults, stretched walls/props and scale drift.
 hero=Image.new('RGBA',(32,32));npc=Image.new('RGBA',(32,32));face=Image.new('RGB',(64,32),'#778899');prop=Image.new('RGBA',(32,32))
 ImageDraw.Draw(hero).rectangle((10,4,22,28),fill='#223344')
 ImageDraw.Draw(npc).rectangle((10,4,22,28),fill='#334455')
 ImageDraw.Draw(prop).rectangle((2,4,29,20),fill='#887766')
 hero.save(root/'hero.png');npc.save(root/'npc.png');face.save(root/'face.png');prop.save(root/'prop.png')
 projection={'adultReference':'hero','adults':['npc'],'actors':[{'id':'hero','path':'hero.png','displayWorld':[32,32]},{'id':'npc','path':'npc.png','displayWorld':[32,32]}],'walls':[{'id':'wall','path':'face.png','displayWorld':[64,32]}],'props':[{'id':'table','path':'prop.png','displayWorld':[32,32],'visibleWidthToAdultRange':[1.1,1.3]}]}
 spec=root/'projection.json';spec.write_text(json.dumps(projection))
 def audit_projection():return subprocess.run([sys.executable,str(skill/'scripts/audit-projected-art.py'),str(spec),'--root',str(root)],capture_output=True,text=True,cwd=root)
 match=audit_projection();results.append({'id':'independent-projected-art-pass','passed':match.returncode==0,'exit':match.returncode,'error':match.stderr[-300:]})
 projection['actors'][1]['displayWorld']=[24,24];projection['walls'][0]['displayWorld']=[64,16];spec.write_text(json.dumps(projection))
 mismatch=audit_projection();results.append({'id':'independent-projected-art-reject','passed':mismatch.returncode==1 and 'adult visible height differs' in mismatch.stderr and 'wall source stretched' in mismatch.stderr,'exit':mismatch.returncode,'error':mismatch.stderr[-300:]})
 projection['actors'][1]['displayWorld']=[32,32];projection['walls']=[{'id':'segment-a','path':'face.png','displayWorld':[64,32],'scaleGroup':'same-wall'},{'id':'segment-b','path':'face.png','displayWorld':[32,16],'scaleGroup':'same-wall'}];spec.write_text(json.dumps(projection))
 fragmented=audit_projection();results.append({'id':'independent-fragmented-wall-scale-reject','passed':fragmented.returncode==1 and 'wall texture scale differs' in fragmented.stderr,'exit':fragmented.returncode,'error':fragmented.stderr[-300:]})
 projection['props'][0]['displayWorld']=[64,32];spec.write_text(json.dumps(projection))
 stretched_prop=audit_projection();results.append({'id':'independent-stretched-prop-and-scale-reject','passed':stretched_prop.returncode==1 and 'prop source stretched' in stretched_prop.stderr and 'visible width / hero height' in stretched_prop.stderr,'exit':stretched_prop.returncode,'error':stretched_prop.stderr[-300:]})
 # Actor-roster gate compares every NPC with the accepted hero and requires renderer evidence.
 evidence=root/'actor-evidence.png';Image.new('RGB',(390,844),'#223344').save(evidence)
 def actor_record(ident,path):return {'id':ident,'path':path.name,'sourceSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'requestIds':['request-'+ident],'taskIds':['task-'+ident],'displayWorld':[32,32]}
 roster={'version':1,'status':'accepted','sourceService':'AlterU Media Service','hero':actor_record('hero',root/'hero.png'),'actors':[actor_record('npc',root/'npc.png')],'evidence':[{'actorId':'npc','path':evidence.name,'viewport':[390,844],'heroAdjacent':True,'directions':['down','side','up']}]}
 roster_path=root/'actor-roster.json';roster_path.write_text(json.dumps(roster))
 def audit_roster():return subprocess.run([sys.executable,str(skill/'scripts/audit-actor-roster.py'),str(roster_path),'--root',str(root),'--require-accepted'],capture_output=True,text=True,cwd=root)
 roster_ok=audit_roster();results.append({'id':'independent-actor-roster-pass','passed':roster_ok.returncode==0,'exit':roster_ok.returncode,'error':roster_ok.stderr[-300:]})
 roster['actors'][0]['displayWorld']=[20,20];roster['evidence']=[];roster_path.write_text(json.dumps(roster))
 roster_bad=audit_roster();results.append({'id':'actor-roster-scale-and-evidence-reject','passed':roster_bad.returncode==1 and 'visible height differs' in roster_bad.stderr and 'missing adjacent hero comparison evidence' in roster_bad.stderr,'exit':roster_bad.returncode,'error':roster_bad.stderr[-500:]})
 # RPGJS maps need an object layer, and the shipped adapter must expose the verified room/event hooks.
 valid_map=root/'valid.tmx';valid_map.write_text('<map><layer/><objectgroup name="collision"/></map>')
 invalid_map=root/'invalid.tmx';invalid_map.write_text('<map><layer/></map>')
 map_validator=skill/'scripts/validate-rpg-map.mjs'
 valid_run=subprocess.run(['node',str(map_validator),str(valid_map)],capture_output=True,text=True,cwd=root)
 invalid_run=subprocess.run(['node',str(map_validator),str(invalid_map)],capture_output=True,text=True,cwd=root)
 results.append({'id':'independent-rpg-map-objectgroup','passed':valid_run.returncode==0 and invalid_run.returncode==1 and 'missing objectgroup' in invalid_run.stderr,'validExit':valid_run.returncode,'invalidExit':invalid_run.returncode,'error':invalid_run.stderr[-300:]})
 runtime_source=(skill/'assets/rpg-space.ts').read_text()
 runtime_tokens=['mapEvents:(scene:string)=>any[]','spritesheets:any[]','loaded===id&&joined===id','activeRoom()','client.renderer.resize','options.onFrame','controlsBlocked','debug']
 results.append({'id':'independent-current-rpgjs-adapter-contract','passed':all(token in runtime_source for token in runtime_tokens),'tokens':runtime_tokens})
 # Pose families must retain platform provenance and derive the opposite contact from the accepted seed.
 def pose_frame(index):return {'requestId':f'request-{index}','taskId':f'task-{index}','sha256':f'{index:064x}'}
 pose={'version':1,'status':'candidate','actorId':'hero','sourceService':'AlterU Media Service','generatedDirections':{},'derivedDirection':{'direction':'right','from':'side','transform':'mirror-full-frame'},'evidence':[]}
 index=1
 for direction in ['down','side','up']:
  stand=pose_frame(index);index+=1;seed=pose_frame(index);index+=1;opposite=pose_frame(index);index+=1;opposite['referenceTaskId']=seed['taskId']
  pose['generatedDirections'][direction]={'stand':stand,'seedContact':seed,'oppositeContact':opposite}
  for viewport in ['390x844','320x568']:pose['evidence'].append({'viewport':viewport,'direction':direction,'renderer':'actual','cycle':'contact-stand-opposite-stand'})
 pose_path=root/'actor-pose.json';pose_path.write_text(json.dumps(pose))
 pose_validator=skill/'scripts/validate-actor-pose-plan.mjs'
 pose_ok=subprocess.run(['node',str(pose_validator),str(pose_path)],capture_output=True,text=True,cwd=root)
 results.append({'id':'independent-actor-pose-family-pass','passed':pose_ok.returncode==0,'exit':pose_ok.returncode,'error':pose_ok.stderr[-300:]})
 pose['generatedDirections']['up']['oppositeContact']['referenceTaskId']=pose['generatedDirections']['up']['stand']['taskId'];pose_path.write_text(json.dumps(pose))
 pose_bad=subprocess.run(['node',str(pose_validator),str(pose_path)],capture_output=True,text=True,cwd=root)
 results.append({'id':'actor-pose-unrelated-edit-reject','passed':pose_bad.returncode==1 and 'must edit the accepted seedContact' in pose_bad.stderr,'exit':pose_bad.returncode,'error':pose_bad.stderr[-300:]})
 # Every room needs the thick envelope and axis-aligned furniture majority; diagonal pieces are accents.
 room={'version':1,'rooms':[{'id':'room','envelope':{'mode':'thick-orthographic','assets':{'floor':'floor','northWall':'north','sideWall':'side','southForeground':'south'},'dimensions':{'northFaceHeight':48,'sideThickness':10,'southForegroundHeight':40},'layerOrder':['north','side','actors','south'],'corners':{'northWest':'side-over-north','northEast':'side-over-north','southWest':'south-over-side','southEast':'south-over-side'},'features':{'north':['cap','face','trim','floor-shadow'],'side':['cap','inner-seam'],'south':['cap','face','trim']}},'furniture':[{'id':'desk','orientation':'axis-aligned','role':'anchor','zone':'work','footprintArea':100,'collision':'rects'},{'id':'cabinet','orientation':'axis-aligned','role':'support','zone':'wall','footprintArea':80,'collision':'rects'},{'id':'chair','orientation':'axis-aligned','role':'support','zone':'work','footprintArea':50,'collision':'rects'},{'id':'accent','orientation':'diagonal-45','role':'accent','zone':'waiting','footprintArea':30,'collision':'polygon'}],'evidence':[{'viewport':'390x844','renderer':'actual','corners':True,'southOcclusion':True},{'viewport':'320x568','renderer':'actual','corners':True,'southOcclusion':True}]}]}
 room_path=root/'scene-visual.json';room_path.write_text(json.dumps(room))
 room_validator=skill/'scripts/validate-scene-visual-contract.mjs'
 room_ok=subprocess.run(['node',str(room_validator),str(room_path)],capture_output=True,text=True,cwd=root)
 results.append({'id':'independent-thick-room-and-furniture-mix-pass','passed':room_ok.returncode==0,'exit':room_ok.returncode,'error':room_ok.stderr[-300:]})
 room['rooms'][0]['envelope']['assets']['southForeground']='side';room['rooms'][0]['furniture'][0]['orientation']='diagonal-45';room['rooms'][0]['furniture'][0]['role']='anchor';room_path.write_text(json.dumps(room))
 room_bad=subprocess.run(['node',str(room_validator),str(room_path)],capture_output=True,text=True,cwd=root)
 results.append({'id':'flat-envelope-and-diagonal-majority-reject','passed':room_bad.returncode==1 and 'independent IDs' in room_bad.stderr and 'must be accent' in room_bad.stderr and 'exceeds one third' in room_bad.stderr,'exit':room_bad.returncode,'error':room_bad.stderr[-500:]})
 # Progressive-room validation must keep shell and final geometry identical and player copy free of implementation terms.
 progressive=json.loads((skill/'assets/progressive-room-contract.json').read_text())
 progressive_path=root/'progressive-room.json'
 def check_progressive(name,obj,expected,needle=''):
  progressive_path.write_text(json.dumps(obj,ensure_ascii=False))
  run=subprocess.run(['node',str(skill/'scripts/validate-progressive-room.mjs'),str(progressive_path)],capture_output=True,text=True,cwd=root)
  passed=(run.returncode==0)==expected and (not needle or needle in run.stderr)
  results.append({'id':name,'passed':passed,'exit':run.returncode,'output':run.stdout[-300:],'error':run.stderr[-500:]})
 check_progressive('independent-progressive-room-contract',progressive,True)
 drift=json.loads(json.dumps(progressive));drift['complete']['slots'][0]['footprint']['w']=9
 check_progressive('progressive-room-footprint-drift-reject',drift,False,'changes footprint')
 internal=json.loads(json.dumps(progressive));internal['shell']['playerCopy']['hint']['zh']='碰撞与后台任务已生效'
 check_progressive('progressive-room-internal-copy-reject',internal,False,'exposes implementation detail')
 # The packaged runtime must restore accepted slots and isolate a terminal failure.
 progressive_runtime_check="""import {freshProgressiveMediaState,loadProgressiveMediaState,saveProgressiveMediaState,recoverProgressiveMedia} from './build-spatial-story-game/assets/progressive-media-runtime.mjs';
const definitions={floor:{taskId:'task-floor',requestId:'request-floor'},chair:{taskId:'task-chair',requestId:'request-chair'}};
const values=new Map();const storage={getItem:key=>values.get(key)??null,setItem:(key,value)=>values.set(key,value)};
const initial=freshProgressiveMediaState(definitions);
const state=await recoverProgressiveMedia({definitions,initial,readTask:async id=>id==='task-floor'?{task_id:id,request_id:'request-floor',status:'succeeded',media:{type:'image',url:'https://example.invalid/floor.png'}}:{task_id:id,request_id:'request-chair',status:'failed',error:{code:'REJECTED'}}});
if(state.assets.floor.phase!=='ready'||state.assets.chair.phase!=='failed')throw Error('per-slot completion or failure isolation mismatch');
saveProgressiveMediaState(storage,'room',state);const restored=loadProgressiveMediaState(storage,'room',definitions);
if(restored.assets.floor.phase!=='ready'||restored.assets.chair.errorCode!=='REJECTED')throw Error('refresh recovery mismatch');
let reads=0;await recoverProgressiveMedia({definitions,initial:restored,readTask:async id=>{reads++;return {task_id:id,request_id:'request-chair',status:'failed',error:{code:'REJECTED'}}}});
if(reads!==1)throw Error('accepted slot was queried again');
"""
 (root/'progressive-runtime-check.mjs').write_text(progressive_runtime_check)
 runtime=subprocess.run(['node',str(root/'progressive-runtime-check.mjs')],capture_output=True,text=True,cwd=root)
 results.append({'id':'independent-progressive-media-runtime','passed':runtime.returncode==0,'exit':runtime.returncode,'error':runtime.stderr[-500:]})
report={'archive':str(a.archive),'independentTemporaryDirectory':True,'syntheticDiagnosticImages':True,'optimizedPythonGuards':True,'results':results,'passed':all(r['passed'] for r in results)}
a.report.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False));sys.exit(0 if report['passed'] else 1)
