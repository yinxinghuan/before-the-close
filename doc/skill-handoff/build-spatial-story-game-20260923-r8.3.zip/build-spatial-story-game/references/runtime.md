# 叙事权威与场景切换

## 唯一状态来源

地图引擎拥有短时位置/动画；权威保存拥有剧情、道具、关系、可见状态和当前区域。由规则/reducer 的结果投射地图。AI、UI、空间引擎都不能在自己的状态里独立结算永久后果。

动作请求至少绑定 actor/session、action_id、expected_version、当前 scene ID、目标 entity ID、动作与落点。检查当前场景与实体所属一致、落点可走且距离允许。仅凭坐标距离不能防止跨场景操作同坐标的物件。

出入口是明确授权动作：原子提交场景变更、目标到达点和故事效果，写入可重放回执。到达点必须不与墙、柜、NPC、另一门碰撞。晚到的位置 checkpoint 必须检查 scene/version，不能把上一地图的位置写回新地图。未知结果用原 action_id 恢复，不能直接丢弃 pending 再发一次。

## 客户端交接

暂停输入 → 取消路径/到达回调与按住状态 → 提交/恢复权威动作 → 加载已准入背景/逻辑地图 → 使用服务端落点 → 确认真实 renderer 当前场景与人物位置 → 恢复输入。加载失败提供重试，不能在上一张物理地图上开放新场景热点。

旧存档增加新地图/缺失事实的默认值，保留旧事实、物品、关系和正文。新的章节完成标志不能复用旧切片完成标志。检查已完成旧存档能继续新章节，也检查未完成旧存档。

## 模型边界

只传当前场景实体。已见人物离开当前图仍可属于历史，但不能据此允许远程互动；未见人物名字更不能出现在初始 roster/选项中。已读线索持久化，未读线索不能静默注入模型。

输出结构建议 kind/entityIds/claims/actionId/text。验证存在性、所属场景、当前状态、身份、许可动作；自由文本需额外审查，仍属概率保障。拒绝/超时安全回退，权威不变。动作由确定性规则产生结果文字，模型不能把提议描述成已完成。

## RPG-JS 样本注意事项

本样本使用 RPG-JS 5 beta 的真实 renderer、Tiled loader 和地图/事件。锁定版本见样本 package-lock，不把 beta API 写成跨版本保证。技术变化时优先查安装源码，再查官方资料。

样本的移动/寻路是读取共享碰撞的适配器，底部对白是 React，并非原生 multiplayer prediction/showText。更新 standalone server player.position 后还要确认实际客户端 sprite 位置/方向/animation signal；曾出现逻辑在走而画面精灵不动。

TMX 透明逻辑层与背景分离，使用外部 TSX；单一透明 map 可承载场景平面，但加载各地图必须等待完成。样本服务端验证合法落点与操作距离，没有跨时间的移动速度反作弊，不宣称可直接做生产多人世界。

本 beta 版本另一个已复现的转场问题：onConnected 捕获的是原房间玩家实例，换房间后必须在 onJoinMap 更新引用；等待目标 onJoinMap 与客户端 onAfterLoading 均完成。`changeMap()` 只发出信号即返回，不能把其 Promise 完成当成 renderer 完成。实时事件列表也不能只在加载 hook 中截一次快照，因为返回已有地图时初始事件同步可能稍晚；验证应读取当前事件 signal。

## 慢网络转场的纹理准备

CanvasEngine 2.2.0 的异步 Sprite.onMount 在贴图加载期间若场景被销毁，恢复后可能更新已销毁的anchor/scale。不能以本地缓存快速加载作为通过证据。

给 `createRpgSpace` 提供 `prepareScene(scene)`：使用同一个 `pixi.js` 的 `Assets.load`，提前加载该房间背景/四边墙/门近端与门叶/家具/当前NPC以及主角的实际spritesheet.image URL。初次创建renderer前也准备首场景。运行时restore在设置changing后等待prepareScene，完成再changeMap；不重复保存剧情状态，不在逐帧里下载。Vite仍需dedupe pixi.js以共享纹理缓存。

用图片请求延迟800ms模拟冷加载，走完进入→快速返回→刷新，检查实际绘制和pageerror。失败应保留可重试加载状态；不得吞掉异常后称加载成功。该门禁已在两种手机尺寸的真实游戏构建与线上复验。
