import fs from 'node:fs';

const file=process.argv[2];
if(!file){console.error('Usage: node validate-actor-pose-plan.mjs ACTOR-POSE-PLAN.json');process.exit(2)}
let data;try{data=JSON.parse(fs.readFileSync(file,'utf8'))}catch(error){console.error('FAIL: '+error.message);process.exit(2)}
const errors=[];const fail=message=>errors.push(message);
if(data.version!==1)fail('version must be 1');
if(data.sourceService!=='AlterU Media Service')fail('sourceService must be AlterU Media Service');
const directions=data.generatedDirections||{};
const required=['down','side','up'];
const sha=/^[a-f0-9]{64}$/i;
const tasks=new Set();
for(const direction of required){
 const family=directions[direction];
 if(!family){fail(`${direction}: missing generated direction family`);continue}
 for(const role of ['stand','seedContact','oppositeContact']){
  const frame=family[role];
  if(!frame){fail(`${direction}/${role}: missing complete-frame source`);continue}
  if(!frame.requestId)fail(`${direction}/${role}: missing requestId`);
  if(!frame.taskId)fail(`${direction}/${role}: missing taskId`);else if(tasks.has(frame.taskId))fail(`${direction}/${role}: taskId reused across independent poses`);else tasks.add(frame.taskId);
  if(!sha.test(frame.sha256||''))fail(`${direction}/${role}: invalid sha256`);
 }
 if(family.oppositeContact?.referenceTaskId!==family.seedContact?.taskId)fail(`${direction}: oppositeContact must edit the accepted seedContact task`);
}
const derived=data.derivedDirection;
if(!derived||derived.direction!=='right'||derived.from!=='side'||derived.transform!=='mirror-full-frame')fail('right direction must derive from side with mirror-full-frame');
const evidence=Array.isArray(data.evidence)?data.evidence:[];
for(const viewport of ['390x844','320x568'])for(const direction of required){
 if(!evidence.some(item=>item.viewport===viewport&&item.direction===direction&&item.renderer==='actual'&&item.cycle==='contact-stand-opposite-stand'))fail(`missing actual renderer evidence for ${direction} at ${viewport}`);
}
if(data.status==='accepted'&&errors.length)fail('accepted plan has unresolved failures');
if(errors.length){for(const error of errors)console.error('FAIL: '+error);process.exit(1)}
console.log(JSON.stringify({passed:true,actorId:data.actorId,directions:required,evidence:evidence.length}));
