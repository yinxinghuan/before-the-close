import assert from 'node:assert/strict';
import {submitImageMedia,generateImageMedia} from '../assets/alteru-media-service.ts';
const calls=[];const fetchImpl=async(url,init)=>{calls.push({url,body:JSON.parse(init.body)});return Response.json({task_id:'fixture',request_id:'fixed',type:'image',status:'succeeded',media:{type:'image',url:'https://example.invalid/1.webp',urls:['https://example.invalid/1.webp','https://example.invalid/2.webp'],format:'webp',model:'gpt-image-2.5-sunburst'}})};
const request={sessionId:'fixture-session',requestId:'fixed',mode:'text',prompt:'A test fixture',referenceUrls:[],model:'gpt-image-2.5-sunburst',size:'auto',quality:'high',background:'opaque',n:2};
await submitImageMedia(request,{fetchImpl});const completed=await generateImageMedia(request,{fetchImpl});
assert.equal(completed.media.urls.length,2);assert.equal(calls.length,2);
for(const {body} of calls){assert.equal(body.model,request.model);assert.equal(body.size,'auto');assert.equal(body.request_id,'fixed');assert.equal(body.session_id,'fixture-session');assert.deepEqual(body.reference_urls,[]);assert.equal(body.n,2)}
await submitImageMedia({...request,model:undefined,n:undefined,size:{width:1024,height:1024}},{fetchImpl});assert.equal(calls[2].body.model,undefined);assert.ok(calls[2].body.size.width>0);
console.log('Media SDK: stable IDs, GPT fields, text without refs, multi-image and legacy sizing pass (mock transport only).');
