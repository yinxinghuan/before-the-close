import assert from 'node:assert/strict'
import {availableTopics,completedTopics} from '../assets/conversation-flow.ts'
const topics=[{key:'root',aliases:[{question:'Why?',reply:'Because.'},{question:'为什么？',reply:'因为。'}]},{key:'next',after:'root'},{key:'end',after:'next'},{key:'help',utility:true}]
assert.deepEqual(availableTopics(topics,[]).map(t=>t.key),['root','help'])
const history=[{question:'为什么？',reply:'因为。'}]
assert.deepEqual(availableTopics(topics,history).map(t=>t.key),['next','help'])
history.push({topicKey:'next',question:'Then?',reply:'Continue.'})
assert.deepEqual(availableTopics(topics,history).map(t=>t.key),['end','help'])
assert.deepEqual(availableTopics(topics,JSON.parse(JSON.stringify(history))).map(t=>t.key),['end','help'])
assert.ok(availableTopics(topics,[],['root','next','end','help']).some(t=>t.key==='help'))
assert.ok(availableTopics(topics,[{topicKey:'root',question:'Why?',reply:''}]).some(t=>t.key==='root'))
assert.equal(completedTopics([...topics,{key:'ambiguous',aliases:topics[0].aliases}],[history[0]]).size,0)
const variants=[{key:'claim@before'},{key:'claim@evidence'}]
assert.deepEqual(availableTopics(variants,[{topicKey:'claim@before',question:'q',reply:'a'}]).map(t=>t.key),['claim@evidence'])
console.log(JSON.stringify({passed:true,checks:8,scope:'pure topic lifecycle; storage/UI supplied by consumer'}))
